# Created by...: Michael Thomas michael@michael-thomas.com
# Description..: MySql - examples of working with Field Types.
# Orig Date....: 05/27/02
# Modified Date: 05/27/02
#
# Reference:  See 7.2    User Variables in the MySql docs.
#             See 7.28.4 Show Variables.
# -------------------------

DROP DATABASE IF EXISTS myex_case;
CREATE DATABASE IF NOT EXISTS myex_case;
USE myex_case;

#-----------------------------------------------
#Setup Tables for the CASE examples.
#-----------------------------------------------

DROP TABLE IF EXISTS sex;
CREATE TABLE sex (
  sex_code CHAR(1) NOT NULL,
  sex_desc CHAR(10) NOT NULL DEFAULT '',
  PRIMARY KEY (sex_code)
) TYPE=MyISAM;

INSERT INTO sex ( sex_code, sex_desc )
  VALUES 
  ( 'M','Male' ),
  ( 'F','Female' );
  
SELECT * FROM sex;

DROP TABLE IF EXISTS test;

CREATE TABLE test (
  id INT(11) NOT NULL,
  name VARCHAR(30) NOT NULL DEFAULT '',
  sex CHAR(1) NOT NULL DEFAULT '',
  age INT,
  playchar1 CHAR(10) NOT NULL DEFAULT '',
  playchar2 CHAR(10) NOT NULL DEFAULT '',
  PRIMARY KEY (id)
) TYPE=MyISAM;

INSERT INTO test ( id, name, sex, age )
  VALUES 
  ( 1,"Michael","M",41 ),
  ( 2,"Charmaine","F",38 ),
  ( 3,"Adam","M",10 ),
  ( 4,"Stephen","M",14 ),
  ( 5,"Ardis","F",62 ),
  ( 6,"Dempsey","M",70 ),
  ( 7,"Abraham","M",100 );

SELECT * FROM test;

#-----------------------------------------------
#Simple CASE with SELECT command.
#-----------------------------------------------

SELECT name,
       sex,
       CASE 
         WHEN sex = 'M' THEN 'Male'
         WHEN sex = 'F' THEN 'Female'
         ELSE
           'N/A'
       END
       FROM test;

#Another way to do the same thing as the above, just abbreviated some.
#Notice:  'CASE' vs 'CASE sex'
SELECT name,
       sex,
       CASE sex
         WHEN 'M' THEN 'Male'
         WHEN 'F' THEN 'Female'
         ELSE
           'N/A'
       END
       FROM test;

#-----------------------------------------------
#Using User Variables, and NO records.
#-----------------------------------------------

SET @var_Sex = "M";
SET @var_SexDesc = "";
SELECT @var_Sex,
       CASE @var_Sex
         WHEN 'M' THEN 'Male'
         WHEN 'F' THEN 'Female'
         ELSE
           'N/A'
       END;

#-----------------------------------------------
#Using User Variables and setting User Variables.
#-----------------------------------------------

SET @var_Sex := "F";
SET @var_SexDesc = "";
SELECT @var_Sex,
       CASE @var_Sex
         WHEN 'M' THEN (@var_SexDesc := 'Male')
         WHEN 'F' THEN (@var_SexDesc := 'Female')
         ELSE
           'N/A'
       END;
SELECT @var_Sex, @var_SexDesc;

#-----------------------------------------------
#CASE with Comparison Operators.
#-----------------------------------------------
SELECT name, 
       CASE
         WHEN age < 12  THEN 'Kid'
         WHEN age < 18  THEN 'Teenage'
         WHEN age < 60  THEN 'Adult'
         WHEN age < 100 THEN 'Senior'
         ELSE
           'Golden Senior'
       END,
       age
       FROM test;

#-----------------------------------------------
#CASE & UPDATE command.
#-----------------------------------------------

UPDATE test
  SET 
  playchar1 = 
    CASE
      WHEN age < 12  THEN 'Kid'
      WHEN age < 18  THEN 'Teenage'
      WHEN age < 60  THEN 'Adult'
      WHEN age < 100 THEN 'Senior'
      ELSE
        'Golden Senior'
    END,
  playchar2 = 
    CASE sex
      WHEN 'M' THEN 'Male'
      WHEN 'F' THEN 'Female'
      ELSE
        'N/A'
    END
  ;
  
SELECT name, age, playchar1, playchar2 from test;

#-----------------------------------------------
# !!! Need to figure out how to update from a value in another table !!!
#-----------------------------------------------

#SELECT sex.sex_desc FROM sex WHERE sex.sex_code = 'M';
#SELECT test.name, test.sex, sex.sex_desc FROM test
#  LEFT JOIN sex ON sex.sex_code = test.sex;

#-----------------------------------------------
#Drop databases created.  Comment the next line if you want to see the tables in the database.
#-----------------------------------------------
DROP DATABASE IF EXISTS myex_case;
