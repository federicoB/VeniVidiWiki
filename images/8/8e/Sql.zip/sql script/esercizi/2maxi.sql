use coorasse;
drop table if exists ciclista;
create table ciclista(
	nome character(20) not null,
	nazionalita character(20),
	eta integer
);

insert into ciclista
	values
		('Mario','Neri',34),
		('Maria','GrandeVagina',14),
		('Giorgio','Napolitano',70),
		('Silvio','Berlusconi',78),
		('Rumeno','Prodi',898);


drop table if exists gara;
create table gara(
	nomeCorsa character(20) not null,
	anno integer not null,
	partenza character(20),
	arrivo character(20)
);

insert into gara
	values
		('TourDeFrance',1980,'Napoli','Nizza'),
		('TourDeFrance',1981,'Da casa di mia nonna', 'a quella della tua'),
		('Giro',2016,'Norimberga','Katmandu'),
		('GiroDItalia',2006,'Firenza','Roma'),
		('Giro',2007,'Milano','Yorkshire');

drop table if exists partecipa;
create table partecipa(
	nomeCorsa character(20) not null references gara(nomeCorsa),
	anno integer not null references gara(anno),
	nome character(20) not null references ciclista(nome),
	posizione character(2)
);

insert into partecipa
	values
		('TourDeFrance',1980,'Silvio','77'),
		('Giro',2016,'Rumeno','R'),
		('Giro',2007,'Mario','1'),
		('Giro',2007,'Maria','2');


/*selezionare i ciclisti che si sono classificati primi in una gara che partiva da Milano*/
select distinct p.nome
from partecipa p natural join gara g
where p.posizione = '1' and
	 g.partenza = 'Milano';

/*selezionare i ciclisti che non si sono mai ritirati al 'Giro'*/
select distinct p.nome
from partecipa p
where p.posizione <> 'R' and
	 p.nomeCorsa = 'Giro';

/*selezionare le corse per le quali, in ogni edizione, vi e' stato almeno un ritirato*/
select p1.nomeCorsa, p1.anno
from partecipa p1
where exists (select *
		    from partecipa p2
		    where p1.nomeCorsa = p2.nomeCorsa and
				p1.anno = p2.anno and
				p2.posizione = 'R')
group by p1.nomeCorsa, p1.anno;

/*selezionare, per ogni corsa, l'anno in cui c'e' stato il maggior numero di ciclisti ritirati*/
select p.nomeCorsa, p.anno
from partecipa p
where p.posizione = 'R'
group by p.nomeCorsa, p.anno
having count(*) >= all ( select count(*)
					from partecipa p2
					where p2.posizione = 'R' and
						p.nomeCorsa = p2.nomeCorsa
					group by nomeCorsa, anno);
