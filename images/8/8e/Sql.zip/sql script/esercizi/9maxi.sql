use coorasse;

drop table if exists fornitore;
drop table if exists prodotto;
drop table if exists fornisce;

create table fornitore (
	codF integer not null,
	nome character(20),
	citta character(20)
);

create table prodotto (
	codP integer not null,
	descrizione character(20),
	prezzo integer
);

create table fornisce (
	anno integer,
	codP integer references prodotto(codP),
	codF integer references fornitore(codF),
	quantita integer
);
	
/*selezionare i prodotti che nel 1995 sono stati forniti da almeno un fornitore di modena*/
select distinct codP
from fornisce fi natural join fornitore fo
where fo.citta = 'Modena' and
	 fi.anno = '1995';

/*selezionare i prodotti non forniti da nessun fornitore di modena*/
select p.*
from prodotto p
where p.codP not in (select distinct codP
				 from fornisce fi natural join fornitore fo
				where fo.citta = 'Modena');

/*selezionare i prodotti che nel 1994 sono stati forniti solo da fornitori di Modena*/
select p.*
from prodotto p natural join fornisce fi natural join fornitore po
where fi.anno = '1994' and
	 po.citta = 'Modena' and
	 fi.codP not in (select fi2.codP
				  from fornisce fi2 natural join fornitore po2
				  where fi.anno = '1994' and
					   po.citta <> 'Modena'
				 );

/*selezionare per ogni anno la quantita totale di prodotti forniti da Modena*/
select fi.anno, sum(fi.quantita) as SommaProdottiDaModena
from fornisce fi natural join fornitore po
where po.citta = 'Modena'
group by fi.anno;
	 
/*selezionare, per ogni anno, il produttore che ha prodotto la maggior quantita' di prodotti*/
select fi.anno, fi.codF
from fornisce fi
group by fi.anno, fi.codF
having sum(fi.quantita) >= all (select sum(f2.quantita)
						from fornisce f2
						where fi.anno = f2.anno and
							 fi.codF = f2.codF
						group by f2.codF
						);


