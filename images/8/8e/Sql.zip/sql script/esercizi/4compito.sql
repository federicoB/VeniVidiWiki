use coorasse;
drop table if exists squadra;
create table squadra(
	sede character(20) not null,
	nome character(20) not null,
	divisa integer not null
);

insert into squadra
	values
		('1','Mario',20),
		('2','Maria',30),
		('3','Giorgio',25),
		('4','Silvio',28),
		('5','Tina',29);

drop table if exists stadio;
create table stadio(
	capienza integer not null,
	nome character(20) not null,
	citta character(20) not null
);

insert into stadio
	values
		(30000,'A','Napoli'),
		(20000,'B','Palermo'),
		(40000,'C','Barcellona'),
		(19870,'D','Udine');

drop table if exists partita;
create table partita(
	stadio character(20) references stadio(nome),
	squadra1 character(20) references squadra(nome),
	squadra2 character(20) references squadra(nome),
	data date
);

insert into partita
	values
		('A','Mario','Maria',2007-19-02),
		('B','Giorgio','Silvio',2007-18-04),
		('C','Tina','Silvio',2007-23-08),
		('D','Tina','Giorgio',2008-23-08),
		('B','Maria','Silvio',2008-30-01);


/*stadi con capienza inferiore a 30000 in cui sono state giocate almeno due partite*/
select p.stadio
from partita p join stadio s on
	s.nome = p.stadio
where s.capienza < 30000
group by p.stadio
having count(*) > 1;

/*squadre che non hanno mai giocato in stadi con capienza inferiore alle 30000 persone*/
select s1.nome
from squadra s1
where not exists (select *
				  from partita p join stadio st on
					st.nome = p.stadio
				  where st.capienza < 30000 and
					   (p.squadra1 = s1.nome or
					   p.squadra2 = s1.nome));
				  
