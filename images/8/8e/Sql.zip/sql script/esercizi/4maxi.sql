use coorasse;
drop table if exists prodotto;
create table prodotto(
	codP integer not null,
	descrizione text
);

insert into prodotto
	values
		(1,'uva'),
		(2,'Mario'),
		(3,'Napolitano'),
		(4,'La guernica parte 2'),
		(5,'I mille'),
		(6,'Le marionette');


drop table if exists socio;
create table socio(
	nome character(20) not null,
	cognome character(20) not null,
	codS integer not null
);

insert into socio
	values
		('Mario','Neri',34),
		('Maria','GrandeVagina',14),
		('Giorgio','Napolitano',70),
		('Silvio','Berlusconi',78),
		('Rumeno','Prodi',898);

drop table if exists offerta;
create table offerta(
	codO integer not null,
	validita integer not null
);

insert into offerta
	values
		(1,1),
		(2,3),
		(3,3),
		(4,4);

drop table if exists comprende;
create table comprende(
	codO integer not null references offerta(codO),
	codP integer not null references prodotto(codP),
	quantita integer not null
);

insert into comprende values
	(1,1,5),
	(1,2,7),
	(1,3,8),
	(2,3,70),
	(2,4,30),
	(3,1,9);

drop table if exists ritira;
create table ritira(
	codO integer not null references offerta(codO),
	codS integer not null references socio(codS),
	data date
);

insert into ritira values
	(1,34,1999-01-01),
	(1,898,1999-01-01),
	(1,70,null),
	(3,70,1999-01-01);

/*codice e descrizione dei prodotti mai stati in offerta assieme a 'uva'*/
select distinct p.codP, p.descrizione
from comprende c natural join prodotto p
where c.codO not in (select distinct c.codO
				 from comprende c natural join prodotto p
				 where p.descrizione = 'uva');

/*codice, nome e cognome dei soci che non hanno mai ritirato alcuna offerta che comprendesse 'uva'*/
select s.codS, s.nome, s.cognome
from socio s
where s.codS not in (select distinct r.codS
				 from ritira r, comprende c, prodotto p
				 where r.codO = c.codO and
					  c.codP = p.codP and
					  p.descrizione = 'uva');

/*nome dei soci che hanno ritirato tutte le offerte con descrizione 'uva'*/
select r.codS
from ritira r, comprende c natural join prodotto p
where r.codO = c.codO and
	 p.descrizione = 'uva'
group by r.codS
having count(distinct r.codO) = (select count(distinct c.codO)
							from comprende c natural join prodotto p
							where p.descrizione = 'uva');

	 

/*selezionare, per ogni socio, il numero di offerte ritirate che comprendono un prodotto con descrizione 'uva'*/
select r.codS, count(distinct r.codO)
from  ritira r, comprende c, prodotto p
where r.codO = c.codO and
	 c.codP = p.codP and
	 p.descrizione = 'uva'
group by r.codS;

