use coorasse;

drop table if exists produttore;
create table produttore(
	id integer not null,
	nome character(20) not null
);

insert into produttore
	values
		(1,'Neri'),
		(2,'GrandeVagina'),
		(3,'Napolitano'),
		(4,'Berlusconi'),
		(5,'Prodi');

drop table if exists prodotto;
create table prodotto(
	id integer not null,
	nome character(20) not null
);

insert into prodotto
	values
		(1,'Fisica'),
		(2,'Matematica'),
		(3,'Culologia');

drop table if exists produzione;
create table produzione(
	idTore integer not null references produttore(id),
	idOtto integer not null references prodotto(id)
);

insert into produzione
	values
		(1,1),
		(2,1),
		(2,2),
		(2,3),
		(3,3),
		(4,3),
		(5,2),
		(5,1);
/*selezionare gli id dei produttore che producono piu della meta dei prodotti*/
select distinct i.idTore
from produzione i
group by i.idTore
having count(distinct i.idOtto) > (select count(p.id)/2
						   from prodotto p);

/*selezionare gli id distinti dei produttori che producono almeno un prodotto prodotto anche da 4*/
select distinct i1.idTore
from produzione i1, produzione i2
where i2.idTore = 4 and
	 i1.idOtto = i2.idOtto and
	 i1.idTore != 4
order by i1.idTore asc;


/*id dei produttori che producono almeno due prodotti*/

