use coorasse;
drop table if exists docente;

create table docente(
	cfDoc character(16) not null,
	nome character(20) not null,
	cognome character(20) not null
);

insert into docente
	values
		('1','DocMario','Neri'),
		('2','DocMaria','GrandeVagina'),
		('3','Giorgio','Napolitano'),
		('4','Silvio','Berlusconi'),
		('5','Rumeno','Prodi');



drop table if exists studente;
create table studente(
	cfStud character(16) not null,
	nome character(20) not null,
	cognome character(20) not null
);

insert into studente
	values
		('1','Mario','Rossi'),
		('2','Maria','Grandi'),
		('3','Giorgio','Napolitano'),
		('4','Silvio','Berlusconi'),
		('5','Tina','Rumena');

drop table if exists argomento;
create table argomento(
	codArg integer not null,
	descrizione text
);

insert into argomento
	values
		(1,'Fisica'),
		(2,'Matematica'),
		(3,'Culologia');

drop table if exists lezione;
create table lezione(
	codArg integer not null references argomento(codArg),
	data date,
	cfDoc character(16) references docente(cfDoc),
	numStud integer not null
);


insert into lezione
	values
		(1,'2004-07-19','1',30),
		(2,'2004-07-19','2',30),
		(3,'2005-02-20','1',30);

drop table if exists interrogazione;
create table interrogazione(
	codArg integer not null references lezione(codArg),
	data date references lezione(data),
	cfStud character(16) references studente(cfStud),
	voto integer not null
);


insert into interrogazione
	values
		(1,'2004-07-19','1',30),
		(1,'2008-08-19','4',30),
		(1,'2008-08-19','5',30),
		(2,'2008-07-19','2',18),
		(3,'2005-02-20','3',20);

#selezionare codice fiscale, nome e cognome degli studenti che non sono mai stati interrogati in 'Fisica'
select *
from studente s
where not exists (select *
		  from interrogazione i, argomento a
		  where s.cfStud = i.cfStud and
		  i.codArg = a.codArg and
		  a.descrizione = 'Fisica');

#selezionare il cf del docente che ha svolto lezione su tutti gli argomenti con descrizione 'Fisica'

select d.cfDoc
from docente d
where d.cfDoc in (select l.cfDoc
		    from argomento a natural join lezione l
		    where d.cfDoc = l.cfDoc and
			  a.descrizione = 'Fisica');

/*codice fiscale del docente che ha sempre interrogato in ogni lezione
codice fiscale del docente per il quale NON ESISTE una lezione per la quale NON ESISTE una interrogazione
Il docente che ci interessa non e' tra i risultati della select annidata al primo livello.
nella select al primo livello seleziono le lezioni per le quali non esiste una interrogazione nella stessa data sullo stesso argomento (nelle quali non sono state fatte interrogazioni).
*/

select distinct l1.cfDoc
from lezione l1		
where not exists (select *
			   from lezione l2
			   where l1.cfDoc = l2.cfDoc and
					not exists ( select *
							   from interrogazione i
							   where l2.data = i.data and
								    l2.codArg = i.codArg));

/*selezionare, per ogni argomento, la media dei voti degli studenti interrogati su quell'argomento, considerando solo quelli interrogati almeno 3 volte*/
select i.codArg, avg(i.voto)
from interrogazione i
where 3 <= (select count(*)
		  from interrogazione i2
		  where i.codArg = i2.codArg and
			   i.cfStud = i2.cfStud)
group by i.codArg;

/*slezionare, per ogni studente, il codice fiscale del docente con cui ha fatto piu interrogazioni*/
select i1.cfStud, l.cfDoc
from interrogazione i1, lezione l
where i1.codArg = l.codArg and
	 i1.data = l.data
group by i1.cfStud, l.cfDoc
having count(*) >= all (select count(*)
				    from lezione l, interrogazione i2
				    where l.codArg = i2.codArg and
						l.data = i2.data and
						i1.cfStud = i2.cfStud
				    group by i2.cfStud, l.cfDoc);


