drop database if exists coorasse;
create database coorasse;
use coorasse;

drop table if exists campo;
drop table if exists tennista;
drop table if exists incontro;

create table campo(
	codC integer not null,
	tipo character(20),
	indirizzo character(20)
);

insert into campo values
	(1,'erba','San Vitale'),
	(2,'mais','San Vitale'),
	(3,'asfalto','San Felice'),
	(4,'terra','San Felice'),
	(5,'erba','San Felice'),
	(6,'erba','Dio'),
	(7,'erba','Mah');

create table tennista(
	codT integer not null,
	nome character(20),
	nazione character(20)
);

insert into tennista values
	(1,'','italia'),
	(2,'','italia'),
	(3,'','francia'),
	(4,'','germania'),
	(5,'','romania');

create table incontro(
	codI integer not null,
	codC integer not null references campo(codC),
	codG1 integer references tennista(codT),
	codG2 integer references tennista(codT),
	set1 integer,
	set2 integer
);

insert into incontro values
	(1,1,5,2,4,6),
	(2,2,1,5,7,6),
	(3,3,4,5,3,6),
	(4,4,1,3,6,1),
	(5,5,4,2,6,4),
	(6,6,1,2,7,6),
	(7,1,2,5,6,4);

/*selezionare gli incontri disputati sull'erba*/
select distinct i.codI
from incontro i natural join campo c
where c.tipo = 'erba';

/*selezionare i campi in erba in cui non c'e' mai stato alcun incontro*/
select c.codC
from campo c
where c.tipo = 'erba' and 
	 c.codC not in (select distinct i.codC
				 from incontro i);				 

/*selezionare i dati dei giocatori vincitori almeno una volta sull'erba*/
select *
from tennista t
where t.codT in (select i.codG1
			  from incontro i natural join campo c
			  where c.tipo = 'erba' and
		 	  i.set1 > i.set2)
	 or
	 t.codT in (select i.codG2
			  from incontro i natural join campo c
			  where c.tipo = 'erba' and
			  i.set1 < i.set2);

/*selezionare le nazioni i cui giocatori hanno tutti, sempre, vinto*/
/*selezionare le nazioni in cui non c'e' un giocatore che abbia perso almeno una volta*/
select distinct t1.nazione
from tennista t1
where t1.codT not in (select i.codG1
			   	   from incontro i
				   where i.set1 < i.set2) or
	  t1.codT not in (select i.codG2
			   	   from incontro i
				   where i.set1 > i.set2);

/*select distinct t1.nazione
from tennista t1
where t1.nazione not in (select t2.nazione
			   	   from incontro i join tennista t2 on
						i.codG1 = t2.codT
				   where i.set1 < i.set2) or
	 t1.nazione not in (select t2.nazione
			   	   from incontro i join tennista t2 on
						i.codG2 = t2.codT
				   where i.set1 > i.set2);
*/

/*selezionare il campo in erba che ha ospitato il maggior numero di incontri*/
select c.codC, count(i.codI) as NumeroIncontri
from incontro i natural join campo c
where c.tipo = 'erba'
group by c.codC
having count(i.codI) >=all (select count(i.codI) 
						from incontro i natural join campo c
						where c.tipo = 'erba'
						group by c.codC);
