drop database if exists coorasse;
create database coorasse;
use coorasse;

drop table if exists operatore;
create table operatore (
		codO integer not null,
		nome character(20)
);

drop table if exists articolo;
create table articolo (
		codA integer not null,
		descrizione text
);

drop table if exists lotto;
create table lotto (
		codA integer references articolo(codA),
		codO integer references operatore(codO),
		num integer
);

drop table if exists reclamo;
create table reclamo (
		codA integer references articolo(codA),
		codO integer references operatore(codO),
		numE integer not null,
		nome character(20)
);

/*codice e nome degli operatori per i quli non vi e' alcun reclamo, ovvero nessun esemplare di nessu lotto ha ricevuto un reclamo*/
select o.*
from operatore o
where not o.codO not in (select distinct r.codO
			   		from reclamo r);

/*nome di quel cliente che ha reclamato tutti gli opeartori*/
/*cliente per il quale non esiste operatore che non esista tra i reclamati*/
select r1.nome
from reclamo r1
where not exists (select *
			   from operatore o
			   where not exists (select *
							 from reclamo r2
							 where r2.codO = o.codO and
								  r1.nome = r2.nome));

/*selezionare, per ogni articolo, il codice dell'operatore che ha confezionato il lotto con il maggior numero di esemplari*/
select l.codA, l.codO
from lotto l
where l.num is not null and
	 l.num >= all (select l2.num
				from lotto l2
				where l2.codA = l.codA and
					 l2 is not null);

/*selezionare il lotto che ha ricevuto piu reclami*/
select codA, codO
from reclamo r1
group by codA, codO
having count(*) >= all (select count(*)
				    from reclamo r1
				    group by codA, codO);
