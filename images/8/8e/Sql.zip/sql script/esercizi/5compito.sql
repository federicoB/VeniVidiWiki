use coorasse;

drop table if exists treno;
drop table if exists tratta;
drop table if exists viaggi;

create table treno (
	id integer not null,
	vagoni integer,
	posti integer
);

insert into treno values
	(1,2,4),
	(2,4,8),
	(3,6,7),
	(4,5,6),
	(5,80,800);

create table tratta (
	id integer references treno(id),
	partenza character(20),
	arrivo character(20),
	km integer
);

insert into tratta values
	(1,'Bologna','Napoli',600),
	(2,'Bologna','Forli',75),
	(3,'Forli','Faenza',10),
	(4,'Bologna','Firenze',120),
	(5,'Faenza','Firenze',70);

create table viaggi (
	idcliente integer not null,
	idtreno integer references treno(id),
	data integer
);

insert into viaggi values
	(1,3,1995),
	(1,5,1995);
/*per ogni destinazione, ricavare il minimo numero di chilometri necessari ad arrivarvi partendo da bologna senza cambiare*/
select t.arrivo, min(t.km) as MinKm
from tratta t
where partenza = 'Bologna'
group by t.arrivo;

/*ricavare il minimo numero di kilometri per andare da Forli a Firenze effettuando un solo cambio*/
/*N.B. Questo treno esiste davvero, si parte da Forli, si cambia Faenza e si prende il "trenino" che passa per le montagne e arriva a Firenze, si risparmia denaro ma non tempo*/
select min(t1.km + t2.km) as MinKm
from tratta t1, tratta t2
where t1.arrivo = t2.partenza and
	 t1.partenza = 'Forli' and
	 t2.arrivo = 'Firenze';

/*id dei coienti che nel 1995 hanno viaggiato da Forli a Firenze effettuando un solo cambio*/
select  v1.idcliente
from viaggi v1, viaggi v2, tratta t1, tratta t2
where v1.data = 1995 and
	 v2.data = 1995 and
	 v1.idcliente = v2.idcliente and
	 t1.arrivo = t2.partenza and
	 t1.partenza = 'Forli' and
	 t2.arrivo = 'Firenze' and
	 v1.idtreno = t1.id and
	 v2.idtreno = t2.id;
