use coorasse;
drop table if exists impiegati;
create table impiegati(
	codImp integer not null,
	nomeImp character(20) not null,
	qualifica character(20)
);

drop table if exists progetti;
create table progetti(
	codProg integer not null,
	nomeProg character(20) not null
);


drop table if exists collabora;
create table collabora(
	codImp integer references impiegati(codImp),
	codProg integer references progetti(codProg),
	mesiUomo integer not null
);


insert into impiegati
	values
		(1,'Mario','Amministrazione'),
		(2,'Andrea','Produzione'),
		(3,'Anna','Amministrazione'),
		(4,'Franco','Distribuzione'),
		(5,'Filippo','Direzione'),
		(6,'Luigi','Direzione'),
		(7,'Olga','Amministrazione'),
		(8,'Sergio','Produzione');


/*restituire nome e qualifica degli impiegati che non collaborano a nessun progetto*/
select i.nomeImp, i.qualifica
from	impiegati i
where not exists (select *
			   from collabora c
			   where c.codImp = i.codImp);

drop table impiegati;
drop table collabora;
drop table progetti;

/*
.
.
*/

drop table if exists forniture;
create table forniture(
	marca character(20) not null,
	nomeForn character(20) not null
);

drop table if exists computer;
create table computer(
	codComputer integer not null,
	marca character(20) not null references forniture(marca),
	modello character(20)
);

insert into computer values
	(1,'Apple','A'),
	(2,'Apple','B'),
	(3,'Apple','C'),
	(4,'Apple','D'),
	(5,'Apple','E');

drop table if exists software;
create table software(
	codSoftware integer not null,
	nome character(20),
	tipo character(20)

);

insert into software values
	(1,'OpenOffice','Word processor'),
	(2,'MicrosoftOffice', 'Word processor'),
	(3,'Culodritto', 'Inculatoio');

drop table if exists installazioni;
create table installazioni(
	codComputer integer not null references computer(codComputer),
	codSoftware integer not null references software(codSoftware), 
	dataInst date
);

insert into installazioni values
	(1,1,'1996-01-01'),
	(2,1,'1996-01-01'),
	(3,1,'1997-01-01'),
	(4,1,'1995-03-01'),
	(5,1,'1999-01-01'),
	(1,2,'1998-01-01');

/*per ogni marca fornita da 'Rossi', il numero di software distinti installati nel 1994*/

select f.marca, count(distinct i.codSoftware)
from installazioni i, forniture f, computer c
where f.nomeForn = 'Rossi' and
      (i.dataInst between '1994-01-01' and '1994-12-31') and
      i.codComputer = c.codComputer and
      f.marca = c.marca
group by f.marca;


/*selezionare i nomi dei software di tipo 'Word Processor' che contano almeno 5 installazioni posteriori al 1/1/95 su computer di marca Apple*/
select s.nome
from software s natural join installazioni i natural join computer c
where s.tipo = 'Word processor' and
	 i.dataInst > '1995-01-01' and
	 c.marca = 'Apple'
group by s.codSoftware
having count(i.dataInst) > 4;

drop table computer;
drop table installazioni;
drop table forniture;
drop table software;

/*
.
.
*/

drop table if exists professori;
create table professori(
	prof character(20) not null,
	citta character(20) not null,
	dipartimento character(20) not null
);

drop table if exists corsi;
create table corsi(
	corso character(20) not null,
	prof character(20) references professori(prof)
);

drop table if exists studenti;
create table studenti(
	studente character(20) not null,
	corso character(20) references corsi(corso)
);

/*in quali citta vivono i professori dei corsi seguiti da Rossi?*/
select distinct p.citta
from professori p, corsi c
where p.prof = c.prof and
      c.corso in (select s.corso
      		  from studenti s
		  where c.corso = s.corso and
		  	s.studente = 'Rossi');

/*
.
.
*/

drop table if exists farmaci;
create table farmaci (
	codF integer not null,
	nome char(20) not null,
	prezzo integer
);

insert into farmaci
	values
		(1,'Cocaina',90),
		(2,'Erba',10),
		(3,'Fumo',6),
		(4,'Ecstasy',15);

drop table if exists principiattivi;
create table principiattivi (
	codP integer not null,
	descrizione text
);

insert into principiattivi
	values
		(1,'thc'),
		(2,'barbiturici'),
		(3,'anfetamina');

drop table if exists contiene;
create table contiene (
	codF integer not null references farmaci(codF),
	codP integer not null references principiattivi(codP),
	quantita float not null
);

insert into contiene
	values
		(1,2,0.5),
		(2,1,0.4),
		(3,1,0.7),
		(4,3,0.2);

drop table if exists incompatibili;
create table incompatibili (
	codP1 integer not null references principiattivi(codP),
	codP2 integer not null references principiattivi(codP),
	grado float not null
);

insert into incompatibili
	values
		(1,2,1),
		(3,1,2),
		(2,3,0.1);
/*selezionare, per ogni principio attivo, il minimo tra i prezzi dei farmaci
 che contengono di quel principio attivo una quantita' pari ad almeno 0.1 mg*/
select * from contiene;

select c.codP, min(f.prezzo)
from contiene c natural join farmaci f
where c.quantita > 0.1
group by c.codP;			

/*aumenta del 10 per cento il prezzo di tutti i farmaci che contengano thc*/
update farmaci f
set prezzo = prezzo*1.10
where codF = (select distinct f.codF
			from contiene c, principiattivi p
			where p.descrizione = 'thc' and
				 f.codF = c.codF and
				 p.codP = c.codP);
select * from farmaci;

/*selezionare le coppie di descrizioni di principi attivi incompatibili sopra lo 0.5*/
select p1.descrizione, p2.descrizione
from principiattivi p1, incompatibili i, principiattivi p2
where
	p1.codP = i.codP1 and
	p2.codP = i.codP2 and
	i.grado > 0.5;


drop table farmaci;
drop table principiattivi;
drop table incompatibili;
drop table contiene;

/*
.
.
*/

drop table if exists incassi;
create table incassi (
	film character(20),
	anno integer,
	incasso integer
);

insert into incassi 
	values
	('viacolvento',1980,70),
	('viacolculo',1995,40),
	('viaconlanonna',1995,50),
	('viacolvia',1995,30);

drop table if exists casst;
create table casst (
	film character(20) references incassi(film),
	attore character(20)
);

insert into casst
	values
	('viacolvento','De niro'),
	('viacolculo','Proietti'),
	('viaconlanonna','De niro'),
	('viacolvia','Mia nonna'),
	('viaconlanonna','Mia nonna');

/*selezionare per ogni attore che ha partecipato almeno a due film, il massimo incasso registrato tra tutti i film in cui ha partecipato nel 1995*/

select s.attore, max(i.incasso)
from casst s natural join incassi i
where 1 < (select count(c.film)
		 from casst c
		 where s.attore = c.attore) and
	i.anno = 1995
group by s.attore;	

drop table casst;
drop table incassi;


/*
.
.
*/

drop table if exists clienti;
create table clienti (
	codCliente integer,
	nome character(20)
);

insert into clienti values
	(1,'Mario');

drop table if exists vhs;
create table vhs (
	codCopia integer,
	codTitolo integer
);

insert into vhs values
	(1,1),
	(2,2),
	(3,3);

drop table if exists titoli;
create table titoli (
	codTitolo integer,
	titolo character(20),
	genere character(20),
	regista character(20),
	durata integer	
);

insert into titoli values
	(1,'Indiana Jones','Avventura','George',180),
	(2,'Shriek','Comico','Michael',190),
	(3,'Le comiche','Comico','Michael',150),
	(4,'Vacanze','Comico','Teddy',90);

drop table if exists prestiti;
create table prestiti (
	codCliente integer,
	codCopia integer,
	data integer
);

insert into prestiti values
	(1,1,1999),
	(1,2,1997),
	(1,3,1998),
	(2,3,2001);

/*nome dei clienti che hanno almeno tre prestiti dopo  il 1996*/
select c.nome
from prestiti p join clienti c on
	p.codCliente = c.codCliente
where p.data > 1996
group by p.codCliente
having count(p.data) > 2;

/*selezionare, per ogni regista che ha girato almeno 2 film comici, la durata media di tutti i suoi film in catalogo*/
drop view if exists RegistiAlmenoDueComici;
create view RegistiAlmenoDueComici as 
select t.regista as regista
from titoli t
where t.genere = 'Comico'
group by t.regista
having count(*) >= 2;

select t.regista, avg(t.durata)
from titoli t, RegistiAlmenoDueComici r
where t.regista = r.regista
group by t.regista;

/*cancellare tutti i prestiti prima del 2000 del genere comico*/
delete from prestiti
where data < 2000 and
	 codCopia in (select v.codCopia
				   from vhs v,titoli t
				   where v.codTitolo = t.codTitolo and
				   t.genere = 'Comico');

select * from prestiti;
select * from titoli;


drop view RegistiAlmenoDueComici;
drop table prestiti;
drop table vhs;
drop table titoli;
drop table clienti;

/*
.
.
*/

drop table if exists clienti;
drop table if exists conti;
drop table if exists possiede;
drop table if exists transazioni;

/*selezionare le transazioni dell'ultimo mese peri clienti che hanno saldo totale negativo*/

select cl.codCli
from clienti cl natural join possiede p natural join conti co
group by cl.codCli
having sum(co.saldo) < 0;

/*prelevare 1.000.000 dal conto 8456*/
insert into transazioni(numConto,data,tipo,ammontare) values
	(8456,today(),'prelievo',1000000);
update conti
set saldo = saldo -1000000
where numConto = 8456;
