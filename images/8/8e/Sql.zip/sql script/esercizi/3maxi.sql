use coorasse;
drop table if exists quadro;
create table quadro(
	codQ integer not null,
	autore character(20) not null,
	periodo character(20)
);

insert into quadro
	values
		(1,'Picasso','La guernica'),
		(2,'Mario',''),
		(3,'Napolitano',''),
		(4,'Picasso','La guernica parte 2'),
		(5,'Garibaldi','I mille'),
		(6,'Mariolina','Le marionette');


drop table if exists mostra;
create table mostra(
	codM integer not null,
	nome character(20) not null,
	anno integer not null,
	organizzatore character(20)
);

insert into mostra
	values
		(1,'Napoli',1997,'Nizza'),
		(2,'Da casa di mia nonna',1981, 'a quella della tua'),
		(3,'Norimberga',2016,'Katmandu'),
		(4,'Firenza',2006,'Roma'),
		(5,'Milano',2007,'Yorkshire');

drop table if exists espone;
create table espone(
	codM integer not null references mostra(codM),
	codQ integer not null references quadro(codQ),
	sala character(20) not null
);

insert into espone
	values
		(1,1,'Sala 1'),
		(1,2,'Sala Quadri'),
		(1,3,''),
		(1,4,''),
		(1,5,''),
		(1,6,''),
		(2,3,'Sala salata'),
		(3,3,'Sala 4'),
		(4,4,'Sala merda');


/*selezionare le sale nelle quali, nel 1997, e' stato esposto un quadro di picasso*/
select e.sala
from mostra m natural join espone e natural join quadro q
where q.autore = 'Picasso' and
	 m.anno = 1997;

/*selezionare tutti i dati dei quadri di picasso mai esposti nel 1997*/
select q.*
from mostra m natural join espone e natural join quadro q
where q.autore = 'Picasso' and
	 m.anno <> 1997;

/*selezionare tutti i dati dei quadri che non sono mai stati esposti assieme a quadri di Picasso
 i codici delle mostre in cui e' stato esposto un quadro di picasso e' P[codM](espone join S[autore='Picasso'](quadro))
 i codici dei quadri esposti in queste mostre li ottengo con un ulteriore join a espone
 i codici di quelli mai mostrati in queste mostre li ottengo con una esclusione dei precedenti dal totale*/
select q1.*
from quadro q1
where q1.codQ not in (select e2.codQ
					 from quadro q2 natural join espone e1, espone e2
					 where q2.autore = 'Picasso' and
						  e1.codM = e2.codM);

/*mostre nelle quali sono stati esposti quadri di almeno cinque autori distinti*/
select m1.codM
from mostra m1
where 5 <= (select count(distinct q.autore)
		  from espone e natural join quadro q
		  where m1.codM = e.codM);

/*selezionare, per ogni mostra, l'autore di cui si esponeva il maggior numero di quadri
 eseguo il join di quadro ed espone, quindi raggruppo per mostra e autori ottenendo la lista delle mostre con tutti gli autori presenti.*/

select e1.codM, autore
from quadro q1 natural join espone e1
group by e1.codM, q1.autore
having count(*) >= all (select count(*)
				    from quadro q2 natural join espone e2
				    where e1.codM = e2.codM);
