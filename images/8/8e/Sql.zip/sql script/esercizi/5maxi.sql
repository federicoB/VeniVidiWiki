drop database if exists coorasse;
create database coorasse;
use coorasse;

drop table if exists via;
drop table if exists incrocio;

create table via(
	codV integer not null,
	nome character(20),
	quartiere character(20),
	lunghezza integer
);

insert into via values
	(1,'Rizzoli','San Vitale',10),
	(2,'Ugo Bassi','San Vitale',20),
	(3,'Pratello','San Felice',5),
	(4,'Felice','San Felice',6),
	(5,'Paradiso','San Felice',6),
	(6,'figa','Dio',20);

create table incrocio(
	codV1 integer references via(codV),
	codV2 integer references via(codV),
	numero integer
);

insert into incrocio values
	(1,2,1),
	(5,4,1),
	(5,3,1),
	(6,1,1),
	(6,2,1);

/*selezionare le vie che incrociao almeno una via del quartire San Vitale*/
select distinct v1.nome
from via v1
where v1.codV in (select i.codV1
			   from incrocio i, via v2
			   where i.codV2 = v2.codV and
				 v2.quartiere = 'San Vitale') or
	v1.codV in (select i.codV2
			   from incrocio i, via v2
			   where i.codV1 = v2.codV and
				 v2.quartiere = 'San Vitale');

/*selezionare le vie che incrociano Via Rizzoli*/
select distinct v1.nome
from via v1
where v1.codV in (select i.codV1
			   from incrocio i, via v2
			   where i.codV2 = v2.codV and
				 v2.nome = 'Rizzoli') or
	v1.codV in (select i.codV2
			   from incrocio i, via v2
			   where i.codV1 = v2.codV and
				 v2.nome = 'Rizzoli');

/*selezionare le coppie di codici di vie con la stessa lunghezza (restituisce doppi risultati!)*/
select v1.codV as Via1, v2.codV as Via2
from via v1, via v2
where v1.lunghezza = v2.lunghezza and
	 v1.codV <> v2.codV;

/*selezionare il quartiere con piu vie*/
select v1.quartiere, count(v1.codV) as NumeroVie
from via v1
group by v1.quartiere
having count(v1.codV) >= all (select count(v2.codV)
						from via v2
						group by v2.quartiere);

/*selezionare la via piu lunga di ogni quartiere*/
select v1.quartiere, v1.nome
from via v1
where v1.lunghezza = (select max(v2.lunghezza) as LunghezzaMaggiore
				  from via v2
				  where v2.codV = v1.codV)
group by v1.quartiere;

/*selezionare le vie che incrociano tutte le vie del quartiere San Vitale*/
/*selezionare le vie che non capita che non incrocino una via del quartiere san vitale*/
select v1.nome
from via v1
where not exists (select *
			   from via v2
			   where v2.quartiere = 'San Vitale' and
					not exists ( select *
							   from incrocio i
							   where (v1.codV = i.codV1 and v2.codV = i.codV2) or 
								    (v1.codV = i.codV2 and v2.codV = i.codV1)));
