use coorasse;

drop table if exists gara;
drop table if exists giocatore;
drop table if exists partecipa;

create table gara(
	codM integer not null,
	nomecampo character(20),
	livello character(20)
);

create table giocatore(
	codG integer not null,
	nome character(20),
	nazione character(20)
);

/*una gara e' vinta dal giocatore con il punteggio piu basso*/
create table partecipa(
	codM integer references gara(codM),
	codG integer references giocatore(codG),
	punteggio integer
);

/*selezionare i gicoatori che hanno disputato almeno una gara a livello nazionale*/

select distinct gi.*
from giocatore gi natural join partecipa p natural join gara ga
where ga.livello = 'nazionale';

/*selezionare le nazioni in cui tutti i giocatori hanno ottenuto un punteggio minore o uguale a zero nelle gare disputate*/
select g1.nazione
from giocatore g1
where not exists (select *
			   from giocatore g2 natural join partecipa p
			   where g1.nazione = g2.nazione and
				    p.punteggio > 0);

/*selezionare i giocatori che hanno partecipato a tutte le gare a livello nazionale*/
select p1.*
from giocatore p1
where not exists (select *
			   from gara g2
			   where g2.livello = 'nazionale' and
				not exists (select *
						  from partecipa p2
						  where p1.codG = p2.codG and
							   g2.codM = p2.codM				   
			  ));

/*selezionare i dati dei giocatri che hanno vinto almeno una gara a livello nazionale*/
select distinct gi.*
from giocatore gi natural join partecipa p natural join gara ga
where ga.livello = 'nazionale' and
	 p.punteggio <= all (select p2.punteggio
					 from partecipa p2
					 where p.codM = p2.codM);
					);

