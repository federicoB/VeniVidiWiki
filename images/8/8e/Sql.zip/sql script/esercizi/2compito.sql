use coorasse;
drop table if exists studente;
create table studente(
	cfStud character(16) not null,
	nome character(20) not null,
	cognome character(20) not null
);

insert into studente
	values
		('1','Mario','Rossi'),
		('2','Maria','Grandi'),
		('3','Giorgio','Napolitano'),
		('4','Silvio','Berlusconi'),
		('5','Tina','Rumena');

drop table if exists argomento;
create table argomento(
	codArg integer not null,
	descrizione text
);

insert into argomento
	values
		(1,'Fisica'),
		(2,'Matematica'),
		(3,'Culologia');

drop table if exists esame;
create table esame(
	codArg integer not null references argomento(codArg),
	cfStud character(16) references studente(cfStud),
	voto integer not null
);


insert into esame
	values
		(1,'1',18),
		(2,'2',28),
		(3,'1',28),
		(3,'2',17),
		(3,'3',14),
		(2,'3',28),
		(2,'4',29),
		(1,'5',17),
		(1,'5',19);
		

/*nome e cognome  degli studenti il cui voto e' sopra la media del voto di tutti gli studenti, o al piu uguale*/
select s.nome, s.cognome
from esame e natural join studente s
where e.voto >= (select avg(e2.voto)
			 from esame e2);

/*id degli argomenti il cui esame e' stato superato da almeno la meta degli studenti iscritti*/



/*id degli argomenti il cui esame e' stato superato da almeno la meta degli studenti che lo hanno frequentato*/
select e.codArg
from esame e
where e.voto >= 18
group by codArg
having count(e.voto) >= (select count(e2.voto)/2
				    from esame e2
				    where e.codArg = e2.codArg);

/*cognomi distinti degli studenti che non hanno mai preso meno di 27 in un corso che inizia per M*/

select distinct s.cognome
from argomento a natural join esame e natural join studente s
where 
	a.descrizione like 'M%' 
group by s.cfStud
having min(e.voto) >= 27;

/*id degli studenti che hanno preso meno di 27 una sola volta*/
select e.cfStud
from esame e
where e.voto < 27
group by e.cfStud
having count(e.voto) = 1;
