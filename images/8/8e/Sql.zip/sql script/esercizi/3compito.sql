use coorasse;
drop table if exists giocatore;
create table giocatore(
	cfGioc character(16) not null,
	cognome character(20) not null,
	eta integer not null
);

insert into giocatore
	values
		('1','Mario',20),
		('2','Maria',30),
		('3','Giorgio',25),
		('4','Silvio',28),
		('5','Tina',29);

drop table if exists partita;
create table partita(
	codPart integer not null,
	avversario character(20),
	data date
);

insert into partita
	values
		(1,'Fisica',2007-19-02),
		(2,'Matematica',2007-18-04),
		(3,'Culologia',2007-23-08);

drop table if exists giocata;
create table giocata(
	codPart integer not null references partita(codPart),
	cfGioc character(16) references giocatore(cfGioc),
	numeromaglia integer not null
);


insert into giocata
	values
		(1,'1',18),
		(2,'2',28),
		(3,'1',28),
		(3,'2',17),
		(3,'3',14),
		(2,'3',28),
		(2,'4',29),
		(1,'5',17),
		(1,'5',19);

/*selezionare le partite con giocatori di almeno 3 eta differenti*/
select g.codPart
from giocata g natural join giocatore t
group by g.codPart
having count(distinct t.eta) > 2;

/*tutti i dati dei giocatori che non hanno mai giocato con 'Mario'*/
select t.*
from giocatore t
where t.cfGioc not in (select g1.cfGioc
					from giocata g1
					where g1.codPart in
					(select distinct g2.codPart
	from giocata g2 natural join giocatore t
	where t.cognome = 'Mario'));

