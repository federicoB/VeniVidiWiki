use coorasse;

drop table if exists manifestazione;
drop table if exists luogo;
drop table if exists spettacolo;

create table manifestazione (
	codM integer not null,
	nome character(20)
);

create table luogo (
	nomel character(20),
	citta character(20)
);

create table spettacolo (
	codM integer references manifestazione(codM),
	num integer,
	ora integer,
	nomel character(20) references luogo(nomel),	
	data integer
);

insert into spettacolo values
	(1,1,16,'Casa',2001),
	(2,2,17,'Casa',2001),
	(3,3,18,'Casa',2001),
	(1,1,16,'Rebibbia',2002),
	(2,2,17,'Rebibbia',2002),
	(3,3,18,'Rebibbia',2003),
	(1,1,13,'Cicileo',2002),
	(1,2,17,'Cicileo',2002),
	(1,3,18,'Cicileo',2003);


/*codice e nome delle manifestazioni che non sono mai state svolte a Modena*/
select m1.*
from manifestazione m1
where m1.codM not in (select s.codM
			   	  from spettacolo s natural join luogo l
				  where l.citta = 'Modena'
			  	 );

/*nomi dei luoghi che hanno ospitato tutte le manifestazioni*/
select distinct s.nomel
from spettacolo s
where not exists (select *
  			   from manifestazione m
			   where not exists (select *
							 from spettacolo s2
							 where s2.codM = m.codM and
								  s.nomel = s2.nomel
			  				 )
			   );

/*nome dei luoghi che ospitano piu di tre spettacoli dopo le 15 nella stessa data*/
select s.nomel
from spettacolo s 
where s.ora > 15
group by s.nomel, s.data
having count(*) >= 3;

/*selezionare per ogni luogo il numero Totale delle manifestazioni e quello degli spettacoli ospitati*/
select s.nomel, count(*) as NumeroSpettacoli, count(distinct s.codM) as NumeroManifestazioni
from spettacolo s
group by s.nomel;

/*selezionare il codice delle manifestazioni i cui spettacoli incominciano tutti dopo le 15*/
select distinct s1.codM
from spettacolo s1
where s1.codM not in (select s2.codM
			   from spettacolo s2
			   where s2.ora < 15);
