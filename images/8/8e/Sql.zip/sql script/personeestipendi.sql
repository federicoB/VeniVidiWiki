drop database if exists terzo;
create database if not exists terzo;
use terzo;
drop table if exists impiegato;
create table impiegato(
	Nome character(10) not null,
	Cognome character(10) not null,
	Dipartimento character(15),
	Ufficio integer,
	Reddito integer
);
drop table if exists dipartimento;
create table dipartimento(
	Nome	character(15)  not null references persone(Nome),
	Indirizzo character(20),
	Citta	character(10) not null references persone(Nome)
);


#inserimento
insert into impiegato (Nome,Cognome,Dipartimento,Ufficio, Reddito)
	values
		('Mario','Rossi','Amministrazione',10,45),
		('Andrea','Bianchi','Produzione',20,36),
		('Anna','Verdi','Amministrazione',20,40),
		('Franco','Neri','Distribuzione',16,45),
		('Filippo','Rossi','Direzione',14,80),
		('Luigi','Lanzi','Direzione',7,73),
		('Olga','Borroni','Amministrazione',75,null),
		('Sergio','Franco','Produzione',20,29);

#inserimento
insert into dipartimento (Nome,Indirizzo,Citta)
	values
		('Amministrazione','via tito livio','Milano'),
		('Produzione','P.zza Lavater', 'Torino'),
		('Distribuzione','Via segre','Roma'),
		('Direzione','via tito livio','Milano');

select * from impiegato;
select * from dipartimento;

#seleziona quelli che fanno Rossi di cognome
#si tratta di una selezione senza proiezione
select *
from impiegato
where Cognome = 'Rossi';

#seleziona i nomi e cognomi di una tabella
#si tratta di una proiezione senza selezione
select Nome,Cognome
from impiegato;

#stipendio mensile di Filippo
#esempio di ridenominazione tramite as
#ed espressione nella target list
select Reddito/12 as RedditoMensile
from impiegato
where Nome = 'Filippo';

#disgiunzione
#espressione nella clausula where
select Nome,Cognome
from impiegato
where Dipartimento = 'Amministrazione' or
	 Dipartimento = 'Produzione';

#condizione un po piu complessa
#quelli di cognome rossi che lavorano in amm o in prod
select Nome
from impiegato
where Cognome = 'Rossi' and 
	 (Dipartimento = 'Amministrazione' or Dipartimento = 'Produzione' );

#condizione like
#quelli che hanno il cognome con la 'o' in seconda posizione e la i finale
#_ indica un carattere qualsiasi, % una stringa di lunghezza variabile
select Cognome
from impiegato
where Cognome like '_o%i';



#stampa la citta in cui lavora ciascun dipendente

select impiegato.Cognome, dipartimento.Citta
from impiegato, dipartimento
where impiegato.Dipartimento = dipartimento.Nome;

#join esplicito
select I.nome, I.cognome, D.Citta
from impiegato I join dipartimento D on
	I.Dipartimento = D.Nome;


#gestione dei valori  null
#impiegati che hanno o potrebbero avere uno stipendio minore di 50
select *
from impiegato
where Reddito < 50  or 
	 Reddito is null;

#eliminare i duplicati
select distinct Cognome
from impiegato;


#ordinare i risultati
select Cognome, Nome, Reddito
from impiegato
where Dipartimento like '%uzione'
order by Reddito desc, Cognome desc;


#operatori aggregati
#numero di dipendenti
select count(*) as NumeroImpiegati
from impiegato;

#non conta i null
select count(Reddito) as NumeroRedditi
from impiegato;

select count(distinct Reddito) as NumeroRedditiDiversi
from impiegato;

#somma, massimo, medio e minimo
#totale degli stipendi nel dipartimento aministrazione
select sum(Reddito) as SommaRedditiAmministrazione
from impiegato
where Dipartimento = 'Amministrazione';

#lo stipendio massimo tra gli impiegati che lavorano a Milano
select max(Reddito) as RedditoMassimoaMilano
from impiegato join dipartimento
 on impiegato.Dipartimento = dipartimento.Nome
where dipartimento.Citta = 'Milano';

#scorretta
#select Cognome, impiegato.Nome, max(Reddito)
#from impiegato,dipartimento
#where Dipartimento = dipartimento.Nome and
#      Citta = 'Milano';

#operatori aggregati
#la somma degli stipendi di ciascun dipartimento
select impiegato.Dipartimento, sum(impiegato.Reddito) as sommaRedditi
from impiegato
group by impiegato.Dipartimento;

#condizioni sui gruppi, clusula having
#dipartimenti che spendono piu di 100 milioni in stipendi
select impiegato.Dipartimento, sum(impiegato.Reddito) as sommaRedditi
from impiegato
group by impiegato.Dipartimento	
having sum(impiegato.Reddito) > 100;

#i dipartimenti per cui la media degli stipendi degli impiegati che lavorano nell'ufficio 20 e' superiore a 25
select impiegato.Dipartimento
from impiegato
where impiegato.Ufficio = 20
group by Dipartimento
#fin qui ho raggruppato per dipartimento tutti quelli che lavorano negli uffici numero 20
having avg(impiegato.Reddito) > 25;

#unioni
#i duplicati vengono rimossi automaticamente!!! (bisogna utilizzare union all)
select Nome
from impiegato
union
select Cognome as Nome
from impiegato
order by Nome;

#operazioni nidificate
#impiegati che lavorano a milano
select *
from impiegato
where Dipartimento = any (
	select Nome
	from dipartimento
	where Citta = 'Milano');


#l impiegato con lo sipendio massimo
select *
from impiegato
where Reddito = (select max(Reddito)
		 from impiegato);

select * from impiegato;
#diamo un aumento del 10% a tutti quelli dell amministrazione
update impiegato set Reddito = Reddito * 1.1
where Dipartimento = 'Amministrazione';


#approccio sbagliato (voglio prma dare un aumento a quelli con lo stipendio minore di 30 e poi anche agli altri)
#sergio franco riceve due aumenti!!
#update impiegato set Reddito = Reddito * 1.1
#where Reddito < 30;
#update impiegato set Reddito = Reddito * 1.1
#where Reddito > 30;

select * from impiegato;


