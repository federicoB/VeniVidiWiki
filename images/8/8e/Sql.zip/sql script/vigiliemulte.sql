drop database if exists primaprova;		/*ricorda il punto e virgola e le condizioni*/
create database if not exists primaprova;
use primaprova;

drop table if exists infrazioni;
create table infrazioni(
	Codice		character(6) primary key,
	Data		date not null,
	Vigile		integer not null references vigili(Matricola),
	Provincia	character(2),
	Numero		character(6) 
);

drop table if exists vigili;
create table vigili(
	Matricola	character(3) primary key,
	Cognome		character(10),
	Nome		character(10)
);

insert into infrazioni (Codice, Data, Vigile, Provincia , Numero) 
	values	
		('10' , '12/02/08' , '343' , 'FC' , '112'),
		('20' , '12/04/07' , '476' , 'FO' , '1334' );

insert into vigili (Matricola, Nome, Cognome)
	values
		('343', 'Rossi' , 'Mario'),
		('476' , 'Neri' , 'Pino'),
		('548' , 'Bruni' , 'Carlo');


select Codice,Provincia from infrazioni;
select *  from infrazioni;
select vigili.Nome from vigili, infrazioni where vigili.Matricola = infrazioni.Vigile	/*seleziona i nomi di chi ha fatto multe*/
