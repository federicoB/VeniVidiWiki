drop database if exists secondo;
create database if not exists secondo;
use secondo;
drop table if exists persone;
create table persone(
	Nome character(10) not null,
	Eta integer,
	Reddito integer
);
drop table if exists maternita;
create table maternita(
	Madre	character(10)  not null references persone(Nome),
	Figlio	character(10) not null references persone(Nome)
);
drop table if exists paternita;
create table paternita(
	Padre	character(10) not null references persone(Nome),
	Figlio	character(10) not null references persone(Nome)
);
insert into persone (Nome, Eta, Reddito)
	values
		('Andrea', 27, 21),
		('Aldo' , 25, 15),
		('Maria', 55, 42),
		('Anna',50,35),
		('Filippo',26,30),
		('Luigi',50,40),
		('Franco',60,20),
		('Olga',30,41),
		('Sergio',85,35),
		('Luisa',75,87);

insert into paternita (Padre,Figlio)
	values
		('Sergio','Franco'),
		('Luigi','Olga'),
		('Luigi','Filippo'),
		('Franco','Andrea'),
		('Franco','Aldo');

insert into maternita (Madre,Figlio)
	values
		('Luisa','Maria'),
		('Luisa','Luigi'),
		('Anna','Olga'),
		('Anna','Filippo'),
		('Maria','Andrea'),
		('Maria','Aldo');

select * from persone;
select * from paternita;
select * from maternita;

#nome e reddito delle persone con meno di 30 anni
select Nome,Reddito
from persone
where Eta < 30;

#stipendio mensile di Filippo
select Reddito/12 as RedditoMensile
from persone
where Nome = 'Filippo';

#i padri di persone che guadagnano piu di 20 milioni
#attenzione, la clausula distinct per eliminare i duplicati e costosa

select distinct paternita.Padre
from paternita, persone
where paternita.Figlio = persone.Nome and
	 persone.Reddito > 20;

#join naturale
#padre  e madre di ogni persona
select paternita.Figlio,  paternita.Padre, maternita.Madre
from paternita, maternita
where paternita.Figlio = maternita.Figlio;

#join esplicito
#padre  e madre di ogni persona
select paternita.Figlio, paternita.Padre, maternita.Madre
from maternita join paternita on
	paternita.Figlio = maternita.Figlio;

select paternita.Figlio, paternita.Padre, maternita.Madre
from maternita natural join paternita;

#outer join
#padre e, se nota, madre di ogni persona

select paternita.Figlio, Padre, Madre
from paternita natural left join maternita;

select paternita.Figlio, Padre, Madre
from paternita left join maternita on
	paternita.Figlio = maternita.Figlio;


#persone che guadagnano piu del padre
select f.Nome,f.Reddito,p.Reddito as RadditoPadre
from persone p, persone f, paternita
where paternita.Padre = p.Nome and
	 paternita.Figlio = f.Nome and
	 f.Reddito > p.Reddito;

#differenza
#select Nome
#from persone
#except
#select Cognome as Nome
#from persone;


#nome e reddito del padre di Franco
select Nome,Reddito
from persone
where Nome = (	select Padre
		from paternita
		where Figlio = 'Franco');

select p.Nome,p.Reddito
from persone p, paternita f
where p.Nome = f.Padre and
      f.Figlio = 'Franco';

#nome e reddito dei padri di persone che guadagnano piu di 20 milioni
select Nome,Reddito
from persone
where Nome in ( select Padre
		from paternita
		where Figlio =any (select Nome
				   from persone
			      	   where Reddito > 20));

select distinct p.Nome,p.Reddito
from persone p, persone f, paternita
where p.Nome = paternita.Padre and
      paternita.Figlio = f.Nome and
      f.Reddito > 20;

#persone che hanno almeno un figlio
select *
from persone
where exists (select *
		from paternita
		where paternita.Padre = persone.Nome) or
      exists (select *
		from maternita
		where maternita.Madre = persone.Nome);


/*i padri i cui figli guadagnano tutti piu di 20 milioni o
 i padri che non hanno fligli che guadagnano meno di 20 milioni
 la select piu interna restituisce tutte le persone che hanno figli che guadagnano meno di 20*/
select distinct a.Padre
from paternita a
where not exists (select *
		  from persone p, paternita w
		  where p.Nome = w.Figlio and
			p.Reddito < 20 and
			w.Padre = a.Padre);


