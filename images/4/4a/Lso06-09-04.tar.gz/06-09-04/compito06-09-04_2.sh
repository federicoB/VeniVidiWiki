#!/bin/bash
#
#Esercizio 2 ("Grep a tre lettere") (8 punti)
#Scrivere uno script che prende in input (da linea di comando) una stringa e una lista di file; lo script deve
#riportare il numero di occorrenze di tutte le sottosequenze di tre lettere della stringa nei file cercati. Ad esempio,
#se la stringa cercata è windows, lo script deve riportare un output del tipo:
#win 7
#ind      12
#ndo 13
#dow 14
#ows 5

SIZE=3
string=$1
shift
list=$*
length=`expr length $string`
if [ $length -le 2 ]
then
	echo Stringa di almeno tre caratteri
	exit 1
fi

let "length = length - SIZE + 1"
from=1

while [ ! $from -gt $length ]
do
	sum=0
	string_2=`expr substr "$string" $from $SIZE`
	for file in $list
	do
		if [ -f $file ]
		then
			add=`awk '{ for (i = 1 ; i <= NF ; i++) print $i }' $file | grep --count $string_2`
			let "sum += add"
		fi
	done
	echo $string_2 $sum
	let "from +=1"
done

