/*Esercizio 1 (“Pachinko”) (24 punti) (*)
Scrivete un programma che crei un albero binario di processi di altezza N. 
Si noti che il processo "padre originale" non fa parte dell'albero. 
Ad ognuno dei nodi foglia viene associato un valore numerico, scelto casualmente fra 0 e 1000.
Il processo padre genera un segnale, che spedisce al suo unico figlio. 
I processi dell'albero si comportano nel modo seguente: 
nodi non foglia: aspettano un segnale dal genitore e inoltrano il segnale ad uno dei loro figlio, scelto casualmente
nodi foglia: stampano un messaggio che dice "hai vinto la quantità x!", dove x è il valore associato al nodo. 
Dopo di che, inviano un segnale di "risposta" al loro genitore, che viene propagato fino al nodo padre.
Una volta ricevuto il segnale di risposta, il nodo padre riprende a giocare da capo.*/

#include <sys/stat.h>
#include <sys/types.h>
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
#include <string.h>

#define TREE_H 5
#define PIPENUM (1 << TREE_H) /*number of pipes that must be opened for communication between processes*/
#define LEAFNUM (1 << (TREE_H -1))	/*number of leaf in the tree*/
#define NODENUM (PIPENUM - LEAFNUM - 1)	/*number of node (not leaf) in the tree*/

int pipes_read[PIPENUM -1][2];	/*read from children fds*/
int pipes_write[PIPENUM -1][2]; /*write to children fds*/	
/*N.B. pipes_write[x][0] is used by processes to read from parent*/

int signal = 1;	 /*the signal*/

void write_father(int callpid, int * signal) {
	int fd = callpid - 1;	/*father's id*/
	if (write(pipes_read[fd][1], signal, sizeof(int)) < 0)
		printf("write to father error: mypid = %d\n", callpid);
}

void write_child_r(int callpid, int * signal) {
	int fd = 2 * callpid - 1;
	if (write(pipes_write[fd][1], signal, sizeof(int)) < 0)
		printf("write to right child error: mypid = %d\n", callpid);
}

void write_child_l(int callpid, int * signal) {
	int fd = 2 * callpid;
	if (write(pipes_write[fd][1], signal, sizeof(int)) < 0)
		printf("write to left child error: mypid = %d\n", callpid);
}

void read_father(int callpid, int * signal) {
	int fd = callpid - 1;
	if ((read(pipes_write[fd][0], signal, sizeof(int))) < 0)
		printf("read from father error: mypid = %d\n", callpid);
}

void read_child_r(int callpid, int * signal) {
	int fd = 2 * callpid - 1;
	if (read(pipes_read[fd][0], signal, sizeof(int)) < 0)
		printf("read from right child error: mypid = %d\n", callpid);
}

void read_child_l(int callpid, int * signal) {
	int fd = 2 * callpid;
	if (read(pipes_read[fd][0], signal, sizeof(int)) < 0)
		printf("read from left child error: mypid = %d\n", callpid);
}

void close_unused_pipes(int id) {
	close(pipes_read[id-1][0]);	/*chiude in lettura la pipe su cui scrive al padre*/
	close(pipes_write[id-1][1]);	/*chiude in scrittura la pipe con cui legge dal padre*/
	close(pipes_read[(2*id) - 1][1]);	/*chiude in scrittura la pipe di lettura col figlio sinistro*/
	close(pipes_read[2*id][1]);
	close(pipes_write[(2*id) - 1][0]);
	close(pipes_write[2*id][0]);
}

void build_tree(int id) {
	int pid_r, pid_l;
	int myid = id;
	int r_id = myid*2 +1;
	int l_id = myid*2;
	int signal;
	int choose;
	if (id <= NODENUM) {
		printf("building node number %d:\n", myid);
		fflush(stdout);
		if (	(pipe(pipes_read[2*id - 1]) < 0) || 
			(pipe(pipes_read[2*id])) || 
			(pipe(pipes_write[2*id - 1])) || 
			(pipe(pipes_write[2*id])))
		perror("pipe error");
		
		if ((pid_r = fork()) < 0)	
			perror("fork error");
		else if (pid_r > 0) {
			if ((pid_l = fork()) < 0)	
				perror("fork error");
			else if (pid_l > 0) {	/*that's me NODE*/
				close_unused_pipes(myid);

				srandom(getpid());
				while (1) {
					read_father(myid, &signal);	/*wait for signal from father*/
					choose = random() % 2;
					printf("Me (%d) choosed to send signal %d to %d\n",myid,signal,choose);
					fflush(stdout);
					if (choose) {	/*choose to wich process send it and wait for signal to come back*/
						write_child_r(myid, &signal);
						read_child_r(myid,&signal);
					}
						else {
						write_child_l(myid, &signal);
						read_child_l(myid,&signal);
					}
					write_father(myid,&signal);	/*write the signal back to father*/
				}
			}
			else {			/*that's left child*/
				build_tree(l_id);
			}
		}
		else {				/*that's right child*/
			build_tree(r_id);
		}
	}
	else if (id < PIPENUM) {		/*that's me LEAF*/
		int value;
		printf("building leaf number %d\n", id);
		fflush(stdout);
		close(pipes_read[id-1][0]);
		close(pipes_write[id-1][1]);
		if (myid == (PIPENUM -1 )) {
			printf("going for signal..\n");
			write(pipes_read[0][1],&signal,sizeof(int));
		}
		srandom(getpid());	/*initialize random facilities*/
		while(1) {
			value= random() % 1001;
			read_father(myid,&signal);
			printf("%d won %d\n", myid, value);
			printf("sending back signal\n");
			fflush(stdout);
			write_father(myid,&signal);
		}
	}
}




int main() {
	int pid, mypid;
	int height;
	height = TREE_H;
	mypid = 0;
	if ((pipe(pipes_read[mypid]) < 0) || (pipe(pipes_write[mypid]) < 0))
		perror("pipe error");
	

	if ((pid = fork()) < 0)
		perror("fork error");
	else if (pid > 0) {	//processo padre

	close(pipes_read[mypid][1]);
	close(pipes_write[mypid][0]);
	while (1) {

		if (read(pipes_read[mypid][0], &signal, sizeof(int)) < 0)
			perror("read error");
		if (write(pipes_write[mypid][1],&signal,sizeof(int)) < 0)
			perror("write error");
		printf("first signal sent\n");
		fflush(stdout);
	}
	}
	else {
		printf("Hi I'm the root of the tree..starting building..\n");
		build_tree(1);
	}
}
