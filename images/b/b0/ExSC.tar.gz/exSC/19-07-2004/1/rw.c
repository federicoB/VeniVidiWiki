#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/select.h>
#include <signal.h>

#define READEND     0
#define WRITEEND    1
#define OK          1
#define REQ         0

void server(void);
void reader(int);
void writer(int);

int r2f[2], w2f[2], r2f2[2], w2f2[2];
int **f2c, N, M;
pid_t *p;
fd_set  set;

typedef struct req{
    pid_t   pid;
    int     time;
}req;


int main(int argc, char *argv[]){

    int i;
    
    if(argc!=3){
        printf("Bad number of arguments\nUsage %s nReaders nWriters\n", argv[0]);
        exit(-1);
    }

    N=atoi(argv[1]);
    M=atoi(argv[2]);
    
    if((f2c=(int **)malloc(sizeof(int *)*(N+M)))==NULL){
        printf("Error malloc-ing....\n");
        exit(0);
    }


    for(i=0; i<N+M; ++i){
        if((f2c[i]=(int *)malloc(sizeof(int)*2))==NULL){
            printf("Error malloc-ing...\n");
            exit(-1);
        }
        if((pipe(f2c[i]))<0){
            printf("Error pipe-ing...\n");
            exit(-1);    
        }
    } 
    if(pipe(r2f)<0||pipe(w2f)<0||pipe(r2f2)<0||pipe(w2f2)<0){
        printf("Error pipe-ing...\n");
        exit(-1);
    }
    
    if((p=(int *)malloc(sizeof(pid_t)*(N+M)))==NULL){
        printf("Error malloc-ing....\n");
        exit(0);
    }


    for(i=0; i<N+M; ++i)
        switch((p[i]=fork())){
            case -1:
                printf("Error forking...\n");
                exit(-1);
                break;
            case 0:
                close(f2c[i][WRITEEND]);
                if(i<N)
                    reader(i);  
                else
                    writer(i);
                exit(0);
                break;
            default:
                close(f2c[i][READEND]);
                break;
        }
    close(r2f[WRITEEND]);
    close(w2f[WRITEEND]);
    close(r2f2[WRITEEND]);
    close(w2f2[WRITEEND]);
    fcntl(r2f[READEND], F_SETFL, O_NDELAY); /*per read non bloccanti*/
    fcntl(w2f[READEND], F_SETFL, O_NDELAY); /*per read non bloccanti*/
    server();
    return 0;  
}

void server(void){
    int nr, nw, br, msg=OK, i;
    req reqR[N], reqW[M];
    
    while(1){
        nr=nw=0;
        FD_ZERO(&set);
        FD_SET(r2f[READEND], &set);
        FD_SET(w2f[READEND], &set);
        select(max(r2f[READEND], w2f[READEND])+1, &set, NULL, NULL, NULL);
        if(FD_ISSET(r2f[READEND], &set)){
            printf("********SERVER: gestisco i lettori********\n");
            while((br=read(r2f[READEND], &reqR[nr], sizeof(req)))>0)
                    ++nr;
            for(i=0;i<nr; ++i){
               printf("SERVER: do a %d la possiblità di leggere per %d\n", reqR[i].pid, reqR[i].time);
               write(f2c[findIndexFromPid(reqR[i].pid)][WRITEEND], &msg, sizeof(int)); 
            }
            printf("SERVER: Aspetto che i  lettori abbiano letto\n");
           /*sleep(getMaxTime(reqR, nr));*/
            for(i=0;i<nr; ++i)
                read(r2f2[READEND], &msg, sizeof(int));
        }
        if(FD_ISSET(w2f[READEND], &set)){
            printf("*********SERVER: gestisco gli scrittori**********\n");
            while((br=read(w2f[READEND], &reqW[nw], sizeof(req)))>0)
                    nw++;
            for(i=0; i<nw; ++i){    
                printf("SERVER: do a %d la possibilità di scrivere per %d\n", reqW[i].pid, reqW[i].time);
                write(f2c[findIndexFromPid(reqW[i].pid)][WRITEEND], &msg, sizeof(int));
                printf("Aspetto la fine della scrittura di %d per %d\n", reqW[i].pid, reqW[i].time);
                /*sleep(reqW.time);*/
                read(w2f2[READEND], &msg, sizeof(int));
            }     
        }
    }
}

void reader(int index){
    int msg;
    req r;
    r.pid=getpid();
    srand(r.pid);
    close(w2f2[WRITEEND]);
    while(1){
        r.time=random()%5+1;
        printf("[READER: %d]: Chiedo la possibilità di leggere per %d sec\n", r.pid, r.time);
        write(r2f[WRITEEND], &r, sizeof(req));
        read(f2c[index][READEND], &msg, sizeof(int));
        printf("[READER: %d]: Ho ottenuto la possibilità di leggere. Sto per leggere\n", r.pid);
        sleep(r.time); 
        write(r2f2[WRITEEND], &msg, sizeof(int));   
        printf("[READER: %d]: Ho letto\n", r.pid);
    }
}

void writer(int index){
    int msg;
    req r;
    r.pid=getpid();
    srand(r.pid);
    close(r2f2[WRITEEND]);
    while(1){
        r.time=random()%5+1;
        printf("[WRITER: %d]: Chiedo la possibilità di scrivere per %d sec\n", r.pid, r.time);
        write(w2f[WRITEEND], &r, sizeof(req));
        read(f2c[index][READEND], &msg, sizeof(int));
        printf("[WRITER: %d]: Ho ottenuto la possibilità di scrivere. Sto per scrivere\n", r.pid);
        sleep(r.time);
        write(w2f2[WRITEEND], &msg, sizeof(int));
        printf("[WRITER: %d]: Ho scritto\n", r.pid);
    }    
}

int findIndexFromPid(pid_t pid){
    int i;
    for(i=0; i<N+M; ++i)
        if(pid==p[i])
            return i;    
return 0; 
}
int getMaxTime(req *r, int limit){
    int max, i;
    max=r[0].time;
    for(i=1; i<limit; ++i)
        if(max<r[i].time)
            max=r[i].time;
    
    return max;
}
int max(int a, int b){
    return (a>=b?a:b);
}


