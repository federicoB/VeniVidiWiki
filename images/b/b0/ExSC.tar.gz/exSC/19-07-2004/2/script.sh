#!/bin/bash

while true; do
    for i in `cat $1`; do
        rights=`stat -c=%a /home/$i | sed -e 's/=//g'`
        ownerT=`stat -c=%u /home/$i | sed -e 's/=//g'`
        if [[ ( $rights -ne 700 ) && ( $rights -ne 600 ) && ( $rights -ne 500 ) ]]; then
            echo "****WARNING****"
        fi
        for j in `find /public -maxdepth 1 -type f`; do 
            owner=`stat -c=%u /home/$j | sed -e 's/=//g'`
            if [ $owner -e $ownerT ]; then
            echo ***WARNING***
            fi 
        done
    done
    sleep 30
done
