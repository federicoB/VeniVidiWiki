#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/select.h>
#include <signal.h>
#include <limits.h>

#define TOFATHER    0
#define TOCHILD     1 


void makeChild(int );

int         N, fdNamedPipe[2], val;
pid_t       child;
char        *tmpNames[2];
int main(int argc, char *argv[]){

    if(argc!=2){
        printf("Error: bad numbero of arguments\n");
        exit(-1);
    }

    N=atoi(argv[1]);

    makeChild(0);
    return 0;
}

void makeChild(int index){
    int i;
    srand(time(NULL)+getpid());
    for(i=0; i<2; ++i)
        tmpNames[i]=(char*)malloc(sizeof(char)*TMP_MAX);
    
    if(index < N-1){
        tmpNames[index%2]=NULL;
        tmpNames[index%2]=tmpnam(tmpNames[index%2]);
        mkfifo(tmpNames[index%2], 0666);
        fdNamedPipe[index%2]=open(tmpNames[index%2], O_RDWR);
    }
        
    
    printf("MyPPid: %d MyPid: %d %s\n", getppid(), getpid(), tmpNames[index%2]);
    
    if(index < N-1){
        switch(child=fork()){
            case -1:
                printf("Error forking\n");
                exit(-1);
                break;
            case 0:
                makeChild(index+1);
                exit(0);
                break;
        }        
    }

    if(index==N-1){
        val=rand()%100;
        printf("Im the last %d %d: %d\n", getpid(), index, val);
        write(fdNamedPipe[1-index%2], &val, sizeof(int));
    }
    else{
        read(fdNamedPipe[index%2], &val, sizeof(int));
        printf("Im the %d %d: %d\n", getpid(), index, val);
        if(index){
            val+=(rand()%2)?1:-1; 
            write(fdNamedPipe[1-index%2], &val, sizeof(int));
        }
        else
            printf("Im the first: %d %d: %d\n", getpid(), index, val);
    }

}


