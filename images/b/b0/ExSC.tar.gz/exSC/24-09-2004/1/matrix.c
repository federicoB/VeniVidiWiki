#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>


int main(int argc, char *argv[]){
    int N, y, x;
    if(argc!=2){
        printf("Error: wrong number of arguments\n");
        exit(-1);
    }
    N=atoi(argv[1]);
    for(y=1; y<=N; ++y){
            switch(fork()){
                case 0:
                    for(x=1; x<=N; ++x)
                        switch(fork()){
                            case 0:
                                printf("(%d %d)gent'd(%d %d)%c",
                                                    y, x, y, x-1, x!=N?' ':'\n');
                                break;
                            default:
                                wait(NULL);
                                exit(0);
                                break;
                            }
                    break;
                default:
                    wait(NULL);
                    break;
                }
        }
    printf("\n");
    return 0;
}




