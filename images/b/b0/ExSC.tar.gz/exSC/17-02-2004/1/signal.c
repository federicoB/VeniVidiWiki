#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/select.h>
#include <signal.h>

/*Non uccido alla fine il figlio ma è banale da implementare*/

void handler(int signo);
void do_receiver(void);

int iesimo, totarg;
char ch;
 
int main(int argc, char *argv[]){
    pid_t   pidrec;
    int i, j, h, len;
    if(argc<2){
        printf("Too few arguments\nUsage: %s str0 str1 str2 ... strn\n", argv[0]);
        exit(-1);
    }
    totarg=argc;
    signal(SIGUSR1, handler);
    signal(SIGUSR2, handler);
    switch((pidrec=fork())){
        case -1:
            printf("Error forking...\n");
            exit(-1);
            break;
        case 0: 
            do_receiver();
            break;
    }
    for(i=1; i<argc; ++i){
        len=strlen(argv[i]);
        for(j=0; j<=len; ++j){
            ch=argv[i][j];
            for(h=0; h<8; ++h)
                if(ch&(1<<h))
                    kill(pidrec, SIGUSR1);
                else
                    kill(pidrec, SIGUSR2);
        }
    }



return 0;
}
void do_receiver(void){
    int nargs=0;
    int     index=0;  
    char    str[256];
    sigset_t    set;
    sigfillset(&set);
    sigdelset(&set, SIGUSR1);
    sigdelset(&set, SIGUSR2);
    sigdelset(&set, SIGINT);
    
  while(1){
        sigsuspend(&set);  
        if(!(iesimo%8)){
            iesimo=0;
            str[index]=ch;
            if(!ch){
                printf("%s\n", str);
                if(++nargs==totarg)
                    exit(0);
                index=0;
                memset(str, 0, 256);
            }
            else
                index++;
            ch=0;
        }
    }
}

void handler(int signo){
    ch|=((signo==SIGUSR1)?1:0)<<(iesimo++);
}




