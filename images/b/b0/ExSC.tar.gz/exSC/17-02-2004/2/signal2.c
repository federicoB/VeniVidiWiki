#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/select.h>
#include <signal.h>

#define BITSONBYTE  8

void handler(int signo);
void do_s(pid_t, int, char **);

int     nargs=0;

int main(int argc, char *argv[]){
    sigset_t    set;
    pid_t       toSend;
 
    if(argc<2){
        printf("Too few arguments\nUsage: %s str0 str1 str2 ... strn\n", argv[0]);
        exit(-1);
    }
    
    signal(SIGUSR1, handler);
    signal(SIGUSR2, handler);

    switch((toSend=fork())){
        case -1:
            printf("Error forking...\n");
            exit(-1);
            break;
        case 0:
            toSend=getppid();
            do_s(toSend, argc, argv);
            break;
        default:
            do_s(toSend, argc, argv);
            break;
    }
    sigfillset(&set);
    sigdelset(&set, SIGUSR1);
    sigdelset(&set, SIGUSR2);
    sigdelset(&set, SIGINT);
    while(nargs!=(argc-1))
       sigsuspend(&set);

return 0;
}

void do_s(pid_t toSend, int argc, char **argv){
    int i, j, h, len;
    char c; 
    for(i=1; i<argc; ++i){
        len=strlen(argv[i]);
        for(j=0; j<=len; ++j){
            c=argv[i][j];
            for(h=0; h<BITSONBYTE; ++h){
                if(c&(1<<h))
                    kill(toSend, SIGUSR1);
                else
                    kill(toSend, SIGUSR2);
            
                    sigsuspend(&set);
            }
        }
    }
}

void handler(int signo){
    static  char    str[256],   ch=0;
    static  int     index=0,    iesimo=0;
    ch|=((signo==SIGUSR1)?1:0)<<(iesimo++);
    if(!(iesimo%BITSONBYTE)){
            iesimo=0;
            str[index]=ch;
            if(!ch){
                printf("%d: %s\n", getpid(), str);
                ++nargs;
                index=0;
                memset(str, 0, 256);
            }
            else
                index++;
            ch=0;
        }
}

