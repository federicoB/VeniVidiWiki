#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/select.h>


int main(int argc, char *argv[]){
    
    pid_t   pid;
    int     pidIn;


    pid=-1;
    pidIn=atoi(argv[1]);    
    while(1){
        switch(pid=fork()){
            case -1:
                printf("Error forking\n");
                exit(-1);
                break;
            case 0:
                if(getpid()==pidIn)
                    printf("My pid is %d\n", getpid());
                exit(0);
                break;
            default:
                if(pid!=pidIn){
                    waitpid(-1, NULL, 0);
                    continue;
                }
                else
                    exit(0);
        }
    }

return 0;
}



