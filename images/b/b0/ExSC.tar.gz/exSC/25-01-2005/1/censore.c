#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/select.h>

#define BUFFER  1024

int main(int argc, char *argv[], char *env[]){

    pid_t   pid;
    int     pipeFd[2], i, br;
    fd_set  set;
    char    buf[BUFFER];

    if (argc!=4){
        printf("Too few arguments....\n");
        printf("Usage: %s [strPattern] [fullpathofcommand] [file]\n", argv[0]);
        printf("Ex. %s ciaociao /bin/cat prova\n");
        exit(-1);
    }



    if(pipe(pipeFd)<0){
        printf("Error pipe-ing\n");
        exit(-1);
    }
    switch(pid=fork()){
        case -1:
                printf("Error forking\n");
                exit(-1);
                break;
        case 0:
                close(pipeFd[0]);
                dup2(pipeFd[1], STDOUT_FILENO);
                execve(argv[2], &(argv[2]), &(env[0]));
                break;
        default:
                while(1){
                    memset(buf, 0, BUFFER);
                    FD_ZERO(&set);
                    FD_SET(pipeFd[0], &set);
                    select(pipeFd[0]+1, &set, NULL, NULL, NULL);
                    br=read(pipeFd[0], buf, BUFFER);
                    for(i=0; i<br; ++i){
                        if(!(strncmp(argv[1], buf+i, strlen(argv[1])))){
                                memset(buf+i, ' ', strlen(argv[1]));
                                i+=strlen(argv[1])-1;
                        }
                    } 
                    write(STDOUT_FILENO, &buf, strlen(buf));
                    break;
            }
    }
    return 0;
}



