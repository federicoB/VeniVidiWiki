#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/select.h>

#define     SASSO   0
#define     FORBICI 1
#define     CARTA   2
#define     ARBITER 0
#define     PLAYER1 1
#define     PLAYER2 2

typedef struct punto{
    pid_t pid;
    int val;
}punto;

void play(int index);

int     NTURNI, fdNPipe[3], arbiter;
char    tmpName[3][TMP_MAX];


int main(int argc, char **argv){

    int i;
    
    if(argc!=2){
        printf("Error: bad number of arguments\n");
        exit(-1);
    }        
    
    NTURNI=atoi(argv[1]);

    for(i=0; i<3; ++i){
        tmpnam(tmpName[i]);
        mkfifo(tmpName[i], 0600);
        fdNPipe[i]=open(tmpName[i], O_RDWR);
    }    

    for(i=0; i<3; ++i){
        switch(fork()){
            case -1:
                perror("Fork-ing...\n"); 
                exit(-1);
                break;
            case 0:
                play(i);
                exit(0);
                break;
        }
    }
    return 0;
}

void play(int index){
    int f;
    punto myscore, score[3];
    myscore.pid=getpid();
    srand(time(NULL)+myscore.pid);
    while(1){
        myscore.pid=getpid();
        if(index==arbiter){
            read(fdNPipe[arbiter], &score[0], sizeof(punto));
            read(fdNPipe[arbiter], &score[1], sizeof(punto));
            if(rand()%2)//da sostituire con un findWinner corretto qui facciamo a caso...
                memcpy(&score[2], &score[0], sizeof(punto));
            else
                memcpy(&score[2], &score[1], sizeof(punto));
            
            write(fdNPipe[(arbiter+1)%3], &score[2], sizeof(punto));
            write(fdNPipe[(arbiter+2)%3], &score[2], sizeof(punto));
        }
        else{
            myscore.val=rand()%3;
            write(fdNPipe[arbiter], &myscore, sizeof(punto));
            read(fdNPipe[index], &myscore, sizeof(punto));
            if(myscore.pid==getpid())
                printf("%d Ho vinto (arbiter %d)\n", index, arbiter);
            else
                printf("%d Ho perso (arbiter %d)\n", index, arbiter);
        }    
        arbiter=(arbiter+1)%3;
        sleep(1);
    }
}


