#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/select.h>
#include <signal.h>
#include <limits.h>

#define     READEND     0
#define     WRITEEND    1


int N;

pid_t   child;
int     pipeFd[2][2], pipeFd2[2][2];

void    go(int);

int main(int argc, char *argv[]){
    int i;    
    if(argc!=2){
        printf("Error: bad number of arguments\n");
        exit(-1);
    }
    
    N=atoi(argv[1]);
    for(i=0; i<2; ++i)
            if((pipe(pipeFd[i])<0)||(pipe(pipeFd2[i])<0)){
                perror("Pipe-ing: ");
                exit(-1);
            }
    --N;
    go(0);
    return 0;
}

void go(int index){
    int val=1;
    if(index)
        if((pipe(pipeFd[index%2])<0)||(pipe(pipeFd2[index%2])<0)){
            perror("Pipe-ing: ");
            exit(-1);
            }
    
    if(index<N){
        switch(child=fork()){
            case -1:
                perror("fork: ");    
                exit(0);
                break;
            case 0:
                go(index+1);
                break;
            default:
                read(pipeFd[index%2][READEND], &val, sizeof(int));
                printf("%d %d\n", index, val);
                if(index){
                    write(pipeFd[1-index%2][WRITEEND], &val, sizeof(int)); 
                    read(pipeFd2[1-index%2][READEND], &val, sizeof(int));
                    printf("%d %d\n", index, val);
                    write(pipeFd2[index%2][WRITEEND], &val, sizeof(int));
                    waitpid(-1, NULL, 0);
                }
                else{ 
                    val++;
                    printf("%d %d\n", index, val);
                    write(pipeFd2[index%2][WRITEEND], &val, sizeof(int));
                    waitpid(-1, NULL, 0);              
                }
                break;
        }    
    }
    else{
        printf("%d %d\n", index, val);
        write(pipeFd[1-(index%2)][WRITEEND], &val, sizeof(int));
        read(pipeFd2[1-index%2][READEND], &val, sizeof(int)); 
        printf("%d %d\n", index, val);
    }
}



