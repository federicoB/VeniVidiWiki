#!/bin/bash



for i in `find $1 -name "*.java"`; do
    sino=`grep -i copyright $i`
    if [ $sino == "" ]; then
        cp $i "$i.bak"
        cat $2 > $i
        cat "$i.bak" >> $i
    fi
done
