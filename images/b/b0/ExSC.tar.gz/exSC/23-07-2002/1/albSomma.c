#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/select.h>
#include <signal.h>


#define READEND     0
#define WRITEEND    1 
#define CHILDDX     0
#define CHILDSX     1


void makeChild(int flag, int h);
void do_node(int);
int     N;
int     pipeF2SX[2][2], pipeF2DX[2][2], im;
pid_t   child[2];

int main(int argc, char *argv[]){
    
    if(argc!=2){
        printf("Error: bad number of arguments.\nEx: %s N\n", argv[0]);
        exit(0);
    }

    N=atoi(argv[1]);

    do_node(0);
    return 0;
}

void do_node(int level){
    int index=level%2, val, somma;
    
    pipe(pipeF2SX[index]);
    pipe(pipeF2DX[index]);
    if(level<N){
        makeChild(CHILDSX, level+1);
        makeChild(CHILDDX, level+1);
    }
    srand(time(NULL)+getpid());
    if(level==N){
        val=rand()%10;
        printf("Foglia level=%d val=%d\n", level, val);
        if(im)
            write(pipeF2SX[1-index][WRITEEND], &val, sizeof(int));
        else
            write(pipeF2DX[1-index][WRITEEND], &val, sizeof(int));
    }
    else {
        read(pipeF2SX[index][READEND], &val, sizeof(int));
        somma=val;
        read(pipeF2DX[index][READEND], &val, sizeof(int));
        somma+=val;    
        if(level){
            printf("Node level=%d val read %d\n", level, somma);
            if(im)
                write(pipeF2SX[1-index][WRITEEND], &somma, sizeof(int));
            else
                write(pipeF2DX[1-index][WRITEEND], &somma, sizeof(int));
        }
        else
            printf("%d somma %d\n", level, somma);
    }
}

void makeChild(int flag, int level){
    int *fptr;
    fptr=(flag==CHILDDX)? &child[CHILDDX]: &child[CHILDSX];
    
    switch(*fptr=fork()){
        case -1:
            perror("Forking...\n");
            exit(0);
            break;
        case 0:
            im=flag;
            do_node(level);
            exit(0);
            break;
        default:
            break;
    }
}



