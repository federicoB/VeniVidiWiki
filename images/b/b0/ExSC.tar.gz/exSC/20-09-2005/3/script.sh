#!/bin/bash

find "$1" -print0 | 
    while read -d $'\0' line; do  
    echo "${#line} $line"; 
    done | sort  -n | cut -d" " -f1 --complement
