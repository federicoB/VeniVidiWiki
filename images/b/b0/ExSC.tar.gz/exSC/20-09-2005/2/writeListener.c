#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/select.h>


#define BUFFER  1024

int main(int argc, char *argv[]){

    int fifoToListen, fifoToWrite;
    char fromStdin[BUFFER], fromTmp[BUFFER];
    fd_set set;
    
    if(argc!=3){
        printf("Bad Namber of arguments\nUsage:\n%s \
                    fifoToReadFrom fifoToWriteTo\n", argv[0]);
        exit(-1);
    }

    


    if(((fifoToListen=open(argv[1],O_RDWR|O_NONBLOCK))<0)||
                 (fifoToWrite=open(argv[2], O_RDWR|O_NONBLOCK))<0){
                         printf("error\n");
                         exit(-1);
    }
    while(1){
        FD_ZERO(&set);
        FD_SET(fifoToListen, &set);  
        FD_SET(0, &set);

        select(fifoToListen+1, &set, NULL, NULL, NULL);
        
        if(FD_ISSET(0, &set)){
            memset(fromStdin, 0, BUFFER);
            read(0, &fromStdin, BUFFER);
            write(fifoToWrite, &fromStdin, strlen(fromStdin));        
        }
        
        if(FD_ISSET(fifoToListen, &set)){
            memset(fromTmp, 0, BUFFER);
            read(fifoToListen, &fromTmp, BUFFER);
            write(1, &fromTmp, strlen(fromTmp));
        }
        
    }

    return 0;
}


