#include <stdio.h>
#include <stdlib.h>
#include <signal.h>

/*Il programma prende in input il pid del processo
 * mittente. E ogni qualvolta quest'ultimo gli spedisce
 * un segnale lui glielo rispedisce*/

void handler(int signo, siginfo_t *siginfo, void *arg);

int main(void){
    int i;
    sigset_t mask;
    struct sigaction act;
    sigfillset(&mask);
    for(i=0; i<32; ++i){
        sigdelset(&mask, i);
        act.sa_handler=NULL;
        act.sa_restorer=NULL;
        act.sa_sigaction=handler;
        act.sa_flags=SA_SIGINFO;
        sigaction(i, &act, NULL); 
    }
    printf("My pid is %d\n", getpid());   
    while(1)
        sigsuspend(&mask);
    
    return 0;
}


void handler(int signo, siginfo_t *siginfo, void *arg){
    kill(siginfo->si_pid, siginfo->si_signo);
}

