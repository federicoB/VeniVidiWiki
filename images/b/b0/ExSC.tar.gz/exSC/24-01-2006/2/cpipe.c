#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

int main(int argc, char *argv[]){
    
    int nCmd=0, i, j, k;
    int **pipeFd;
    pid_t   pid;

    if(argc<2){
        printf("Error: too few parameters\n");
        exit(-1);
    }
    for(i=0; i<argc; ++i)
        if(!strncmp(argv[i], "}", strlen(argv[i])))
            nCmd++;
    
    if((pipeFd=calloc(nCmd, sizeof(int *)))==NULL){
        printf("Error calloc-ing...\n");
        exit(-1);
    }
    
    for(i=0; i<nCmd; ++i){
        if((pipeFd[i]=calloc(2, sizeof(int )))==NULL){
            printf("Error calloc-ing...\n");
            exit(-1);
        }
    }

    for(i=0; i<nCmd; i+=2)
        if(pipe(pipeFd[i])<0){
            printf("Error creating %d° pipe\n", i);
            exit(-1);
        }
    
    for(i=0,k=0, j=1; i<argc; ++i)
        if(!strncmp(argv[i], "}", strlen(argv[i]))){
            argv[i][0]='\0';
        
            if((pid=fork())<0){
                printf("Error forking\n");
                exit(-1);
            }
            else if(!pid){
                if((dup2(pipeFd[(k+1)%nCmd][1], STDOUT_FILENO))<0 || 
                        (dup2(pipeFd[k][0], STDIN_FILENO))<0){
                    printf("Error dup2-ing...\n");
                    exit(-1);
                }
                execvp(argv[j],argv+j);
                printf("Error: Maybe command %s not found\n", argv[j]);
            }
            else{
                j=i+1;
              	k+=1;
              	}
        }
     
return 0; 
}



