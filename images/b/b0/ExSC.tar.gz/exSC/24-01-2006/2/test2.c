#include <stdio.h>
int main(void){
        char str[5];
        scanf("%s", str);
        printf("%s\n", str);
        return 0;
}
