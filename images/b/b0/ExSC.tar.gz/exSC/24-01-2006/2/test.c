#include <stdio.h>
int main(int argc, char *argv[]){
    char str[5];
    fflush(stdout);
    sleep(4);
    printf("ciao\n");
     
    scanf("%s", str);
    fprintf(stderr, "STDERR %s\n", str);
    
    }
