#!/bin/bash

a=$1
b=$2
c=$3


cd $a

for i in "$(find $a -type d )"; do
    echo ./$c$i
    mkdir -p ./$c$i
done




