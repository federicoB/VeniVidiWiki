#!/bin/bash
file=$1
shift
for i in $*; do
     
    awk 'BEGIN{min=1000000000} \
                {if (max<$'$i') max=$'$i'; if(min>$'$i') min=$'$i'; media+=($'$i')/$NL;} \
         END{printf("'$i': Min: %d Max: %d Avg: %f\n", min, max, media);}'  $file
    
    shift
done



