#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/select.h>
#include <signal.h>
#include <sys/time.h>
#include <time.h>

#define     PROBTODIE   20

void usage(char *);
void handler(int, siginfo_t *, void *);
void do_child();
void childHandler(int, siginfo_t*, void *);
int N;
pid_t   *childs;
struct itimerval    timeInfo;
struct sigaction    action;
sigset_t            set;


int main(int argc, char *argv[]){

    int     i;

    if(argc!=2){
        usage(argv[0]);
        exit(-1);
    }
    N=atoi(argv[1]);
    childs=(pid_t *)malloc(sizeof(pid_t) * N); 
    
    sigfillset(&set);
    sigaddset(&set, SIGCHLD);
    sigaddset(&set, SIGUSR1);
    sigaddset(&set, SIGALRM);
    sigprocmask(SIG_BLOCK, &set, NULL);
 
    for(i=0; i< N; ++i){
        switch((childs[i]=fork())){
            case -1:
                printf("Error forking %d° child\n");
                exit(-1);
                break;  
            case 0:
                do_child();
                break;
        }
    }
    

    /*gestione timer*/
    timeInfo.it_interval.tv_sec =   1;
    timeInfo.it_interval.tv_usec=   0;  
    timeInfo.it_value.tv_sec    =   1;
    timeInfo.it_value.tv_usec   =   0;

    action.sa_sigaction         =   handler;
    action.sa_flags             =   SA_SIGINFO;
    sigfillset(&action.sa_mask);

    sigaction(SIGUSR1, &action, NULL);
    sigaction(SIGALRM, &action, NULL);
    sigaction(SIGCHLD, &action, NULL);    

    sigfillset(&set);
    sigdelset(&set, SIGUSR1);   /*risposta figlio*/
    sigdelset(&set, SIGALRM);   /*tick: devochiamare i figli*/
    sigdelset(&set, SIGCHLD);   /*un figlio è morto*/

    sigdelset(&set, SIGINT);   /*un figlio è morto*/



    setitimer(ITIMER_REAL, &timeInfo, NULL);   

    while(1)
        sigsuspend(&set);


    return 0;
}


void handler(int signo, siginfo_t *info, void *arg){
    static int nDied=0;
    int    i;
    switch(signo){
        case SIGUSR1:
            break;
        case SIGALRM:
            for (i=0; i<N; ++i)
                if(childs[i]!=0){
                    printf("\nIl padre invia un segnale a %d\n", childs[i]);
                    kill(childs[i], SIGUSR1);
                }
            break;
        case SIGCHLD:
            nDied++;
            if(nDied==N)
                exit(0);
            
            for(i=0; i<N; ++i)
                if(childs[i]==info->si_pid){
                       printf("\nIl figlio %d è morto\n", childs[i]);
                       childs[i]=0;
                }
                    
            break;    
            
    }

}

void do_child(void){

    timeInfo.it_interval.tv_sec =   1;
    timeInfo.it_interval.tv_usec=   0;
    timeInfo.it_value.tv_sec    =   1;
    timeInfo.it_value.tv_usec   =   0; 

    action.sa_sigaction         =   childHandler;

    sigaction(SIGUSR1, &action, NULL);
    sigaction(SIGALRM, &action, NULL);
 

    sigfillset(&set);
    sigdelset(&set, SIGUSR1);   /*devo rispondere al padre*/
    sigdelset(&set, SIGALRM);   /*tick: devo decidere se vivere o morire*/

    setitimer(ITIMER_REAL, &timeInfo, NULL);

    while(1)
        sigsuspend(&set);

}

void childHandler(int signo, siginfo_t *l, void *r){
    int p;
    switch(signo){
        case SIGUSR1:
                    printf("\nIo sono il figlio %d e invio un segnale a mio padre %d\n", 
                                                                                getpid(), getppid());
                    kill(getppid(), SIGUSR1);
                    break;
        case SIGALRM:
                    srand(time(NULL));
                    p=rand()%100+1;
                    if(p<PROBTODIE){
                       printf("\nIo figlio %d ho deciso di morire\n", getpid()); 
                       exit(0);
                    }
                    printf("\nIo figlio %d ho deciso di continuare a vivere\n", getpid());
            break;
    }

}

void usage(char *str){
    printf("%s [nProc]\n", str);
}



