#!/bin/bash
MD5SUMLENGTH=33
for i in $*; do 

    find $i -type f -exec md5sum {} \; | sort| uniq -d -w$MD5SUMLENGHT> log

done


