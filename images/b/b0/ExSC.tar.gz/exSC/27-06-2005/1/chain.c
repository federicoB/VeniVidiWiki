#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/select.h>
#include <signal.h>
#include <sys/time.h>

#define READEND     0
#define WRITEEND    1

void do_child(int index);
void genParticle(int signo);
int     **pipeFd, N;
int main(int argc, char *argv[]){
    int  i;
    pid_t       pid;
    sigset_t    set;
    struct      itimerval timerInfo;
    if(argc!=2 || atoi(argv[1])<=5){
        printf("Error. Usage: %s [nProc>5]\n", argv[0]);
        exit(-1);
    } 
    N=atoi(argv[1]);
    if((pipeFd=(int **)malloc(sizeof(int *)*N))==NULL){
        printf("Error allocating mem\n");
        exit(-1);
    }
    for(i=0; i<N; ++i)
     if((pipeFd[i]=(int *)malloc(sizeof(int)*2))==NULL){
        printf("Error allocating mem\n");
        exit(-1);
    }

    for(i=0; i<N; ++i)
        if((pipe(pipeFd[i]))<0){
            printf("Error pipe-ing...\n");
            exit(-1);    
        }

    close(pipeFd[0][READEND]);    
    for(i=1; i<N; ++i){
    
        switch((pid=fork())){
            case -1:
                printf("Error forking\n");
                exit(-1);
                break;
            case 0:
                break;
            default:
                do_child(i);
                break;
        }
    
    }

    signal(SIGALRM, genParticle);
    
    timerInfo.it_interval.tv_sec=1;
    timerInfo.it_interval.tv_usec=0;
    timerInfo.it_value.tv_sec=1;
    timerInfo.it_value.tv_usec=0;
    setitimer(ITIMER_REAL, &timerInfo, NULL);
    while(1){
        sigfillset(&set);
        sigdelset(&set, SIGALRM);
        sigdelset(&set, SIGINT);
        sigsuspend(&set);
    }
    return 0;
}
void genParticle(int signo){
    unsigned int    nprtc;
    srand(time(NULL));
    nprtc=rand()%1000+1;
    printf("Emitter: generated %d particles\n", nprtc);
    write(pipeFd[1][WRITEEND], &nprtc, sizeof(unsigned int));
}

void do_child(int index){
    unsigned int    nprtc;
    static   float  media=0.0;
    static   int    nExp=0; 
    if(index==N-1)
        close(pipeFd[index][WRITEEND]);

    srand(time(NULL));
    while(1){
        read(pipeFd[index][READEND], &nprtc, sizeof(unsigned int));
        if(index!=N-1){
            if((rand()%100+1)>50){
                printf("%d° transporter: received %d particles. Sending them...\n", index);    
                write(pipeFd[index+1][WRITEEND], &nprtc, sizeof(unsigned int));
            }
            else{
                printf("%d° transporter: data loss\n", index);
            }
        }
        else{
            media+=(nprtc/++nExp);
            printf("Receiver: average particles is %f\n", media);
        }
   }
}

