#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/select.h>
#include <signal.h>

#define DX          0
#define SX          1
#define READEND     0
#define WRITEEND    1

int N, fdx, fsx, level, pF2SX[2][2], pF2DX[2][2], pC2F[2][2], im, value, sxval, dxval, msg, somma;

void node(int );
void makeChild(int, int);
int main(int argc, char *argv[]){
    int i;
    if(argc!=2){
        printf("Bad number of arguments\nUsage: %s N(!=0)\n", argv[0]);
        exit(-1);
    }

    if(!(N=atoi(argv[1]))){
        printf("Bad argument\nUsage: %s N(!=0)\n", argv[0]);
        exit(-1);
    }

    node(0);

    return 0;
}

void node(int h){
    int index=level%2;
    srand(getpid());
    pipe(pF2SX[index]);
    pipe(pF2DX[index]);
    pipe(pC2F[index]);
    if(h<N){
        makeChild(DX, h+1);   
        makeChild(SX, h+1);
    }
    while(1){
        if(!level){
            write(pF2SX[index][WRITEEND], &msg, sizeof(int));
            read(pC2F[index][READEND], &sxval, sizeof(int));
            write(pF2DX[index][WRITEEND], &msg, sizeof(int));
            read(pC2F[index][READEND], &dxval, sizeof(int));
            somma=sxval+dxval;
            printf("La somma è %d\n", somma);
            sleep(1);
            }
        else{
            if(!im)
                read(pF2SX[1-index][READEND], &msg, sizeof(int));
            else
                read(pF2DX[1-index][READEND], &msg, sizeof(int));
            if(level!=N){
                write(pF2SX[index][WRITEEND], &msg, sizeof(int));
                read(pC2F[index][READEND], &sxval, sizeof(int));
                write(pF2DX[index][WRITEEND], &msg, sizeof(int));
                read(pC2F[index][READEND], &dxval, sizeof(int));
                somma=dxval+sxval;
                write(pC2F[1-index][WRITEEND], &somma, sizeof(int));
            }
            else{
                value=rand()%10+1;
                write(pC2F[1-index][WRITEEND], &value, sizeof(int));
            }
      } 
   }
}
void makeChild(int flag, int h){
    pid_t *fptr;
    if(flag==DX)
        fptr=&fdx;
    else
        fptr=&fsx;

    switch((*fptr=fork())){
        case -1:
            printf("Error forking\n");
            exit(-1);
            break;
        case 0:
            im=flag;
            level=h;
            node(h);
            break;
        default:
            break;
    }
}


