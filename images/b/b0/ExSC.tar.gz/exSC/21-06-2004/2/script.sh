#!/bin/bash


for i in `ruptime | cut -d' ' -f1`; do
    str=`ssh $i grep -i memtotal /proc/meminfo`
    str1=`ssh $i grep -i Mhz /proc/cpuinfo`
    echo $i $str $str1 >> logfile
done;

