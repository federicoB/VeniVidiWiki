#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/select.h>
#include <signal.h>

#define NCONCORRENTI    24
#define NGIURIA         6
#define WRITEEND        1
#define READEND         0

typedef struct conc{
    pid_t   pid;
    int     voto;
}conc;

void mirigliani(void);
void egiuria(void);
void cmiss(void);
int cmp(const void *a, const void *b);
void nullFunction(int);


conc    miss[NCONCORRENTI];
pid_t   giuria[NGIURIA];
int     pipeM2G[2];
int     pipeG2M[2];
int     nConc   =   NCONCORRENTI;

int main(void){
    int i;
    if(((pipe(pipeM2G))<0)||
        ((pipe(pipeG2M))<0)){
            printf("Error pipe-ing..\n");
            exit(-1);
    }

    for(i=0; i<NCONCORRENTI; ++i)
        switch((miss[i].pid=fork())){
            case -1:
                printf("Error forking...\n");
                exit(-1);
                break;
            case 0:
                cmiss();
                break;
            default:
                break;
        }
    printf("..........RAGAZZE GENERATE..........\n");
    for(i=0; i<NGIURIA; ++i)
        switch((giuria[i]=fork())){
            case -1:
                printf("Error forking...\n");
                exit(-1);
                break;
            case 0:
                egiuria();
                break;
            default:
                printf(".");
                break;
        }
    printf("......GIURIA GENERATA.......\n");
    close(pipeM2G[READEND]);
    close(pipeG2M[WRITEEND]);
    mirigliani();

    return 0;
}

void mirigliani(void){
    int i, j, k, gover;
    conc    missTemp[NCONCORRENTI];
    
    while(1){
        sleep(1);
        for(k=0; k<NCONCORRENTI; ++k)
                    miss[k].voto=0;
        for(i=0; i< NGIURIA; ++i)
            write(pipeM2G[WRITEEND], miss, sizeof(conc)*NCONCORRENTI);
        for(i=0; i<NGIURIA; ++i){
            read(pipeG2M[READEND], missTemp, sizeof(conc)*NCONCORRENTI);
            printf("Ricevuti dati dalla giuria\n");
            for(k=0; k<NCONCORRENTI; ++k)
                if(missTemp[k].pid!=-1)
                        miss[k].voto+=missTemp[k].voto;
        }
        qsort(miss, NCONCORRENTI, sizeof(conc), cmp);
        for(gover=0, i=0; gover<4; ++i)
            if(miss[i].pid!=-1){
                kill(miss[i].pid, SIGUSR1);
                miss[i].pid=-1;
                gover++;
            }
         
        nConc-=4;
        if(nConc==4){
            int t=rand()%4+1;
            k=0;
            for(i=0; i<NCONCORRENTI; ++i){
                if(miss[i].pid!=-1)
                    k++;
                if(k==t)
                    break;
             }
            
            printf("La vincitrice è: %d\n", miss[i].pid);
        
        for(i=0;i<NGIURIA;++i)
            kill(giuria[i], SIGKILL);
        for(i=0;i<NCONCORRENTI;++i)
            if(miss[i].pid!=-1)
                kill(miss[i].pid, SIGKILL);
        }
   }
}
void egiuria(){
    conc    miss[NCONCORRENTI];
    int     i;
    while(1){
        read(pipeM2G[READEND], miss, sizeof(conc)*NCONCORRENTI);
        printf("Io giuriato %d: ho ricevuto dati da mirigliani\n", getpid());
         
        for(i=0;i<NCONCORRENTI;++i)
            if(miss[i].pid!=-1)
                miss[i].voto=rand()%10+1;
        write(pipeG2M[WRITEEND], miss, sizeof(conc)*NCONCORRENTI);
        printf("Io giuriato %d: ho inviato dati a mirigliani\n", getpid());
     }
}

void cmiss(void){
    sigset_t set;
    sigfillset(&set);
    signal(SIGUSR1, nullFunction);
    sigdelset(&set, SIGUSR1);
    sigsuspend(&set);
    printf("MISS %d: Grazie è stato un piacere\n", getpid());
    exit(0);
}

int cmp(const void *a, const void *b){
    const conc *ia = (const conc *)a; 
    const conc *ib = (const conc *)b;
    return ia->voto-ib->voto; 
}

void nullFunction(int signo){
}

