#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <signal.h>

#define     A       0
#define     B       1

void    docity(void);
void    doC(void);
void    handler(int, siginfo_t*, void *arg);

pid_t       station, city[2];
int         fre, turn;
sigset_t    mask;

int main(void){
    struct  sigaction act;
    int i; 
    sigfillset(&act.sa_mask);
    act.sa_flags        =   SA_SIGINFO;
    act.sa_sigaction    =   handler;
    sigaction(SIGUSR1, &act, NULL);
    
    turn=A;
    fre=0;
    sigemptyset(&mask),
    sigaddset(&mask, SIGUSR1);
    sigprocmask(SIG_BLOCK, &mask, NULL);

    for(i=0; i<2; ++i)
            switch(city[i]=fork()){
                case -1:
                    perror("Forking....\n");
                    exit(-1);
                    break;
                case 0:
                    docity();
                    break;
            }
    doC();
    return 0;
}

void docity(void){
    srand(time(NULL)+getpid());
    sigfillset(&mask);
    sigdelset(&mask, SIGUSR1);
    sigdelset(&mask, SIGINT);
    
    while(1){
        kill(getppid(), SIGUSR1);
        while(!fre)
            sigsuspend(&mask);
            
        fre=0;
    }
}

void doC(void){
    int     i=0;
    sigfillset(&mask);
    sigdelset(&mask, SIGUSR1);
    sigdelset(&mask, SIGINT);
    
    while(1)
        sigsuspend(&mask);
}

void handler(int signo, siginfo_t *info, void *arg){
    if(info->si_pid==city[A]){      /*se il sender è A può essere solo getpid()==stazione*/
        printf("Richiesta di: A\n");
        if(turn==A){
            turn=B;
            printf("Passa A\n");
            kill(city[A], SIGUSR1);
            }
        else
            printf("A non può passare\n");
            
        }
    else 
        if (info->si_pid==city[B]){ //idem
            printf("Richiesta di B\n");
            if(turn==B){
                turn=A;
                printf("Passa B\n");
                kill(city[B], SIGUSR1);
            }
            else
                printf("B non può passare\n");
            
        }        
    else        /*è ovvio che il sender è la stazione e il receiver è o A o B che ha ricevuto il via
                libera*/
        fre=1;
}


