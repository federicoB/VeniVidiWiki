#!/bin/bash



for str in `cat $file`; do
    for i in `seq 1 ${#str}`; do 
        for j in `seq 1 $K`; do
            for h in `seq `
