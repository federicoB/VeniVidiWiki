#!/bin/bash

for i in `find $1 -type f -print`; do
    file=`basename $i`
    pathfile2="$2/$file"
    cmp $i $pathfile2
done;


