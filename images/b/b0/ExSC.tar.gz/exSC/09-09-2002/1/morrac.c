#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/select.h>
#include <signal.h>

#define     FALSE   0
#define     TRUE    1

#define     CARTA   0
#define     FORBICI 1
#define     SASSO   2

#define     GIOCATORE1  ((arbiter+1)%3)
#define     GIOCATORE2  ((arbiter+2)%3)


void    play();
void    initPids();
void    handler(int signo, siginfo_t *, void *);
void    getPlayers(int *, int *);
int     NTURNI, phaseInit=0, arbiter, punto[3], myIndex, arrived;
pid_t   players[3];

struct  sigaction   act;
sigset_t        set;

int main(int argc, char *argv[]){
    int i;
    if(argc!=2){
        printf("Bad Number of arguments: %s nTurni\n", argv[0]);
        exit(-1);
    }

    NTURNI=atoi(argv[1]);
    act.sa_handler=NULL;
    act.sa_sigaction=handler;
    act.sa_flags=SA_SIGINFO;
    sigemptyset (&act.sa_mask);
    sigaddset(&act.sa_mask, SIGUSR1);
    sigaddset(&act.sa_mask, SIGUSR2);
     
    sigaction(SIGUSR1, &act, NULL);
    sigaction(SIGUSR2, &act, NULL);
    sigemptyset(&set);
    sigaddset(&set, SIGUSR1);
    sigaddset(&set, SIGUSR2);
    sigprocmask(SIG_BLOCK, &set, NULL);

    for(i=0;i<3; ++i)
            players[i]=-1;
    
    players[0]=getpid();
    arbiter=myIndex=0;
    
    for(i=1;i<3; ++i)
        switch(players[i]=fork()){
            case -1:
                printf("Error forking\n");
                exit(-1);
                break;
            case 0:
                myIndex=i;
                initPids();
                exit(0);
                break;
        }
    initPids();
    return 0;
}

void handler(int signo, siginfo_t *info, void *arg){
    if(info->si_pid!=players[0]&&getpid()!=players[2]&&!phaseInit){
        players[2]=info->si_pid;
        kill(players[2], SIGUSR1);
        phaseInit=1;
    }
    if(phaseInit)
        if(myIndex==arbiter){
             printf("Arrived %d\n", ++arrived);
             //arrived++;
        }
}

void play(void){
    int i;
    sigfillset(&set);
    sigdelset(&set, SIGUSR1);
    sigdelset(&set, SIGUSR2);
    sigdelset(&set, SIGINT);    

    if(myIndex==arbiter){
        for(i=0; i<2; ++i){
            sigsuspend(&set);
            kill(players[GIOCATORE1], SIGUSR1);
        }
    }
    else{
        if(myIndex==GIOCATORE1){
            kill(players[arbiter], SIGUSR1);
            sigsuspend(&set);
            kill(players[arbiter], SIGUSR1);
            sigsuspend(&set);
        }
    }
}

void getPlayers(int *winner, int *loser){
    *winner=1;
    *loser=2;
}


void initPids(void){
    sigfillset(&set);
    sigdelset(&set, SIGUSR1);
    sigdelset(&set, SIGUSR2);
    sigdelset(&set, SIGINT);

    if(players[1]>0 && getpid()!=players[0]){
        kill(players[1], SIGUSR1);
        sigsuspend(&set);
    }
    else 
        if(players[0]!=getpid())
            sigsuspend(&set);

    phaseInit=1;
    players[myIndex]=getpid();
    play();
}

