#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/select.h>
#include <signal.h>

#define READEND     0
#define WRITEEND    1

void initOfferte(void);
void do_asta(int);
int getMax(int *);

int     K, count, pWinner;
int     *offerte, **p;

int main(int argc, char *argv[]){
    int i;
    if(argc!=2){
        printf("Bad number of arguments\nUsage %s K[nproc]\n", argv[0]);
        exit(0);
    }

    K=atoi(argv[1]);
    if  (
        ((offerte=(int *)malloc(sizeof (int )*K))==NULL)||
        ((p=(int **)malloc(sizeof (int *)*K))==NULL)
        ){
        printf("Error malloc-ing...\n");
        exit(-1);
    }

    for(i=0; i<K; ++i)
        if ( ((p[i]=(int *)malloc(sizeof (int )*2))==NULL)|| (pipe(p[i])<0) ){   
            printf("Error malloc-ing or pipe-ing...\n");
            exit(-1);
        }

    for(i=0; i<K; ++i)
        switch(fork()){
            case -1:
                printf("Error fork-ing...\n");
                exit(-1);
                break;
            case 0:
                do_asta(i);
                break;
        }
    
    
    initOfferte();
    while(1){
        write(p[0][WRITEEND], offerte, sizeof(int)*K);
        read(p[0][READEND], offerte, sizeof(int)*K);
        for(i=0;i<K; ++i)
            if(!offerte[i])
                count++;
            
        if(count==K-1){
            for(i=0; i<K; ++i)
                if(offerte[i])
                    break;
            printf("%d ha vinto con un offerta di %d\n", i, offerte[i]);
            initOfferte();
        }
        if(count==K){
            printf("Nessuno ha voluto offrire nulla. Si passa al prossimo prodotto\n");
            initOfferte();
        }
        count=0;
    }
    return 0;
}


void do_asta(int index){
    int lofferte[K], max, val, i;
    srand(getpid());
    while(1){
        read(p[index][READEND], lofferte, sizeof(int)*K);   
        if(lofferte[index]){
            max=getMax(lofferte);
            if(max>lofferte[index]||max==-1)
                if(rand()%2)
                    lofferte[index]=((max==-1)?0:max)+rand()%1000;
                else
                    lofferte[index]=0;
        }
        printf("I'm %d ", index);
        for(i=0; i<K; ++i)
            printf("%d ", lofferte[i]);
        printf("\n");
        sleep(1);
        write(p[(index==K-1)?0:index+1][WRITEEND], lofferte, sizeof(int)*K); 
    }
}

void initOfferte(){
    int i;
    for(i=0; i<K; ++i)
        offerte[i]=-1;    
}

int getMax(int *p){
    int i, max;
    max=p[0];
    
    for(i=1; i<K; ++i)
        if(max<p[i])
            max=p[i];

    return max;
}


