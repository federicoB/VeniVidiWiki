#!/bin/bash



for i in $@; do 

    for file in `find $i -type f`; do
        orig=`du $file|cut -f1`
        gzip    $file
        new=`du "$file.gz"|cut -f1`
        orig=`expr $orig / 2`
        if [ $new -gt $orig ]; then
            uncompress "$file.gz"
        fi
    done


done
