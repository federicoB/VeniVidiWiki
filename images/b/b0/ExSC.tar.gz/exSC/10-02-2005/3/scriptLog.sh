#!/bin/bash

PATHtmp=/etc
filelog=log
for i in $( find $PATHtmp -maxdepth 1 -type f -atime -1 ) ; do
    file=`basename "$i"`
    user=`stat --printf="%U" "$i"`
    accessTime=`stat --printf="%x" "$i"`
    modificationTime=`stat --printf="%y" "$i"`
    toWrite=$accessTime
    if [ "$accessTime" != "$modificationTime" ]; then
        toWrite="$modificationTime *"
    fi

    echo "$file $user $toWrite" >> $filelog 

done

 
