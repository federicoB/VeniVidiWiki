#/bin/bash   
    
cat $0
