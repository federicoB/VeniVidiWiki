#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <errno.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/stat.h>
#include <sys/select.h>
int nProc, codaProcFd;
void doNet(void);
void takenToken(int signo);
void usage(char *str);
int main(int argc, char *argv[]){
    int fd;
    pid_t myAndHisPid[2];
    fd_set fdRead;
    if((fd=open(argv[1], O_RDWR))<0){
        printf("Error\n");
        exit(-1);
    }

    if((codaProcFd=open(argv[2], O_RDWR))<0){
        printf("Error\n");
        exit(-1);
    }

    myAndHisPid[0]=getpid();
    myAndHisPid[1]=atoi(argv[3]);
    write(fd, &myAndHisPid, sizeof(pid_t)*2);
    
    FD_ZERO(&fdRead);
    FD_SET(fd, &fdRead);
    select(fd+1, &fdRead, NULL, NULL, NULL);
    read(fd, &nProc, sizeof(int));
    write(fd, &nProc, sizeof(int)); //solo per non far ciclare in eterno token1
    doNet(); 
return 0;
} 

void doNet(void){
    int i;
    sigset_t set;
    pid_t valR, succProc;
    sigfillset(&set);
    sigdelset(&set, SIGUSR1);
    sigdelset(&set, SIGINT);
    signal(SIGUSR1, takenToken);
    while(1){
        sigsuspend(&set);
        for(i=0; i<nProc; ++i){
            read(codaProcFd, &valR, sizeof(pid_t));
            write(codaProcFd, &valR, sizeof(pid_t));
            if(valR==getpid()){
                read(codaProcFd, &succProc, sizeof(pid_t));
                write(codaProcFd, &succProc, sizeof(pid_t));
            }
        }
        printf("%d: ho ricevuto il Token\n", getpid());
        sleep(1);
        printf("Spedisco il Token al processo %d\n", succProc);
        kill(succProc, SIGUSR1);
    }
}


void takenToken(int signo){
}

