#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <errno.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/stat.h>
#include <sys/select.h>


int codaProcFd, nProc, listenFd;

void doNet(void);
void takenToken(int signo);
void usage(char *str);
int main(int argc, char *argv[]){
    int i;
    pid_t pid, valW, start, father, pidNext, pidToAdd;
    fd_set fdRead;
    if(argc!=4){
        printf("Too few arguments\n");
        usage(argv[0]);
        exit(-1);
    }
    
    if((mkfifo(argv[1], O_CREAT|(0600)))<0){
        printf("Error while creating %s named pipe\n", argv[1]);
        usage(argv[0]);
        exit(-1);
    } 
    if((mkfifo(argv[2], O_CREAT|(0600)))<0){
        printf("Error while creating %s named pipe\n", argv[2]);
        usage(argv[0]);
        exit(-1);
    }
    
    
    if(((codaProcFd=open(argv[1], O_RDWR|O_NONBLOCK))<0)||
            ((listenFd=open(argv[2], O_RDWR|O_NONBLOCK))<0)){
                printf("Error while opening named pipe\n");
                usage(argv[0]);
                exit(-1);
    }

    father=getpid(); 
    nProc=atoi(argv[3]);
    for(i=0; i<nProc; ++i){

        if((pid=fork())<0){
            printf("Errore\n");
            exit(-1);
        }
        else if(!pid){
            valW=getpid();
            write(codaProcFd, &valW, sizeof(pid_t));
            break;
        }
        else
            if(!i)
                start=pid;
    }

    if(getpid()!=father)
        doNet();
    else{
        kill(start, SIGUSR1);
        while(1){
            FD_ZERO(&fdRead);
            FD_SET(listenFd, &fdRead);
            select(listenFd+1, &fdRead, NULL, NULL, NULL);
            read(listenFd, &pidNext, sizeof(pid_t));
            read(listenFd, &pidToAdd, sizeof(pid_t));
            printf("I'm trying to serve...%d\n", pidNext);        
            write(codaProcFd, &pidToAdd, sizeof(pid_t));


            write(listenFd, &nProc, sizeof(int));
//SOLO PER
            FD_ZERO(&fdRead);
            FD_SET(listenFd, &fdRead);
            select(listenFd+1, &fdRead, NULL, NULL, NULL);
            read(listenFd, &pidNext, sizeof(pid_t));
//NON CICLARE IN ETERNO
        }
    }
return 0;
}




void doNet(void){
    int i;
    sigset_t set;
    pid_t valR, succProc;
    sigfillset(&set);
    sigdelset(&set, SIGUSR1);
    sigdelset(&set, SIGINT);
    signal(SIGUSR1, takenToken);
    while(1){
        sigsuspend(&set);
        for(i=0; i<nProc; ++i){
            read(codaProcFd, &valR, sizeof(pid_t));
            write(codaProcFd, &valR, sizeof(pid_t));
            if(valR==getpid()){
                read(codaProcFd, &succProc, sizeof(pid_t));
                write(codaProcFd, &succProc, sizeof(pid_t));
            }
        }
        printf("%d: ho ricevuto il Token\n", getpid());
        sleep(1);
        printf("Spedisco il Token al processo %d\n", succProc);
        kill(succProc, SIGUSR1);
    }
}


void takenToken(int signo){
}


void usage(char *cmd){

    printf("Usage: %s fifo1 fifo2 nProc\n", cmd);
    printf("Where \n1) fifo1 is the named pipe used by processes to communicate\n");
    printf("2) fifo2 is the named pipe used by new processes that want to enter the token ring\n");
    printf("3) nProc is the initial number of processes\n");
}

