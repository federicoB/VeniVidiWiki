#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <errno.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/wait.h>


int fd, nProc;

void doNet(void);
void takenToken(int signo);

int main(int argc, char *argv[]){
    int i;
    pid_t pid, valW, start, father;
    if(argc!=3){
        printf("Bad number of arguments\n");
        exit(-1);
    }
    
    if((fd=open(argv[1], O_RDWR|O_NONBLOCK))<0){
        printf("Error opening pipe\n");
        exit(-1);
    } 
    father=getpid(); 
    nProc=atoi(argv[2]);
    for(i=0; i<nProc; ++i){

        if((pid=fork())<0){
            printf("Errore\n");
            exit(-1);
        }
        else if(!pid){
            valW=getpid();
            write(fd, &valW, sizeof(pid_t));
            break;
        }
        else
            if(!i)
                start=pid;
    }

    if(getpid()!=father)
        doNet();
    else{
        kill(start, SIGUSR1);
        for(i=0; i<nProc; ++i)
                waitpid(-1, NULL, 0);
    
                
}
return 0;
}




void doNet(void){
    int i;
    sigset_t set;
    pid_t valR, succProc;
    sigfillset(&set);
    sigdelset(&set, SIGUSR1);
    sigdelset(&set, SIGINT);
    signal(SIGUSR1, takenToken);
    while(1){
        sigsuspend(&set);
        for(i=0; i<nProc; ++i){
            read(fd, &valR, sizeof(pid_t));
            write(fd, &valR, sizeof(pid_t));
            if(valR==getpid()){
                read(fd, &succProc, sizeof(pid_t));
                write(fd, &succProc, sizeof(pid_t));
            }
        }
        printf("%d: ho ricevuto il Token\n", getpid());
        sleep(1);
        printf("Spedisco il Token al processo %d\n", succProc);
        kill(succProc, SIGUSR1);
    }
}


void takenToken(int signo){
}


