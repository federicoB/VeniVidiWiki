#!/bin/bash

maschi=`grep -c ";M;" $1`
femmine=`grep -c ";F;" $1`

cat file | sort -t";" --key=4 | tail -n$maschi | sort -t";" --key=2|awk -F";" '
                            BEGIN{media=0; flag=0} { 
                                if(!flag){ 
                                     flag=1;  
                                     old=$2; 
                                }
                                if($2==old){
                                        media+=$5; 
                                        count++
                                    }
                                else{
                                    printf("%s %f\n", old, media/count ); 
                                    old=$2; media=$5; count=1}
                                    } 
                            END{printf("%s %f\n", $2, media/count); }'



cat file | sort -t";" --key=4 | head -n$femmine | sort -t";" --key=2|awk -F";" '
                            BEGIN{media=0; flag=0} { 
                                if(!flag){ 
                                     flag=1;  
                                     old=$2; 
                                }
                                if($2==old){
                                        media+=$5; 
                                        count++
                                    }
                                else{
                                    printf("%s %f\n", old, media/count ); 
                                    old=$2; media=$5; count=1}
                                    } 
                            END{printf("%s %f\n", $2, media/count); }'

