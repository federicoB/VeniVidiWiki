#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/select.h>
#include <signal.h>
#include <limits.h>


void handler(int, siginfo_t *, void *);
void play(void);

pid_t       child, father;
sigset_t    set;
int         lostballs;
int main(void){
    struct  sigaction   act;
    
    act.sa_sigaction=handler;
    sigemptyset(&act.sa_mask);
    act.sa_flags=SA_SIGINFO;
    sigaction(SIGUSR1, &act, NULL);
    sigaction(SIGUSR2, &act, NULL);
    
    
    sigemptyset(&set);
    sigaddset(&set, SIGUSR1);
    sigaddset(&set, SIGUSR2);
    
    sigprocmask(SIG_BLOCK, &set, NULL);

    father=getpid();
    switch((child=fork())){
        case -1:
            perror("Forking\n");
            exit(-1);
            break;
        case 0:
            father=-1;
            play();
            break;
        default:
            play();
            break;
    }
    return 0;
}


void play(void){
    srand(time(NULL)+getpid());
    sigfillset(&set);
    sigdelset(&set, SIGUSR1);
    sigdelset(&set, SIGUSR2);
    sigdelset(&set, SIGINT);
    
    if(getpid()==father)
        kill(child, (rand()%2) ? SIGUSR1 : SIGUSR2);   
 
    while(1)
        sigsuspend(&set);
}

void handler(int signo, siginfo_t *info, void *arg){
    int sig;
    sig=(rand()%2)?SIGUSR1:SIGUSR2;
    if(signo!=sig){
        if(lostballs==15){
            printf("Ho perso %d e ha vinto %d\n", getpid(), info->si_pid);
            kill(info->si_pid, SIGKILL);
            exit(0);
        }
        printf("Punto al processo %d\n", (getpid()==father) ? child : getppid());
        lostballs++;
        sleep(1);
        kill(info->si_pid, sig);    
    }
    else{
        usleep(200);
        sig=(rand()%2)?SIGUSR1:SIGUSR2;
        printf("%d %d : AHHHH\n", getpid(), sig);
        kill(info->si_pid, sig); 
    }
}





