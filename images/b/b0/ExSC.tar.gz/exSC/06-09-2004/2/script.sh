#!/bin/bash

bigStr=$1
len=`expr length $bigStr`
shift
let "len=len-3"
for j in `seq 0 $len`; do
    let "cont=0"
    for i in $*; do
            for t in `cat $i`; do
                len2=`expr length $t`
                for h in `seq 0 $len2`; do
                    if [ "${t:$h:3}" = "${bigStr:$j:3}" ]; then
                        let "cont=cont+1"
                    fi
                done
            done
    done
    echo "${bigStr:$j:3}" $cont
done
