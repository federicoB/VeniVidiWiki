#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/select.h>
#include <signal.h>


void do_child(int );
void do_father(pid_t fc);
void makeChild(pid_t *, int);
void handler(int signo);
void handlerFather(int signo);

int     N, wait=1, cont=0;
int     myLevel, value;
pid_t   fsx, fdx;
sigset_t    set;

int main(int argc, char *argv[]){

    pid_t   fc;
    
    if(argc!=2){
        printf("Error: bad number of arguments...\n");
        return -1;
    }
    N=atoi(argv[1]);
    signal(SIGUSR1, handlerFather);
    signal(SIGUSR2, handlerFather);
    sigfillset(&set);
    sigdelset(&set, SIGUSR1);
    sigdelset(&set, SIGUSR2);
    sigdelset(&set, SIGINT);
    switch((fc=fork())){
        case -1:
            printf("Error forking...\n");
            exit(-1);
            break;
        case 0:
            do_child(0);
            break;
        default:
            do_father(fc);
            break;
    } 
    return 0;
}
void handlerFather(int signo){
    if(signo==SIGUSR2&&wait){
        cont++;
        if(cont==(1<<N))
            wait=0;
    }
}

void do_father(pid_t fc){
    while(wait)
        sigsuspend(&set);
    while(1){
        kill(fc, SIGUSR1);
        sigsuspend(&set);
    }
}

void do_child(int h){
    myLevel =   h;
    signal(SIGUSR1, handler);
    signal(SIGUSR2, handler);
    srand(getpid());
    if(h<=N){
        makeChild(&fsx, h);    
        makeChild(&fdx, h);    
    }
    value=rand()%1001;
    if(h==N){
       kill(getppid(), SIGUSR2);
    }
    sigfillset(&set);
    sigdelset(&set, SIGUSR1);
    sigdelset(&set, SIGUSR2);
    sigdelset(&set, SIGINT); 
    while(1)
        sigsuspend(&set);
}

void handler(int signo){
    if(signo==SIGUSR1){
        if(myLevel==N){
            printf("Sono %d e tu hai vinto %d\n", getpid(), value);
            //sleep(1);
            kill(getppid(), SIGUSR2);
        }
       else{
            if(rand()%2)
                kill(fsx, SIGUSR1);
            else
                kill(fdx, SIGUSR1);
        }

    }
    else
        kill(getppid(), SIGUSR2);
    
}

void makeChild(pid_t *f, int h){
    switch((*f=fork())){
        case -1:
            printf("Error forking...\n");
            exit(-1);
            break;
        case 0:
            do_child(h+1);
            break;
    }
}


