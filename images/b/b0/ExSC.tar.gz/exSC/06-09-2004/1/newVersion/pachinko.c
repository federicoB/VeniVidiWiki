#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <signal.h>

#define DX              0
#define SX              1
#define MAXQUANTITY     10000
void    usage(char *);
void    do_node(int );
void    makeChild(pid_t *, int);
void    do_father(void);
void    handler(int );

int         N, level, myRandValue;
pid_t       child[2];
sigset_t    mask;

int main(int argc, char **argv){
    if(argc!=2){
        usage(argv[0]);
        exit(-1);
    }
    N=atoi(argv[1]);
    do_father();
    return 0;
}
void usage(char *str){
    printf("Bad number of arguments. Example: %s N (where N is the max depth of the bintree)\n", str);
}        

void do_father(void){
    struct      sigaction   act;
    pid_t       firstChild;

    act.sa_handler  =   handler;
    sigemptyset (&act.sa_mask);
    act.sa_flags = 0;
    sigaction(SIGUSR1, &act, NULL);   
    sigaction(SIGUSR2, &act , NULL);

    sigemptyset(&mask);
    sigaddset(&mask, SIGUSR1);
    sigprocmask(SIG_BLOCK, &mask, NULL);

    level=-1;
    switch((firstChild=fork())){
        case -1:    
            printf("Error forking...\n");
            exit(-1);
        case 0:
            do_node(0);
            break;
    }    
    
    sigfillset(&mask);
    sigdelset(&mask, SIGUSR2);
    sigdelset(&mask, SIGINT);
    
    while(1){
        kill(firstChild, SIGUSR1);
        sigsuspend(&mask);
        //sleep(1);
    }
}
void handler(int signo){
    if(level>=0)
        if(signo==SIGUSR1)
            if(level!=N)
                kill(child[rand()%2], SIGUSR1);
            else{
                printf("Hai vinto la quantità %d\n", myRandValue);
                kill(getppid(), SIGUSR2);
            }
        else
            kill(getppid(), SIGUSR2);    
}
void do_node(int l){
    level=l;
    srand(time(NULL)+getpid());
    if(level<N){
        makeChild(&child[DX], level+1);
        makeChild(&child[SX], level+1);
    }    
    if(l==N)
        myRandValue=rand()%MAXQUANTITY+1; 
    
    sigfillset(&mask);
    sigdelset(&mask, SIGUSR1);
    sigdelset(&mask, SIGUSR2);
    sigdelset(&mask, SIGINT); 
    while(1)
        sigsuspend(&mask);
}


void makeChild(pid_t *f, int h){
    switch((*f=fork())){
        case -1:
            printf("Error forking...\n");
            exit(-1);
            break;
        case 0:
            do_node(h);
            break;
    }
}


