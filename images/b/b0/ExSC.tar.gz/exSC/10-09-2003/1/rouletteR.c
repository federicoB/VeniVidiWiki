#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/select.h>
#include <signal.h>


void handler(int);
void do_gun(void);
void do_suicide(pid_t, int);

int         NTURNI;
pid_t       suicide, gun;
sigset_t    mask;

int main(int argc, char **argv){
    struct      sigaction   act;
    
    if(argc!=2){
        printf("Bad number of arguments\n Example %s N\n", argv[0]);
        exit(-1);
    }


    NTURNI=atoi(argv[1]);
    suicide=getpid();
    

    act.sa_handler  =   handler;
    sigemptyset (&act.sa_mask);
    act.sa_flags = 0;
    sigaction(SIGUSR1, &act, NULL);

    sigemptyset(&mask);
    sigaddset(&mask, SIGUSR1);
    sigaddset(&mask, SIGUSR2);
    sigprocmask(SIG_BLOCK, &mask, NULL);

    switch(gun=fork()){
        case -1:
            printf("Error forking...\n");
            exit(-1);
            break;
        case 0:
            do_gun();
            break;
        default:
            do_suicide(gun, NTURNI);
            break;
    }

    return 0;
}

void do_suicide(pid_t gun, int times){
    sigfillset(&mask);
    sigdelset(&mask, SIGUSR1); 
    sigdelset(&mask, SIGINT);
    
    while(times--){
        printf("Addio\n");
        kill(gun, SIGUSR1);
        sigsuspend(&mask);
        sleep(1);
        printf("Cilecca\n");
    }
    printf("Per oggi mi sono salvato\n");
    kill(gun, SIGUSR2);
}
void do_gun(void){
    srand(getpid()+time(NULL));
    gun=getpid();
    sigfillset(&mask);
    sigdelset(&mask, SIGUSR1);
    sigdelset(&mask, SIGUSR2);
    sigdelset(&mask, SIGINT);
    
    while(1)
        sigsuspend(&mask); 
}
void handler(int signo){
    if(getpid()==gun)
        if(signo==SIGUSR1)
            if((rand()%6+1)==1){
                kill(suicide, SIGKILL);
                exit(0);
                }
            else{
                printf("Click\n");
                kill(suicide, SIGUSR1);
            }
    
        else
            exit(0);
}
    

