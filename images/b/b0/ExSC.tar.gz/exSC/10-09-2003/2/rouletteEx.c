#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <signal.h>


void play(void);
void handler(int, siginfo_t *, void *);

int         NTURNI;
sigset_t    mask;
pid_t       gun, child[2];

int main(int argc, char **argv){
    int     i;
    struct  sigaction act;

    if(argc!=2){
        printf("Bad number of arguments\n Example %s N\n", argv[0]);
        exit(-1);
    }    
    
    act.sa_sigaction  =   handler;
    sigemptyset (&act.sa_mask);
    act.sa_flags=SA_SIGINFO;

    sigaction(SIGUSR1, &act, NULL);
    sigaction(SIGUSR2, &act, NULL);

    sigemptyset(&mask);
    sigaddset(&mask, SIGUSR1);
    sigaddset(&mask, SIGUSR2);
    sigprocmask(SIG_BLOCK, &mask, NULL);

    NTURNI=atoi(argv[1]);
    srand(time(NULL));
    for(i=0; i<2; ++i)
        switch((child[i]=fork())){
            case -1:
                printf("Error forking...\n");
                exit(-1);
                break;
            case 0:
                play();
                break;
        }

    gun=getpid();
    i=0;
    sigfillset(&mask);
    sigdelset(&mask, SIGUSR1);
    sigdelset(&mask, SIGUSR2);
    sigdelset(&mask, SIGINT);
    while(i++<NTURNI*2 && child[0] && child[1]){
        kill(child[i%2], SIGUSR1);
        sigsuspend(&mask);
        if(child[0]&&child[1]){
            kill(child[i%2], SIGUSR1);
            sigsuspend(&mask);
            }
        }

    for(i=0; i<2; ++i)
        if(child[i]){
            printf("%d è sopravvissuto\n", child[i]); 
            kill(child[i], SIGKILL);    
        }
    return 0;
}

void play(void){
    sigfillset(&mask);
    sigdelset(&mask, SIGUSR1);
    while(1){
        sigsuspend(&mask);
        printf("%d: Addio\n", getpid());
        sleep(1);
        kill(getppid(), SIGUSR1);      
        sigsuspend(&mask);
        printf("%d: Cilecca! Ora sta a te\n", getpid());
        kill(getppid(), SIGUSR2);
    } 
}

void handler(int signo, siginfo_t *info, void *arg){
    if(getpid()==gun){
        if(signo==SIGUSR1){
                if((rand()%6+1)==1){
                    printf("Bang!!!!!\n");
                    kill(info->si_pid, SIGKILL);
                    if (info->si_pid==child[0])
                        child[0]=0;
                    else
                        child[1]=0;
                    }
                else
                    kill(info->si_pid, SIGUSR1);
        }
    }
}

