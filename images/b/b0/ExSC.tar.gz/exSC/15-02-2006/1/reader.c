#include <stdio.h>
#include <stdlib.h>
#include <sys/select.h>
#include <sys/time.h>
#include <sys/types.h>
#include <unistd.h>
#include <string.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <limits.h>
#define BUFFER PIPE_BUF
/*Esercizio 1 15/02/2006*/
int main(int argc, char *argv[]){
    int fd[argc-1], i, max=-1, fdr;
    fd_set  readSet, tmpReadSet;    
    char    buf[BUFFER];
    if(argc<2){
        printf("Error: too few arguments\n");
        exit(-1);
    }
    FD_ZERO(&readSet);
    for(i=0; i<argc-1; ++i){
        if((fd[i]=open(argv[i+1], O_RDWR|O_NONBLOCK))<0){
            printf("Error: while opening %s\naborting...\n", argv[i+1]);
            exit(-2);
        }
        max=(fd[i]>max)?fd[i]:max;
        FD_SET(fd[i], &readSet);
    }
    
    memset(&buf, 0, BUFFER);
    memcpy(&tmpReadSet, &readSet, sizeof(fd_set));
    while(1){
        select(max+1, &readSet, NULL, NULL, NULL);
        for(i=0; i<argc-1; ++i)
            if(FD_ISSET(fd[i], &readSet)){
                read(fd[i], &buf, BUFFER);
                printf("%s\n", buf);
            }
        memcpy(&readSet, &tmpReadSet, sizeof(fd_set));
        memset(&buf, 0, BUFFER);
    }

return 0;
}

