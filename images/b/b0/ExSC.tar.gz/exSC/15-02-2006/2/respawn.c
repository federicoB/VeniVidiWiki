#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/wait.h>


/*Esercizio 2*/
int main(int argc, char *argv[], char *env[]){
    pid_t   pid;
    int status;

    if (argc<2){
        printf("Too few arguments...\n");
        exit(-1);
    }


    while(1){
        if((pid=fork())<0){
            printf("Error while forking\nAborting....\n");
            exit(-1);
        }

        else if(pid==0){
            execve(argv[1], &(argv[1]), &(env[0]));
            printf("Error loading new program\nAborting...\n");
            exit(-1);
            }
        
        
        else{
            waitpid(pid, &status, 0);        
            printf("Il processo ha avuto termine a causa di un segnale %d\n",
                    WTERMSIG(status));
            if(WIFEXITED(status))    
                break;
            
            else{
                printf("ReExecuting....\n");
                sleep(1);
            }
    }
    }
    return 0;
}

