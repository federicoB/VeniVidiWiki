#include <stdio.h>
int main(void){
    while (1){
        printf("CiaoCiao\n");
        sleep(10);
    }
    return 0;
}
