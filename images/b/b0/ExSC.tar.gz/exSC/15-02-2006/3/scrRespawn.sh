#!/bin/bash
$* &

pid=$!
while :; do  
    sleep 10
    str=`ps aux|grep "$pid"`
    if [ -z $str ]; then
        $* & 
    fi    
done


