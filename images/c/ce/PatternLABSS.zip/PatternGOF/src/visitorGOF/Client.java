package visitorGOF;


/**
 * @uml.dependency   supplier="visitorGOF.Visitor"
 * @uml.dependency   supplier="visitorGOF.ObjectStructure"
 */
public class Client {

}
