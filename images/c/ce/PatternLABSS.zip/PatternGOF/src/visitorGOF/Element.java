package visitorGOF;


public interface Element {

		
		/**
		 */
		public abstract void Accept(Visitor visitor);
		

}
