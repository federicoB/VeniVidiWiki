package visitorGOF;


/**
 * @uml.dependency   supplier="visitorGOF.Element"
 */
public class ObjectStructure {

}
