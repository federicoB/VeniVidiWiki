package visitorGOF;


public class ConcreteVisitor2 implements Visitor {

	public void visitConcreteElementA(ConcreteElementA concreteElementA) {
		// TODO Auto-generated method stub

	}

	public void visitConcreteElementB(ConcreteElementB concreteElementB) {
		// TODO Auto-generated method stub

	}

}
