package visitorGOF;

public class ConcreteElementB implements Element {

	public void Accept(Visitor visitor) {
		visitor.visitConcreteElementB(this);
	}

	/**
		 */
	public void OperationB() {
	}

}
