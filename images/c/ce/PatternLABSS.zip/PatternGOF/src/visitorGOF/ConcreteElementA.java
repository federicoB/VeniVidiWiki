package visitorGOF;

public class ConcreteElementA implements Element {

	public void Accept(Visitor visitor) {
		visitor.visitConcreteElementA(this);

	}

	/**
		 */
	public void OperationA() {
	}

}
