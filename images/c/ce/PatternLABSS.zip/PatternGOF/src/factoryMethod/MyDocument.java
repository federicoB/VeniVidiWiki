package factoryMethod;

public class MyDocument extends Document {

	public void Close() {
		System.out.println("Chiuso");
	}

	public void Open() {
		System.out.println("Aperto");
	}

}
