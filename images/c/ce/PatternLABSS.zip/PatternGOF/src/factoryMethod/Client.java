package factoryMethod;


/**
 * @uml.dependency   supplier="factoryMethod.Application"
 * @uml.dependency   supplier="factoryMethod.Document"
 */
public class Client {
    public static void main(String[] args) {
        Application factory = new MyApplication();
        Document doc = factory.NewDocument("Doc1");
        doc.Revert();
        doc.Save();
        doc.Close();
    }
}
