package factoryMethod;


public class Application {

		
		/**
		 */
		public Document CreateDocument(){
			Document newDoc = new MyDocument();
			newDoc.setNome("BASE");
			return newDoc;
		}

		/**
		 */
		public Document NewDocument(String nome){
			Document nuovoDoc = CreateDocument();
			nuovoDoc.setNome("documento1.txt");
			nuovoDoc.Open();
			return nuovoDoc;
		}
		
		/**
		*/
		public void OpenDocument(){
			
		}
}
