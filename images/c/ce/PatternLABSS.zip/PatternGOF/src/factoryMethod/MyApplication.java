package factoryMethod;


/**
 * @uml.dependency   supplier="factoryMethod.MyDocument"
 */
public class MyApplication extends Application {

	@Override
	public Document CreateDocument() {
		return new MyDocument();
	}

}
