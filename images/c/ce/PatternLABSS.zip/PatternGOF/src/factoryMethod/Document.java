package factoryMethod;

public abstract class Document {

		/**
		 */
		public abstract void Open();
	
		/**
		 */
		public abstract void Close();						
						
		public void Save(){ 
			System.out.println("Salvato");
   		}
						
		public void Revert(){
			String str = this.getNome();
			System.out.println("Rendo il nome del documento in MAIUSCOLO...");
			String UPSTR = str.toUpperCase();
			System.out.println(UPSTR);
		}

		/**
		 * @uml.property  name="nome"
		 */
		private String nome = "";

		/** 
		 * Getter of the property <tt>documento</tt>
		 * @return  Returns the documento.
		 * @uml.property  name="nome"
		 */
		public String getNome() {
			return nome;
		}

		/** 
		 * Setter of the property <tt>documento</tt>
		 * @param documento  The documento to set.
		 * @uml.property  name="nome"
		 */
		public void setNome(String nome) {
			this.nome = nome;
		}

}
