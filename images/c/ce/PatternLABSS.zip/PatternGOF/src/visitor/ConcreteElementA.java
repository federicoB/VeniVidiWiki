package visitor;


public class ConcreteElementA implements Element { 
	 
	   private String value; 
	 
	   public ConcreteElementA(String string) { 
	      value = string; 
	   } 
	 
	   public String getString() { 
	      return value; 
	   } 
	 
	   public void accept( Visitor visitor ) { 
	        visitor.visit( this ); 
	   } 
	 
	} 
