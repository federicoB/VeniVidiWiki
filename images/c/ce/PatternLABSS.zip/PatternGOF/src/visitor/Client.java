package visitor;

import java.util.Vector; 

public class Client { 
 
   @SuppressWarnings("unchecked")
public static void main (String[] arg) { 
 
   // Prepare a heterogeneous collection 
   Vector untidyObjectCase = new Vector(); 
   untidyObjectCase.add( new ConcreteElementA( "A string" ) ); 
   untidyObjectCase.add( new ConcreteElementB( 1 ) ); 
   Vector aVector = new Vector(); 
   aVector.add( new ConcreteElementA( "Another string" ) ); 
   aVector.add( new ConcreteElementB( 2 )  ); 
   untidyObjectCase.add( aVector ); 
   untidyObjectCase.add( new ConcreteElementB( 3 ) ); 
   untidyObjectCase.add( new Double( 4 ) ); 
 
   // Visit the collection 
   @SuppressWarnings("unused")
   Visitor browser = new WatcherVisitor(); 
 
   } 
 
} 