package visitor;


public class ConcreteElementB implements Element {
	private Float value; 
	 
	public ConcreteElementB(float f) { 
	   value = new Float( f );
	} 
	 
    public Float getFloat() { 
      return value; 
    } 
 
    public void accept( Visitor visitor ) { 
      visitor.visit( this ); 
    } 
}
