package visitor;

public interface Visitor { 

   public void visit( ConcreteElementA string ); 
   public void visit( ConcreteElementB nFloat ); 
 
} 
