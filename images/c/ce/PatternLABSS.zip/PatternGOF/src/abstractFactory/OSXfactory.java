package abstractFactory;

/**
 * @uml.dependency   supplier="abstractFactory.OSXButton"
 */
public class OSXfactory extends GUIFactory {
    public Button createButton() {
        return new OSXButton();
    }
}
