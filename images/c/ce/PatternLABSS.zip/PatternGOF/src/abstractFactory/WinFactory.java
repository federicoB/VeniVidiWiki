package abstractFactory;

/**
 * @uml.dependency   supplier="abstractFactory.WinButton"
 */
public class WinFactory extends GUIFactory {
    public Button createButton() {
        return new WinButton();
    }
}
