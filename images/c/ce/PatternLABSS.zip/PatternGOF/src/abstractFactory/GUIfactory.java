package abstractFactory;

abstract class GUIFactory {
    public static GUIFactory getFactory() {
        int sys = 1;
        if (sys == 0) {
            return new WinFactory();
        } else {
            return new OSXfactory();
        }
    }
 
    public abstract Button createButton();
}
