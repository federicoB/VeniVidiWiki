package abstractFactory;

abstract class Button {
    public abstract void paint();
}
