package abstractFactory;

public class WinButton extends Button {
    public void paint() {
        System.out.println("Sono un WinButton");
    }
}
