package abstractFactory;

public class OSXButton extends Button {
    public void paint() {
        System.out.println("Sono un OSXButton");
    }
}
