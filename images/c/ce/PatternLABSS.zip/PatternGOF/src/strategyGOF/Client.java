package strategyGOF;

/**
 * @uml.dependency   supplier="strategyGOF.Context"
 */
public class Client { 
	 
	 public static void main (String[] arg) { 
	 
	   Context m = new Context( 10 ); 
	   m.setValue( 1 , 6 ); 
	   m.setValue( 0 , 8 ); 
	   m.setValue( 4 , 1 ); 
	   m.setValue( 9 , 7 ); 
	   
	   // A seconda della ConcreteStrategy che istanzio ho risultati differenti.
	   System.out.println("This is the array in �standard� format");
	   m.setStrategy( new ConcreteStrategyB() ); 
	   m.execute_algorithm(); 
	   
	   System.out.println("This is the array in �math� format:"); 
	   m.setStrategy( new ConcreteStrategyA() ); 
	   m.execute_algorithm(); 
	 } 
	 
	}  