package strategyGOF;

/**
 * @uml.dependency   supplier="strategyGOF.Strategy"
 */
public class Context { 
	   
	  private int[] array; 
	  private int size; 
	  Strategy strategy; 
	 
	 
	  public Context( int size ) { 
	     array = new int[ size ]; 
	  } 
	 
	  public void setValue( int pos, int value ) { 
	     array[pos] = value; 
	  } 
	 
	  public int getValue( int pos ) { 
	    return array[pos]; 
	  } 
	 
	  public int getLength( int pos ) { 
	    return array.length; 
	  } 
	 
	  public void setStrategy( Strategy adf ) { 
	    strategy = adf; 
	  } 
	 
	  public void execute_algorithm() { 
	     strategy.algorithm( array ); 
	  }

	public void setSize(int size) {
		this.size = size;
	}

	public int getSize() {
		return size;
	} 
	 
	}
