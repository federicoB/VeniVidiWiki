package strategyGOF;

public class ConcreteStrategyA implements Strategy { 
	 
	   public void algorithm( int[] arr ) { 
	      for(int i=0; i < arr.length ; i++ ) 
	         System.out.println( "Arr[ " + i + " ] = " + arr[i] ); 
	   } 
	}