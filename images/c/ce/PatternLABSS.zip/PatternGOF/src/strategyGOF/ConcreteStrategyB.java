package strategyGOF;

public class ConcreteStrategyB implements Strategy { 
	 
	   public void algorithm( int[] arr ) { 
	      System.out.print( "{ " ); 
	      for(int i=0; i < arr.length-1 ; i++ ) 
	         System.out.print( arr[i] + ", " ); 
	      System.out.println( arr[arr.length-1] + " }" ); 
	 
	   } 
	}
