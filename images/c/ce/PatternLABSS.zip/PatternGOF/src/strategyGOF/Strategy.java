package strategyGOF;


public interface Strategy {
	  public void algorithm( int[] arr ); 
		 
} 
