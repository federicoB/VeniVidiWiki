package singletonGOF;


public class Singleton {
	
	private Singleton(){
		
	}

	/**
	 * @uml.property  name="istanza"
	 */
	public static Singleton istanza;
	
		/**
		 * @return l'unica istanza istanziabile
		 */
		public static Singleton getIstance(){
			if ( istanza==null) { 
		         istanza = new Singleton(); 
		      } 
		      return istanza;
		}

			
		/**
		 * Funzione Stampa di un messaggio in input
		 */
		public void stampa(String msg){
			System.out.println(msg);
		}

}
