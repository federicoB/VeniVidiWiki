package singletonGOF;


public class Client {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Singleton unicaIstanza = Singleton.getIstance();
		Singleton secondaIstanza = Singleton.getIstance();
		if(unicaIstanza!=secondaIstanza) unicaIstanza.stampa("Singleton NON riuscito!");
		unicaIstanza.stampa("Singleton riuscito!");
	}

}
