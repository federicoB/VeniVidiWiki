package compositeGOF;

public abstract class Component { 
	 
	  public String name; 
	 
	  public Component(String aName){ 
	   name = aName; 
	  } 
	 
	  public abstract void Operation(); 
	  
	  public void add(Component c) throws SinglePartException { 
	      if (this instanceof Leaf) 
	         throw new SinglePartException( ); 
	  } 
	 
	  public void remove(Component c) throws SinglePartException{ 
	      if (this instanceof Leaf) 
	         throw new SinglePartException( ); 
	  } 
	 
	  public Component getChild(int n){ 
	      return null; 
	  } 

}
