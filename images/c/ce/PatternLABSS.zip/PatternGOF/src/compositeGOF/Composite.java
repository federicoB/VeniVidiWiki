package compositeGOF;

import java.util.Vector;
 
public class Composite extends Component { 
 
  public Vector<Component> children ; 
 
  public Composite(String aName) { 
      super(aName); 
      children = new Vector<Component>(); 
  } 
 
  public void Operation(){ 
   //Stampa il name ereditato dalla superClasse Component che l'ha creata
   System.out.println("Component: " + name); 
     System.out.println("Composed by:"); 
     System.out.println("{"); 
 
        int vLength = children.size(); 
        for( int i=0; i< vLength ; i ++ ) { 
        	Component c = (Component) children.get( i ); 
        	c.Operation(); 
     } 
     System.out.println("}"); 
  } 
 
  public void add(Component c) throws SinglePartException { 
	   children.addElement(c); 
  } 
  
  public void remove(Component c) throws SinglePartException{ 
	   children.removeElement(c); 
	  } 
	 
  public Component getChild(int n) { 
   return (Component)children.elementAt(n); 
  }
}
