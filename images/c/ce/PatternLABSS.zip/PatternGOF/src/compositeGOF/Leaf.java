package compositeGOF;

public class Leaf extends Component { 
	 
	  public Leaf(String aName) { 
	      super(aName); 
	  } 
	 
	  public void Operation(){ 
	      System.out.println( "Component: " + name ); 
	  } 
	 
	}
