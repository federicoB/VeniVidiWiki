package compositeGOF;

@SuppressWarnings("serial")
class SinglePartException extends Exception { 
    public SinglePartException( ){ 
     super( "Not supported method" ); 
  } 
}
