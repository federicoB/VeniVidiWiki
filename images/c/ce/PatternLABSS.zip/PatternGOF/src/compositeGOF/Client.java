package compositeGOF;

public class Client {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// Crea le singole parti - Leaf
	    Component monitor     = new Leaf("LCD Monitor"); 
	    Component keyboard    = new Leaf("Italian Keyboard"); 
	    Component processor   = new Leaf("Pentium III Processor"); 
	    Component ram         = new Leaf("256 MB RAM"); 
	    Component hardDisk    = new Leaf("40 Gb Hard Disk"); 
	 
	    // Crea un oggetto Composite
	    Component mainSystem = new Composite( "Main System" ); 
	    try { 
	    	// Composto da 3 Leaf
	      mainSystem.add( processor ); 
	      mainSystem.add( ram ); 
	      mainSystem.add( hardDisk ); 
	    } 
	    catch (SinglePartException e){ 
	     e.printStackTrace(); 
	    } 
	 
	    // Crea un oggetto Composite (Oggetto Composto)
	    Component computer = new Composite("Computer"); 
	    try{ 
	    	// Composto da 2 Leaf (Oggetto Singolo)
	        computer.add( monitor ); 
	        computer.add( keyboard );
	        
	        // E 1 Composite (Oggetto Composto da pi� Parti Singole)
	        computer.add( mainSystem ); 
	    } 
	    // Se non � possibile aggiungere un oggetto Composite o Leaf manda l'eccezione
	    catch (SinglePartException e){ 
	     e.printStackTrace(); 
	    } 
	    
	    // L'Operation non fa altro che stampare tutti i nomi dei Component, sia che essi siano Leaf che Composite, fino
	    // a che vi sono Component.
	    
	    System.out.println("**Provo a descrivere il Component �monitor�"); 
	    monitor.Operation(); 
	    
	    System.out.println("**Provo a descrivere il Component �main system�"); 
	    mainSystem.Operation();
	    
	    System.out.println("**Provo a descrivere il Component �computer�"); 
	    computer.Operation(); 
	 
	    // Attenzione! Non puoi invocare una add su un Componente NON composto! 
	    System.out.println( "**Provo ad aggiungere un Component a una Leaf. " ); 
	    try{ 
	     monitor.add( mainSystem ); 
	    } 
	    catch (SinglePartException e){ 
	     e.printStackTrace(); 
	    } 
	 

	}

}
