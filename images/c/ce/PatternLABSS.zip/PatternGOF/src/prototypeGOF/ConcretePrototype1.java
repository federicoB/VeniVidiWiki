package prototypeGOF;


public class ConcretePrototype1 implements Prototype {

	public Object clone()
	   {
	       try{
	           Prototype copy = (Prototype)super.clone();

	           System.out.println("ConcretePrototype1");

	           return copy;
	       }
	       catch(CloneNotSupportedException e)
	       {
	          e.printStackTrace();
	          return null;
	       }
	   }

}
