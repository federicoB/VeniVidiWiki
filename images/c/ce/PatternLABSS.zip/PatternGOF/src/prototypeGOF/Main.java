package prototypeGOF;

public class Main {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		/**
		 * Prototipo di supporto, ausiliario
		 * */
		@SuppressWarnings("unused")
		Prototype protoA = null;
		int i = 0;
		while(i!=2){
			switch(i){
				case 0:
					Prototype protoB = new ConcretePrototype2();
					Client C = new Client(protoB);
					for(int x=0; x<10; x++){
			    	  protoA = C.creaCloneDiPrototipo(); 
			    	  System.out.println("Clone "+x+" di protoB\n");
					}
					break;
					
				case 1:
					protoB = new ConcretePrototype1();
					C = new Client(protoB);
					for(int j=0; j<10; j++){
			    	  protoA = C.creaCloneDiPrototipo(); 
			    	  System.out.println("Clone "+j+" di protoB\n");
					}
					break;
			}
		i++;
		}
	}
}
