package prototypeGOF;


public class ConcretePrototype2 implements Prototype {

	public Object clone()
	   {
	       try{
	           Prototype copy = (Prototype)super.clone();

	           System.out.println("ConcretePrototype2");

	           return copy;
	       }
	       catch(CloneNotSupportedException e)
	       {
	          e.printStackTrace();
	          return null;
	       }
	   }
}
