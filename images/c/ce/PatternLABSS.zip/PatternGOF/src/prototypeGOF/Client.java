package prototypeGOF;

public class Client 
{

	  private Prototype prototipo;//could have been a private Cloneable cookie; 
	  	
	  /*Costruttore parametrizzato*/
	  public Client(Prototype prot) { 
	       this.prototipo = prot; 
	  }
	  
	  /*Produce un clone del campo "cookie" e DEVE essere fatto il cast a Cookie 
	   * perch� la clone() produce un object generico*/
	  public Prototype creaCloneDiPrototipo() { 
	    return (Prototype)prototipo.clone(); //Questa � la clone() della classe Prototype.
	  }
}
