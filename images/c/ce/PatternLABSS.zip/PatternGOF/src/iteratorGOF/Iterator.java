package iteratorGOF;


public interface Iterator {

		
		/**
		 */
		public abstract void First();

			
			/**
			 */
			public abstract void Next();


				
				/**
				 */
				public abstract void IsDone();


					
					/**
					 */
					public abstract void CurrentItem();
					
				
			
		

}
