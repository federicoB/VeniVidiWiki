package iteratorGOF;


/**
 * @uml.dependency   supplier="iteratorGOF.Iterator"
 * @uml.dependency   supplier="iteratorGOF.Aggregate"
 */
public class Client {
	

}
