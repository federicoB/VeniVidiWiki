package iteratorGOF;


public interface Aggregate {

		
		/**
		 */
		public abstract ConcreteIterator CreateIterator();
		

}
