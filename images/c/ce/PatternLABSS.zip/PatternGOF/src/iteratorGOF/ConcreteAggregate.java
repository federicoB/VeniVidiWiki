package iteratorGOF;


public class ConcreteAggregate implements Aggregate {

	public ConcreteIterator CreateIterator() {
		return new ConcreteIterator(this);

	}

}
