package iteratorGOF;


public class ConcreteIterator implements Iterator {
	
	public ConcreteIterator(ConcreteAggregate c){
		
	}

	public void CurrentItem() {
	}

	public void First() {
	}

	public void IsDone() {
	}

	public void Next() {
	}

}
