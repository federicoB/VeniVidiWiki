package prototype;

public class CookieMachine
{

  private Prototype cookie;//could have been a private Cloneable cookie; 
  	
  /*Costruttore parametrizzato*/
  public CookieMachine(Prototype cookie) { 
       this.cookie = cookie; 
  } 
  
  /*Produce un clone del campo "cookie" e DEVE essere fatto il cast a Cookie 
   * perch� la clone() produce un object generico*/
  public Prototype makeCookie() { 
    return (Prototype)cookie.clone(); //Questa � la clone() della classe Prototype.
  } 
}
