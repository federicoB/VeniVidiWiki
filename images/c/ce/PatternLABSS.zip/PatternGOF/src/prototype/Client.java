package prototype;

/**
 * @uml.dependency   supplier="prototype.CookieMachine"
 */
public class Client {
	public static void main(String args[]){ 
      @SuppressWarnings("unused")
      Prototype tempCookie = null; 
      /*Creo il primo prototipo*/
      Prototype prot = new CoconutCookie();
      
      /*Imposto il prototipo da clonare nella Cookiemachine*/
      CookieMachine cm = new CookieMachine(prot);
      /*System.out.println("Entro nel for");*/
      for(int i=0; i<100; i++){
    	  tempCookie = cm.makeCookie(); 
    	  System.out.println("Clone "+i+" di prot");
      }
	}

}
