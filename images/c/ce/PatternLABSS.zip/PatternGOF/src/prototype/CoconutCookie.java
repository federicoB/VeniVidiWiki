package prototype;

/** Concrete Prototypes to clone - Prototipo da clonare **/
public class CoconutCookie extends Prototype {

	/**
	 * @uml.property  name="nome"
	 */
	private String nome = "MARCO";

	/**
	 * Getter of the property <tt>nome</tt>
	 * @return  Returns the nome.
	 * @uml.property  name="nome"
	 */
	public String getNome() {
		return nome;
	}

	/**
	 * Setter of the property <tt>nome</tt>
	 * @param nome  The nome to set.
	 * @uml.property  name="nome"
	 */
	public void setNome(String nome) {
		this.nome = nome;
	}

	/**
	 * @uml.property  name="qualit�"
	 */
	private String qualit� = "BUONISSIMO!";

	/**
	 * Getter of the property <tt>Qualit�</tt>
	 * @return  Returns the qualit�.
	 * @uml.property  name="Qualit�"
	 */
	public String getQualit�() {
		return qualit�;
	}

	/**
	 * Setter of the property <tt>Qualit�</tt>
	 * @param Qualit�  The qualit� to set.
	 * @uml.property  name="Qualit�"
	 */
	public void setQualit�(String qualit�) {
		this.qualit� = qualit�;
	}
}