package interpreter;

public interface BooleanExpression { 
	 
	  public boolean interpreter( Context context ); 
	 
	}
