package interpreter;

public class Constant implements BooleanExpression { 
	 
	 boolean value; 
	 
	 public Constant(boolean val) { 
	  value = val; 
	 } 
	 
	 public boolean interpreter(Context context) { 
	  return value; 
	 } 
	 
	}
