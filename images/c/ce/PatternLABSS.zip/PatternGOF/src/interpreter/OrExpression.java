package interpreter;

public class OrExpression implements BooleanExpression{ 
	 
    BooleanExpression operand1, operand2; 

    public OrExpression(BooleanExpression op1, BooleanExpression op2) { 
 operand1 = op1; 
 operand2 = op2; 
    }  

    public boolean interpreter(Context context) { 
 return operand1.interpreter(context) ||  
            operand2.interpreter(context); 
    } 

}
