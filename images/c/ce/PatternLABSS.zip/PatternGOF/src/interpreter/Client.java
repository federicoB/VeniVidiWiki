package interpreter;


/**
 * @uml.dependency   supplier="interpreter.Context"
 * @uml.dependency   supplier="interpreter.BooleanExpression"
 */
public class Client { 
	 
	 public static void main( String[] args ) { 
	 
	   // Creo 2 Variabili q e p
	   VariableExpression p = new VariableExpression( "p" ); 
	   VariableExpression q = new VariableExpression( "q" ); 
	 
	   // Expression: "(true AND p) OR ( q AND NOT p )"  
	   BooleanExpression expr = new OrExpression(  
	                             new AndExpression( new Constant(true), p ), 
	                             new AndExpression(q, new NotExpression(p)) 
	    ); 
	 
	   // Creo il nuovo contesto
	   Context context = new Context(); 
	 
	   // Nel contesto Assegno a p il valore true e a q il valore true
	   context.assign( p, true ); 
	   context.assign( q, true ); 
	   System.out.println( "(p=true,q=true) The result is: "+ expr.interpreter( context ) ); 
	 
	   context.assign( p, true ); 
	   context.assign( q, false ); 
	   System.out.println( "(p=true,q=false) The result is: "+ expr.interpreter( context ) );
	   
	   context.assign( p, false ); 
	   context.assign( q, true ); 
	   System.out.println( "(p=false,q=true) The result is: "+ expr.interpreter( context ) ); 
	 
	   context.assign( p, false ); 
	   context.assign( q, false ); 
	   System.out.println( "(p=false,q=false) The result is: "+ expr.interpreter( context ) ); 
	      
	  } 
	 
}
