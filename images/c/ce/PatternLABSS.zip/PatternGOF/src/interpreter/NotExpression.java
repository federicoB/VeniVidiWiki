package interpreter;

public class NotExpression implements BooleanExpression { 
	 
	 BooleanExpression operand; 
	 
	 public NotExpression(BooleanExpression op) { 
	  operand = op; 
	 }  
	 
	 public boolean interpreter(Context context) { 
	  return ! operand.interpreter(context); 
	 } 
	 
	}
