package abstractFactoryGOF;


/**
 * @uml.dependency   supplier="abstractFactoryGOF.ConcreteProduct_A_2"
 */
public class ConcreteFactory_2 implements AbstractFactory {

	public AbstractProduct_A CreateConcreteProduct_A() {
		AbstractProduct_A A_2 = new ConcreteProduct_A_2();
		return A_2.createProduct_A();
	}

	public AbstractProduct_B CreateConcreteProduct_B() {
		AbstractProduct_B B_2 = new ConcreteProduct_B_2();
		return B_2.createProduct_B();
	}

}
