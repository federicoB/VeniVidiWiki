package abstractFactoryGOF;


public interface AbstractProduct_A {

		
		/**
		 */
		public abstract AbstractProduct_A createProduct_A();
		
}
