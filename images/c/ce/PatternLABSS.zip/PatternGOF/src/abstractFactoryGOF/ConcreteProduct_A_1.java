package abstractFactoryGOF;


public class ConcreteProduct_A_1 implements AbstractProduct_A {

	public AbstractProduct_A createProduct_A() {
		System.out.println("Sono il prodotto A_1");
		return null;
		
	}

}
