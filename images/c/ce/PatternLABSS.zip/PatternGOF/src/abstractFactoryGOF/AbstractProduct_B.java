package abstractFactoryGOF;


public interface AbstractProduct_B {

		
		/**
		 */
		public abstract AbstractProduct_B createProduct_B();
		

}
