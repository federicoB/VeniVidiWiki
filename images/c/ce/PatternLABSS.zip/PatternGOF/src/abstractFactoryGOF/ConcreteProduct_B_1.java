package abstractFactoryGOF;


public class ConcreteProduct_B_1 implements AbstractProduct_B {

	public AbstractProduct_B createProduct_B() {
		System.out.println("Sono il prodotto B_1");
		return null;
		
	}

}
