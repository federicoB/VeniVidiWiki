package abstractFactoryGOF;


public class ConcreteProduct_A_2 implements AbstractProduct_A {

	public AbstractProduct_A createProduct_A() {
		System.out.println("Sono il prodotto A_2");
		return null;
	}

}
