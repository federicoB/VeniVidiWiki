package abstractFactoryGOF;


public class ConcreteProduct_B_2 implements AbstractProduct_B {

	public AbstractProduct_B createProduct_B() {
		System.out.println("Sono il prodotto B_2");
		return null;
		
	}

}
