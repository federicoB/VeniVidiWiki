package abstractFactoryGOF;


/**
 * @uml.dependency   supplier="abstractFactoryGOF.AbstractProduct_A"
 * @uml.dependency   supplier="abstractFactoryGOF.AbstractFactory"
 * @uml.dependency   supplier="abstractFactoryGOF.AbstractProduct_B"
 */
public class Cliente {
	public static void main(String args[]){
		int i = 0;
		
		while (i!=4){
			
			switch (i){
			
			case 0:
				AbstractFactory factory = new ConcreteFactory_1();
				@SuppressWarnings("unused")
				AbstractProduct_A newA_1 = factory.CreateConcreteProduct_A();
				break;
				
			case 1:
				factory = new ConcreteFactory_1();
				@SuppressWarnings("unused")
				AbstractProduct_B newB_1 = factory.CreateConcreteProduct_B();
				break;
				
			case 2:
				factory = new ConcreteFactory_2();
				@SuppressWarnings("unused")
				AbstractProduct_A newA_2 = factory.CreateConcreteProduct_A();
				break;
				
			case 3:
				factory = new ConcreteFactory_2();
				@SuppressWarnings("unused")
				AbstractProduct_B newB_2 = factory.CreateConcreteProduct_B();
				break;
			}
			i++;
		}
		
	}
}
