package abstractFactoryGOF;


public interface AbstractFactory {

		
		/**
		 */
		public abstract AbstractProduct_A CreateConcreteProduct_A();

			
		/**
		 */
		public abstract AbstractProduct_B CreateConcreteProduct_B();
			
		

}
