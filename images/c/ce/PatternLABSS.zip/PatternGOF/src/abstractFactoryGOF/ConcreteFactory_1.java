package abstractFactoryGOF;


public class ConcreteFactory_1 implements AbstractFactory {

	public AbstractProduct_A CreateConcreteProduct_A() {
		AbstractProduct_A prd_A_1 = new ConcreteProduct_A_1();
		return prd_A_1.createProduct_A();
		
	}

	public AbstractProduct_B CreateConcreteProduct_B() {
		AbstractProduct_B prd_B_1 = new ConcreteProduct_B_1();
		return prd_B_1.createProduct_B();
		
	}


}
