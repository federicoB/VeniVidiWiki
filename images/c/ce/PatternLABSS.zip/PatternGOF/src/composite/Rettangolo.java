package composite;

class Rettangolo implements Graphic{

	public void print(){
			System.out.println("Rettabgolo");
	}
}
