package composite;

class Cerchio implements Graphic{

	public void print(){
		System.out.println("Cerchio");
	}
	
}
