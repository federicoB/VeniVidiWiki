package composite;

/**
 * @uml.dependency   supplier="composite.Ellisse"
 * @uml.dependency   supplier="composite.CompositeGraphic"
 * @uml.dependency   supplier="composite.Graphic"
 * @uml.dependency   supplier="composite.Rettangolo"
 * @uml.dependency   supplier="composite.Cerchio"
 */
public class Client {
	 
    public static void main(String[] args) {
        //Inizializza quattro ellissi
        Ellisse ellisse1 = new Ellisse();
        Ellisse ellisse2 = new Ellisse();
        Ellisse ellisse3 = new Ellisse();
        Ellisse ellisse4 = new Ellisse();
 
        //Inizializza due cerchi
        Cerchio cerchio1 = new Cerchio();
        Cerchio cerchio2 = new Cerchio();
        
        //Inizializza un rettangolo
        Rettangolo rettangolo = new Rettangolo();
        
        //Inizializza tre grafici composti
        CompositeGraphic graphic = new CompositeGraphic();
        CompositeGraphic graphic1 = new CompositeGraphic();
        CompositeGraphic graphic2 = new CompositeGraphic();
 
        //Compone i grafici
        graphic1.add(ellisse1);
        graphic1.add(ellisse2);
        graphic1.add(ellisse3);
        graphic1.add(cerchio1);
 
        graphic2.add(ellisse4);
        graphic2.add(rettangolo);
        graphic2.add(cerchio2);
 
        graphic.add(graphic1);
        graphic.add(graphic2);
 
        //Stampa i grafici completi
        graphic.print();
    }
}
