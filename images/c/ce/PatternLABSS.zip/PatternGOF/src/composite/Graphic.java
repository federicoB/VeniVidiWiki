package composite;

public interface Graphic {

		public abstract void print();
		

}
