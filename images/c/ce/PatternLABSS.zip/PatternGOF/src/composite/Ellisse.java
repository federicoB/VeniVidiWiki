package composite;

class Ellisse implements Graphic {
	 
    //Stampa il grafico.
    public void print() {
        System.out.println("Ellisse");
    }
 
}