/*
 * Es 1 2006/02/15
 *
 * Scrivere un programma C che prese in input da riga comando il pathname di molteplici FIFO (almeno 1, numero
 * imprecisato) metta in output tutto cio' che arriva da qualsiasi di esse.
 * Il programma non deve usare fork ma una chiamata a scelta fra select o poll.
 */
#include <stdio.h>
#include <errno.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>

#include <sys/types.h>
#include <sys/stat.h>
#include <sys/time.h>
#include <sys/stat.h>
#include <poll.h>

#define BUFF_SIZE 20

int open_pipe(char * path);

int main( int argc, char **argv )
{
int i, j; /* indice per i cicli for */
int ret, nread;
const int nume_pipe = argc - 1;
char buff[BUFF_SIZE];
struct pollfd *fds;

	/* Controllo se ci sono abbastanza argomenti */
	if (argc <= 1)
	{
		printf( "Argomenti insufficenti : serve alemno in file FIFO\n" );
		exit( 1 );
	}
	
	/* Alloco lo spazio per i descrittori */
	fds = malloc( sizeof(struct pollfd) * nume_pipe );
	if ( fds == NULL )
	{
		perror("Main: fds = malloc( sizeof(int) * ( argc - 1 ) )");
		exit(1);
	}
	
	/* Apro tutte le pipe */
	for ( i = 1; i < argc; i++ )
	{
		fds[i-1].fd = open_pipe( argv[i] );
		fds[i-1].events = POLLIN | POLLHUP;
	}
	
	while ( 1 )
	{
		ret = poll(fds, nume_pipe, -1);
		
		if ( ret == -1 )
		{
			if ( errno == EINTR )		
				continue;
			else
			{
				perror( "Main ret = poll(fds, nume_pipe, -1)" );
				exit( 1 );
			}
		}
		
		/* Controllo su quale pipe è avvenuto cosa */
		for ( i = 0; i < nume_pipe; i++ )
		{
			if ( fds[i].revents & POLLIN  )
			{
				do /* Leggo e stampo tutto il contenuto della pipe sino a che non la svuoto */
				{
					nread = read( fds[i].fd, buff, BUFF_SIZE );
					
					if (nread) {
						write( STDOUT_FILENO, buff, nread );
					}
			
				} while (nread);
			}
			
			if ( fds[i].revents & POLLHUP ) /* L'altra applicazione ha chiusola pipe */
			{
				/* Chiudo anchio la  pipe e la riapro */
				close( fds[i].fd );
				fds[i].fd = open_pipe( argv[i+1] );
			}
		}
	}

	return 0;
}

int open_pipe(char * path)
{
	struct stat file_info;
	int fd;
	 
	fd = open( path, O_RDONLY | O_NONBLOCK );
	
	if ( fd < 0 ) {
		perror("open_pipe: fd = open( argv[i], O_RDONLY | O_NONBLOCK )");
		fprintf(stderr, "File accusato \"%s\"\n", path);
		exit(1);
	}
	
	if ( fstat( fd, &file_info) == -1 )  {
		perror("open_pipe: fstat( fds, &file_info) == -1)");
		exit(1);
	}
		
	if ( !S_ISFIFO( file_info.st_mode ) ) {
		fprintf(stderr, "open_pipe: file \"%s\" is not a FIFO\n", path);
		exit(1);
	}
	
	return fd;
}
