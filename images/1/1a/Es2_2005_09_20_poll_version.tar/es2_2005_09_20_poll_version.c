/*
 * Esercizio 2 20/9/2005
 *  Scrivere un programma che funzioni da “terminale” in grado di comunicare tramite due named pipe (fifo) con un
 * programma gemello.
 * Es. dopo aver creato due fifo di nome f1 e f2 in una finestra si scrive:
 * $ fifoterm f1 f2
 * in un'altra finestra
 * $ fifoterm f2 f1
 * tutto quello che si digita in una finestra deve comparire nella seconda e viceversa.
 * Ogni carattere letto in input deve essere posto su uno dei due fifo (diciamo quello indicata come secondo parametro) e cio'
 * che viene letto dall'altro fifo viene posto in output
 * Suggerimenti (aprire le fifo con parametri O_RDWR | O_NONBLOCK, leggere il manuale di poll o di select).
 */

#include <stdio.h>
#include <sys/types.h>
#include <unistd.h>
#include <assert.h>
#include <sys/time.h>
#include <sys/types.h>
#include <stdlib.h>
#include <errno.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <poll.h>

#define DIM 25

#define DIM_FDS 2


int main(int argc, char **argv)
{
int read_pipe, write_pipe, nread, ret;
char buff[DIM];
fd_set allreadfd, readfd;
struct pollfd fds[DIM_FDS];

	assert(argc >= 3);
	
	printf("*** Aspettate che dall'altro terminale qualcuno si colleghi ***\n");
	
	read_pipe = open(argv[1], O_RDONLY | O_NONBLOCK);
	assert(read_pipe != -1);
	
	write_pipe = open(argv[2], O_WRONLY );
	assert(write_pipe != -1);
	
	fds[0].fd = STDIN_FILENO;
	fds[0].events = POLLIN;
	fds[1].fd = read_pipe;
	fds[1].events = POLLIN | POLLHUP;
	
	printf("*** Pronti a chatare! premere Ctrl-D per uscire ***\n");
	
	while(1) {
		ret = poll(fds, DIM_FDS, -1);
				
		if (ret == -1) {
			if (errno == EINTR) {
				printf("Iterrotto\n");
				continue;
			}
			perror("poll");
			exit(1);
		}
		
		
		if (fds[1].revents & POLLHUP) { /* L'altro terminale ha chiuso la pipe, quindi esco */
			break;
		}
		
		
		if (fds[0].revents & POLLIN) { /* C'e' qualcosa da leggere sulo STDIN */
			nread = read(fds[0].fd, buff, DIM);
			
			if (nread == 0)
				break; /* E' stato premuto Ctrl^D*/
			else
				write(write_pipe, buff, nread); /* Invio il messaggio */
		}
		
		if (fds[1].revents & POLLIN) { /* Mihanno inviato un messaggio */
			nread = read(fds[1].fd, buff, DIM);
			write(STDOUT_FILENO, buff, nread);
		}
		
		
	}
	
	close(read_pipe);
	close(write_pipe);
	printf("*** Chat chiusa ***\n");
	return 0;
}
