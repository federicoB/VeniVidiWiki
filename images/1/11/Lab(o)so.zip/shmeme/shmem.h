/* NOTA: RICORDATI DI COMPILARE CON IL FLAG -lrt */

#include <sys/mman.h>               
#include <sys/types.h>
#include <sys/stat.h>
#include <stdio.h>                               
#include <fcntl.h>
#include <signal.h>                          
#include <unistd.h>
#include <string.h>
#include <errno.h>
#include <stdlib.h>
#include <stdio.h>
#include <mqueue.h>

/* *************************************************************************
 *
 *  Functions for POSIX shared memory
 *
 * ************************************************************************* */
/*
 * Function CreateShm:
 * Create a POSIX shared memory segment and map it to the current process.
 *
 *
 * Input:  a pathname
 *         the shared memory segment size
 *         the permissions
 *         the fill value
 * Return: the address of the shared memory segment (NULL on error)
 */
static inline void * CreateShm(char * shm_name, off_t shm_size, mode_t perm, char fill) 
{
    void * shm_ptr;
    int fd;
    int flag;
    /* first open the object, creating it if not existent */
    flag = O_CREAT|O_EXCL|O_RDWR;
    fd = shm_open(shm_name, flag, perm);    /* get object file descriptor */
    if (fd < 0) { 
	perror("errore in shm_open");
	return NULL;
    }
    /* set the object size */
    if (ftruncate(fd, shm_size)) {
	perror("errore in ftruncate");
	return NULL;
    }
    /* map it in the process address space */
    shm_ptr = mmap(NULL, shm_size, PROT_WRITE|PROT_READ, MAP_SHARED, fd, 0);
    if (shm_ptr == MAP_FAILED) {
	perror("errore in mmap");
	return NULL;
    }
    memset((void *) shm_ptr, fill, shm_size);                /* fill segment */
    return shm_ptr;
}
/*
 * Function FindShm:
 * Find a POSIX shared memory segment 
 * Input:  a name
 *         the shared memory segment size
 * Return: the address of the segment (NULL on error)
 */
static inline void * FindShm(char * shm_name, off_t shm_size) 
{
    void * shm_ptr;
    int fd;                           /* ID of the IPC shared memory segment */
    /* find shared memory ID */
    if ((fd = shm_open(shm_name, O_RDWR|O_EXCL, 0)) < 0) {
	printf("Cannot open %s\n", shm_name);
	return NULL;
    }
    /* take the pointer to it */
    shm_ptr = mmap(NULL, shm_size, PROT_WRITE|PROT_READ, MAP_SHARED, fd, 0);
    if (shm_ptr == MAP_FAILED) {
	return NULL;
    }
    return shm_ptr;
}
/*
 * Function RemoveShm:
 * Remove a POSIX shared memory segment 
 * Input:  the object name
 * Return: 0 on success, -1 on error
 */
static inline int RemoveShm(char * shm_name)
{
    shm_unlink(shm_name);
    return 0;
}



/**** EASY++ */
static inline void *initSHM(char* NAME, off_t SIZE) {
	void *pos;
	if ((!(pos=FindShm(NAME,SIZE)))&& (!(pos=CreateShm(NAME,SIZE,0666,(char)0)))) 
		exit(1);
	return pos;
}

static inline void exitSHM(char* name) { RemoveShm(name); } 

