#include "shmem.h"

#ifndef uint
#define uint 	unsigned int
#endif

typedef struct {

	char  ready_read;
	char  ready_write;
	char  buffer[512];
	int   volte;

} shmem_data;

#define NAME	"sistemioperativi"
#define SIZE	sizeof(shmem_data)
#define false	(char)0
#define true	(char)1

int main(int argc, char* argv[]) {
	
	shmem_data* pos;
	pos=(shmem_data*)initSHM(NAME,SIZE);
	
	printf("ok...\n");
	
	
#ifdef SENDER

	pos->ready_read=false;
	pos->ready_write=true;
	pos->volte=argc;
	int i;
	
	for (i=0; i<argc; i++) {
		strcpy(pos->buffer,argv[i]);
		pos->ready_write=false;
		pos->ready_read=true;
		if (i<argc-1) while (!(pos->ready_write));
	}

#else
	int n,i;
	while (!(pos->ready_read)); //È ok perché l'area è inizializzata con zeri
	n = pos->volte;
	for (i=0; i<n; i++) {
		printf("%s\n", pos->buffer);
		pos->ready_read=false;
		pos->ready_write=true;
		if (i<n-1) while (!(pos->ready_read));
	}

#endif
	
	exitSHM(NAME);
	return 0;

}
