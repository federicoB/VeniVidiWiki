#ifndef _PL_H_
#define _PL_H_

/**
 *  distance()
 *
 * MACRO DI CALCOLO
 * ----------------
 * Permette di effettuare il calcolo in quale posizione si trova ptr2 rispetto 
 * a ptr1, sapendo che sono puntatori con la stessa dimensione in memoria
 */
#define distance(ptr1,ptr2) ((!(sizeof(ptr1)==sizeof(ptr2))) ? -1 : (((ptr2)-(ptr1))/sizeof(*ptr1)))


/**
 *  kassert()
 * 
 * FUNZIONE DI DEBUG
 * -----------------
 * Controlla che sia presente effettivamente quel dato valore 
 */
#define kassert(a,b) _kassert((int)a,b,__FILE__,__LINE__)
 
static inline void _kassert(int test, char* string, char* file, int line) {
	if (!test) {
		printf("DEBUG ERROR [%s line %d]: \"%s\" \n", file, line, string );
		exit(0);
	}
}

/**
 *  haspos()
 * Dato un campo di testo \a text dove deve essere cercato \a BASE dalla 
 * posizione \a pos in \a text, restituisce -1 se BASE è inesistente dal primo
 * suo carattere, altrimenti la posizione successiva all'ultimo carattere in BASE
 */
static inline int haspos(char* text, char* BASE, int pos) {
	int i;
	for (i=0;i<strlen(BASE); i++)
		if ((!(text[pos+i]==BASE[i]))&&(!(BASE[i]=='\0'))) return -1;
	return pos+i;
}

/**
 *  surfto()
 * Dato un campo di testo \a text, si vuole cercare dal suo inizio il carattere 
 * base: verrà restituita la posizione successiva al ritrovamento del carattere,
 * altrimenti NULL
 */
static inline char* surfto(char* text, char base) {
	int i;
	for (i=0; i<strlen(text); i++)
		if (text[i]==base) return &text[i+1];
	return NULL;
}

/**
 *  atreturns() 
 * 
 * FUNZIONE DI PARSING/LEXING
 * --------------------------
 * Restituisce eventualmente il puntatore alla stringa dopo due andate a capo 
 */
static inline char* atreturns(char* buf,int len) {
	int  end=0;
	for (end=0; end<len; end++)
		if ((end>0)&&(buf[end]==buf[end-1])&&(buf[end]=='\n')) return &buf[end+1];
	return NULL;
}

/**
 *  atreturn() 
 * 
 * FUNZIONE DI PARSING/LEXING
 * --------------------------
 * Restituisce eventualmente il puntatore alla stringa dopo una andata a capo
 */
static inline char* atreturn(char* buf,int len) {
	int  end=0;
	for (end=0; end<len; end++)
		if (buf[end]=='\n') return &buf[end+1];
	return NULL;
}


#endif
