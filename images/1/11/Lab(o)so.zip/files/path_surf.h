#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <arraystr.h>

#ifndef _FOLDERS_H_
#define _FOLDERS_H_

/** getcwdname(): returns the name (without the path) of the current directory */
static inline char* getcwdname() {
	char *d, *e;
	d=(char*)get_current_dir_name();
	e=d+strlen(d)-1;
	
	while (*e!='/') *e--;
	*e++;
	return e;
}

/** getcwdpace(): returns the name at a depth of \a pace */
static inline char* getcwdpace(int pace) {
	char *d, *e;
	int f;
	d=(char*)get_current_dir_name();
	e=d+strlen(d)-1;

	if (!pace) {
	   *(e+1)='\0';
	   return (char*)(e+1);//the empty string
	}
	
	for (f=0; f<pace; f++) 
	  { while (*e!='/') *e--;
	    *e--;
	  }

	*e++; *e++; //f==0 only if pace=0
	return e;
}

/** getcwdup(): returns the path going up \a pace times the cwd */
static inline char* getcwdup(int pace) {
	char *d, *e;
	int f;
	d=(char*)get_current_dir_name();
	e=d+strlen(d)-1;
	if (pace) { 
	 for (f=0; f<pace; f++) 
	  { while (*e!='/') *e--;
	    *e--;
	  }
	 e[1]='\0';
	}
	return d;
}

/** mkblank(): creates a blank \a path file */
static inline void mkblank(char* path) {
	FILE *k;
	if (!(k=(fopen(path, "a+")))) {
	  printf("Error opening %s in %s\n", path, (char*)get_current_dir_name());
	  exit(0);
	} else  fclose(k);
}

/** mkdir2(): creates \a path folder with 0777 */
static inline void mkdir2(char* path) {
	mkdir(path, 0777);
}

#endif
