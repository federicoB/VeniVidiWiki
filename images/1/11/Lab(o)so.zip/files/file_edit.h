/** @file: 	files.c
 *  @author:	Giacomo Bergami <giacomo90@libero.i>
 *  @notes:	This module makes the file editation more easy 
 */

#ifndef __DATABASE__H__
#define __DATABASE__H__

#include <stdio.h>
#include <stdlib.h>
#include <string.h>


typedef struct {
   char* filename;     //filename
   char  openmode[3];   //current open mode
   FILE* flow;         //Cstandard File
   long  pos;           //previous file position
} EFile;


/** Eopen(): similar to fopen, but returns an EFile structure */
static inline EFile* Eopen(char* path, char* mode) {
   unsigned int len = strlen(path);
   FILE *retin;
   EFile *ret;

   
   retin=fopen(path, mode);
   if (!retin) return NULL;
   ret=(EFile*)malloc(sizeof(EFile));
   ret->flow=retin;
   ret->filename=(char*)malloc(sizeof(char)*len);
   strcpy(ret->openmode, mode);
   strcpy(ret->filename, path);
   ret->pos=0;
   return ret;
}

/** Eclose(): Deallocates the given EFile pointer. For reestablish
 *            an opening use "rEopen" */
static inline void Eclose(EFile* fri) {
   free(fri->filename);
   if (fri->flow) fclose(fri->flow);
  
   free(fri);
}

/** rEopen(): Given a file, closes the previous operation on it,
 *            stores the previous position and uses the other opening mode.
 *            If an error occurred, the previous position is returned, else -1 */
static inline long rEopen(EFile* fi, char* mode) {
   FILE *fl;

   fl=freopen(fi->filename, mode, fi->flow);
   if (!fl) {
     long toret=fi->pos;
     fi->flow=NULL;
     Eclose(fi);
     return toret;
   } 
   strcpy(fi->openmode, mode);
   return -1;
}


/** fgetn(): returns in a buffer buf the containt of \a path until
 *           \a path is EOF: if the record exceedes \a size,
 *           it returns the size and returns to read the same line, if buf
 *           is ok, returns the size and copies the data to fgetn. if EOF is reached, returns 0 */
static inline unsigned int fgetn(char *buf, unsigned int size, EFile *path) {
    char *tmp, *c;
    unsigned int count=0;
    char donotstore=0;
    char isEOF=0;

    //give at least a char for allocate data
    if (!size) c=tmp=(char*)malloc(sizeof(char));
    else c=tmp=(char*)malloc(sizeof(char)*size);

    // get chars until newline or EOF
    do {
        //store in a new position the read iif the bufsize is not exeeded
        if (!donotstore) *c++=getc(path->flow);
     	else  *(c-1)=getc(path->flow);
     	//printf("%c", *(c-1));
     	count++;
     	if (count>size) donotstore=1;	  //if size is exeeded
    } while (*(c-1)!=EOF);
    
    if (*(c-1)==EOF) 
       isEOF=1;

    if (count>size) {		          //if the buf is small
     	free(tmp);			  //frees the tmp allocator
     	fseek(path->flow, -count, SEEK_CUR);    //rewinds the file before the new reading
     	return count;		  //returns the actual data size
    }
    
    *(c-1)='\0';			  //sets string termination
    strcpy(buf, tmp);			  //copies the entry in the buffer from tmp
    free(tmp);				  //frees the tmp allocator
    return count;
}

/** fgetalloc(): given the file \a path, returns a pointer to an allocated data */
static inline char* fgetalloc(EFile *path) {
    char *tmp;
    unsigned int storage=fgetn(NULL, 0, path); //gets the record size
    
    rEopen(path,path->openmode);
    
    if (storage) {
	tmp=(char*)malloc(sizeof(char)*(storage+1));
	if (fgetn(tmp, storage, path)) { tmp[storage]='\0'; return tmp; }
        else { free(tmp); return NULL;} 
    } else  return NULL;

}

/** contains(): returns if a \a file contains a certain line; it will save the previous state */
static inline int contains(EFile *f, char *string) {
	char *j;
	int toret=0;
	long curpos=ftell(f->flow);  // stores the current file location
	fseek(f->flow, 0, SEEK_SET); // starts from the beginning

	j=fgetalloc(f);
	while ((j)&&(!toret)) 	  // while there is some file
	    { if (strcmp(j,string)) toret=1;
	      free(j);
	      j=fgetalloc(f);
 	    }

	fseek(f->flow, curpos, SEEK_SET); // returns back to the previous position
	return toret;
}

/** structE(): given a file \a f, it returns an EFile struct, with null path,
    pos set at the current position and the FILE pointer */
static inline EFile* structE(FILE *f) {
	EFile *j;
	j=(EFile*)malloc(sizeof(EFile));
	j->flow=f;
	j->filename=NULL;
	j->pos=ftell(f);
	j->openmode[0]='\0';
	return j;
}

/** Etmp(): returns a temp file with null values exept of FILE record*/
static inline EFile* Etmp() {
	FILE* tmp;
	tmp=tmpfile();
	return structE(tmp);
}

/** removeatline(): removes the first occurence of \a str from the \a file.
                    it won't save the previous state. The FILE will be closed. */
static inline void removeatline( char*file,char* str, unsigned int outline) {

	EFile 		*tmp, *f;
	char  		*j;
	char  		changes=0;
	char  		pvmode[3];
	unsigned int 	cnt=0;
	
	tmp=Etmp(); 					//creates a temporary file
	f=Eopen(file, "r");				//reopens the current file in read mode

	j=fgetalloc(f);
	while (j)      					//until there is some file
	   {  if ((strcmp(j, str))||(cnt<outline))  	//iif there is no match
	           fprintf(tmp->flow, "%s\n", j);	//copy the data from the file     
	      else changes=1;           		//else there is at least one line to change
	      free(j);
	      j=fgetalloc(f);
	      if (cnt<outline) cnt++;
 	   }

	rEopen(f, "w");
	rewind(tmp->flow);			//rewinds the tmp

	if (changes) {			//iif some changes were committed
	     j=fgetalloc(tmp);
	     while (j)
	        {  fprintf(f->flow, "%s\n", j);//copy the entire modified file
	           free(j);
	           j=fgetalloc(tmp);
	        }
	}


	Eclose(f);	     //closes definetively the flow
	fclose(tmp->flow);   //breaks the temporary file

}


static inline void EAppendStr(EFile* path, char* str) {
	unsigned int len = strlen(str);
	rEopen(path,"a");		//open the file in Append Mode
	fprintf(path->flow,"%s",str);
	path->pos+=len;
}

#endif
