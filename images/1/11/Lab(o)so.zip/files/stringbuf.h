#include <string.h>

/** revcpy():
 *  funzione che copia il buffer di memoria invertito 
 */
static inline void revcpy(char* orig, char* dest, int len) {
	int i, j;
	j=len-1;
	i=0;
	while (i<len) {
		dest[j-i]=orig[i];
		i++;
	}
}

/** revcmp():
 *  effettua il confronto tra il contenuto di due elementi 
 */
static inline int revcmp(char* orig, char* dest, int len) {
	int i;
	while ((*orig++==*dest++)&&(i<=len)) i++;
	return (i==len);
}
