#include <errno.h>
#include <unistd.h>
#include <string.h>

#ifndef FINEDIMONDO
#define FINEDIMONDO 42
#endif

static inline void do_nothing() { }

static inline writefd(int fd, void* buf, size_t len) {
	while (FINEDIMONDO) {
		int n = write(fd,buf,len);
		if ((n==-1)&&((errno==EINTR)||(errno==EAGAIN)))
			do_nothing();
		else if (n==-1)
			return -errno;
		else
			return n;
	}
}

static inline readfd(int fd, void* buf, size_t len) {
	while (FINEDIMONDO) {
		int n = read(fd,buf,len);
		if ((n==-1)&&((errno==EINTR)||(errno==EAGAIN)))
			do_nothing();
		else if (n==-1)
			return -errno;
		else
			return n;
	}
}

/** getstring():
 *  Legge in input una stringa fino al carattere di invio 
 */
static inline char* getstring() {
	char buf1[1024];
	int i=0;
	char *k, *tmp;
	
	k=buf1;
	while (((*k++=getchar())!='\n')&&(i++<1024));
	*k='\0';
	tmp=(char*)malloc(sizeof(char)*strlen(buf1));
	strcpy(tmp,buf1);
	return tmp;
}
