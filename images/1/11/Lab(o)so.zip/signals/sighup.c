/* ---------------------------------------------------------------- */
/* PROGRAM  sig-0.c:                                                */
/*    This is a simple program that illustrates the use of signal   */
/* handler.  It catches Ctrl-C.                                     */
/* ---------------------------------------------------------------- */

#include  <stdio.h>
#include  <signal.h>
#include <unistd.h>
#include <stdlib.h>

FILE *ptr;
char buffer[1024];
int i=1;

int make_string(char* bufferings, int i, int len) {
	int gotlen = snprintf(NULL, 0, "%s%d", "file", i);
	if (gotlen>len)
		return gotlen;
	sprintf(bufferings,"%s%d","file",i);
	return 0;
}

void  INThandler(int sig)
{
     char  c;

     signal(sig, SIG_IGN);              /* disable Ctrl-C           */

	//Scrivo nel buffer il nome del file
	if (make_string(buffer,i++,1024)) {
	  	printf("Unable to make new file stirng\n");
		exit(1);
	} else printf("\n{%d}\n", i-1);

	fflush(ptr);
	freopen(buffer,"w+",ptr);

     signal(sig, INThandler);   /* reinstall the handler    */
}




void  main(void)
{
     

     
     //Scrivo nel buffer il nome del file
     if (make_string(buffer,i++,1024)) {
     	printf("Unable to make new file stirng\n");
        exit(1);
     }
     
     //Gestore del segnale
     signal(SIGHUP,INThandler);
     
     ptr = fopen(buffer, "w+");
 
     while (42) {
     	fprintf(ptr,"%c", getchar());
     }    
}
