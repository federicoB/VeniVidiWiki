#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>
#include <mqueue.h>

#include <sys/mman.h>               
#include <sys/types.h>
#include <sys/stat.h>
#include <stdio.h>                               
#include <fcntl.h>
#include <signal.h>                          
#include <unistd.h>
#include <string.h>
#include <errno.h>
#include <stdlib.h>
#include <stdio.h>
#include <mqueue.h>

int *turno;

/* *************************************************************************
 *
 *  Functions for POSIX shared memory
 *
 * ************************************************************************* */
/*
 * Function CreateShm:
 * Create a POSIX shared memory segment and map it to the current process.
 *
 *
 * Input:  a pathname
 *         the shared memory segment size
 *         the permissions
 *         the fill value
 * Return: the address of the shared memory segment (NULL on error)
 */
static inline void * CreateShm(char * shm_name, off_t shm_size, mode_t perm, char fill) 
{
    void * shm_ptr;
    int fd;
    int flag;
    /* first open the object, creating it if not existent */
    flag = O_CREAT|O_EXCL|O_RDWR;
    fd = shm_open(shm_name, flag, perm);    /* get object file descriptor */
    if (fd < 0) { 
	perror("errore in shm_open");
	return NULL;
    }
    /* set the object size */
    if (ftruncate(fd, shm_size)) {
	perror("errore in ftruncate");
	return NULL;
    }
    /* map it in the process address space */
    shm_ptr = mmap(NULL, shm_size, PROT_WRITE|PROT_READ, MAP_SHARED, fd, 0);
    if (shm_ptr == MAP_FAILED) {
	perror("errore in mmap");
	return NULL;
    }
    memset((void *) shm_ptr, fill, shm_size);                /* fill segment */
    return shm_ptr;
}
/*
 * Function FindShm:
 * Find a POSIX shared memory segment 
 * Input:  a name
 *         the shared memory segment size
 * Return: the address of the segment (NULL on error)
 */
static inline void * FindShm(char * shm_name, off_t shm_size) 
{
    void * shm_ptr;
    int fd;                           /* ID of the IPC shared memory segment */
    /* find shared memory ID */
    if ((fd = shm_open(shm_name, O_RDWR|O_EXCL, 0)) < 0) {
	printf("Cannot open %s\n", shm_name);
	return NULL;
    }
    /* take the pointer to it */
    shm_ptr = mmap(NULL, shm_size, PROT_WRITE|PROT_READ, MAP_SHARED, fd, 0);
    if (shm_ptr == MAP_FAILED) {
	return NULL;
    }
    return shm_ptr;
}
/*
 * Function RemoveShm:
 * Remove a POSIX shared memory segment 
 * Input:  the object name
 * Return: 0 on success, -1 on error
 */
static inline int RemoveShm(char * shm_name)
{
    shm_unlink(shm_name);
    return 0;
}



/**** EASY++ */
static inline void *initSHM(char* NAME, off_t SIZE) {
	void *pos;
	if ((!(pos=FindShm(NAME,SIZE)))&& (!(pos=CreateShm(NAME,SIZE,0666,(char)0)))) 
		exit(1);
	return pos;
}

static inline void exitSHM(char* name) { RemoveShm(name); } 
/*****************************************************/

#define MAX	3

int privateval[]={0,0};
int privateval2[]={0,0};
int privateval3[]={0,0};

int return_pos() {
	if (getpid()==turno[1]) 
}

void  Handler1(int sig)
{
     privateval[0]++;//Incremento: è arrivato un segnale
     signal(sig, SIG_IGN);
     if (sig==SIGUSR1) {
     	printf("~ %d handled ~\n",getpid());
     }
     else {
     	printf("%d: wrong handler\n",getpid());
     	exit(1);
     }
     signal(sig, Handler1);
}

void  Handler2(int sig)
{
     privateval[1]++;
     signal(sig, SIG_IGN);
     if (sig==SIGUSR2) {
     	printf("~ %d handled ~\n",getpid());
     }
     else {
     	printf("%d:wrong handler\n",getpid());
     	exit(1);
     }
     signal(sig, Handler2);
}


void set_handler1(struct sigaction *ssiga) {

	signal(SIGUSR1,Handler1);
	
}

void set_handler2(struct sigaction *ssiga) {
	signal(SIGUSR2,Handler2);
}

static inline int get_random_max(int max,int seed) {
	if (max>0)
		return random()%max+1;
	else 
		return random();
}

/** Nota infatti che il segnale potrebbe anche arrivare prima 
    della chiamata della gestione, in quel caso incremento il 
    valore. Alla terminazione decremento */
static inline void wait_signal1() {
	if (!privateval[0]) pause(); 
	privateval[0]--;
}

static inline void wait_signal2() {
	if (!privateval[1]) pause(); 
	privateval[1]--;
}

static inline int wait_all_signals() {
	if (privateval[0]) { privateval[0]--; return SIGUSR1; }
	else if (privateval[1]) { privateval[1]--; return SIGUSR2; }
	pause();
	if (privateval[1]) { privateval[1]--; return SIGUSR1; }
	else if (privateval[0]) { privateval[0]--; return SIGUSR2; }
}



static inline int do_son(int i) {
	int j;
	for (j=0; j<MAX; j++) {
		if (*turno+1==i) {
			int choose, result;
			if (rand()%2) choose=SIGUSR1;
			else choose=SIGUSR2;
			kill(getppid(),choose);
			result = wait_all_signals();
			if ((result==SIGUSR1)&&(!choose)) printf("%d: Ok\n", i);
			else printf("%d: Nay\n", i);
		} else {
			int scelta, result;
			scelta = wait_all_signals();
			result = wait_all_signals();
			if (scelta==result) printf("%d: No\n",i);
			else printf("%d: Si\n", i);
		}
	}
}



void main(void) {
	
	int i;
	struct sigaction ssiga1, ssiga2;
	set_handler1(&ssiga1);
	set_handler2(&ssiga2);
	srand(time(NULL));
	
	exitSHM("provetta");
	turno=initSHM("provetta",sizeof(int)*4);
	turno[3]=getpid();
	*turno=0;
	
	pid_t child[2];
	if ((child[1]=fork())==0) { set_handler1(&ssiga1); set_handler2(&ssiga2); do_son(1); }
	else if (child[1]<0) { printf("ERROR FORKING 1ST\n"); exit(1); }
	else turno[1]=child[0];
	
	if ((child[2]=fork())==0) { set_handler1(&ssiga1); set_handler2(&ssiga2); do_son(2); }
	else if (child[2]<0) { printf("ERROR FORKING 1ST\n"); exit(1); }
	else turno[2]=child[1];
	
	//Sono il padre
	for (i=0; i<MAX; i++) {
		int segnale, dice;
		
		printf("Padre: attendo\n");
		segnale = wait_all_signals();
		kill(child[*turno],segnale);
		printf("Sent signal\n");
		dice =rand()%2;
		if (dice==0) {
			kill(child[0],SIGUSR1);
			kill(child[1],SIGUSR1);
		} else {
			kill(child[0],SIGUSR2);
			kill(child[1],SIGUSR2);
		}
		*turno=(*turno%2)+1;
	}
	
	//waitpid(child[0],NULL,0);
	//waitpid(child[1],NULL,0);
	exitSHM("provetta");
	
}
