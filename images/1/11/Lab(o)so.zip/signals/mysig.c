#include  <stdio.h>
#include  <signal.h>


void  INThandler(int sig)
{
     char  c;

     signal(sig, SIG_IGN);              
	     printf("I Can Handle It: %d\n", sig);
	     exit(0);
	     
          signal(sig, INThandler);   
}

void  main(void)
{
	int i;
	for (i=1; i<NSIG; i++) signal(i, INThandler);
            
     while (1)                          /* loop forever and wait    */
          pause();                      /* for Ctrl-C to come       */
}


