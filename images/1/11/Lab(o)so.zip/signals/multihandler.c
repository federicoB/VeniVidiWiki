#include <stdio.h>
#include <string.h>

#include "forks/forka.h"
#include "pipe_fifos/pipe.h"
#include "pipe_fifos/fifo.h"
#include "files/read_write.h"

int fdtoson[2];
int fdfromnephew[2];
int fdfromson[2];

struct msg_interrupt {
	pid_t pid;
	int   no;
};

#define MSGSIZE		sizeof(struct msg_interrupt)
#define sndson(x)  	write(in_pipe(fdtoson),x,strlen(x))

/** handler():
 *  il gestore del genitore invia il messaggio al figlio
 */
void handler(int signo, siginfo_t *info, void *context) {
	struct msg_interrupt ptr;
	
	/* Writing the data structure */
	ptr.pid = info->si_pid;
	ptr.no=signo;
	
	/* Sending the structure to the son-server */
	write(in_pipe(fdtoson),&ptr,MSGSIZE);
}

/** set_handler():
 *  Inizializzazione dei gestori del padre 
 */
void set_handler() {
	int i;
	struct sigaction ssiga; 
	
	sigemptyset(&ssiga.sa_mask);
	sigfillset(&ssiga.sa_mask);
	ssiga.sa_flags = SA_SIGINFO;
	ssiga.sa_handler = handler;
	for (i=1; i<=NSIG; i++) sigaction(i, &ssiga, NULL);
}



int main(void) {
	
	int sonpid;
	int nephew;
	char test[]="testing testing testing 1 2 3";
	
	
	mkpipe(fdtoson);
	mkpipe(fdfromnephew);
	mkpipe(fdfromson);
	set_handler();
	
	if (sonpid=fork()) {
		int signo;
	
		close(out_pipe(fdtoson));
		close(in_pipe(fdfromnephew));
		close(in_pipe(fdfromson));
		
		while (FINEDIMONDO) {
		
			printf("Digit the number to signal [0-%d]: ", NSIG);
			scanf("%d", &signo);
		
			/* Se il segnale esiste dal KERNEL */
			if ((0<signo)&&(signo<=NSIG)) {
				pid_t nipote;
				char msgbuf[1024];
				
				/* Mi lancio il segnale da solo */
				raise(signo);
				printf("[gothere]\n");
				
				/* Mi informo sul nipote... */
				readfd(out_pipe(fdfromson),&nipote,sizeof(nipote));
				printf("[readedfd]\n");
				
				/* ... e lo aspetto */
				my_waitpid(nipote);
				printf("[waitednep]\n");
				
				/* Leggo che cosa mi dice il nipote */
				readfd(out_pipe(fdfromnephew),msgbuf,1024);
				
				printf("RECEIVED: %s\n",msgbuf);
				//exit(0);
			} else {
				/* Altrimenti chiudo il figlio ed esco */
				kill(sonpid,9);
				exit(0);
			}
			
			
			
		}
		
		//sndson(test);
	
	} else {
		/* SERVER FIGLIO */	
		char buf[MSGSIZE+1];
		struct msg_interrupt *ptr;
		
		ptr=(struct msg_interrupt *)buf;
		close(in_pipe(fdtoson));
		close(out_pipe(fdfromson));
		
			
		while (FINEDIMONDO) {
		
			pid_t nephew;
		
			readfd(out_pipe(fdtoson),buf,MSGSIZE);
			printf("Handled intno: %d\n", ptr->no);
			
			mkfork(&nephew);
			if (nephew) {
				/* Mando al padre l'ID del nipote da attendere all'uscita da scuola */
				printf("Printing nephew...\n");
				write(in_pipe(fdfromson),&nephew,sizeof(nephew));
				printf("Printing nephew done. EXITING\n");
				exit(0);
			} else {
				//GESTIONE DEL MESSAGGIO
				char nep_buf[1024];
				/* Posso fare ciò perchè il fork salva lo stato precedente */
				strcpy(strsignal(ptr->no), nep_buf);
				/* Mando al nonno la scritta del segnale */
				printf("Writing message to main...\n");
				write(in_pipe(fdfromnephew),nep_buf,strlen(nep_buf));
				printf("Writing message to main done.\n");
			}
			
		}
	}

	return 0;

}
