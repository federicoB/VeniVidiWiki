#include <stdio.h>
#include <string.h>

#include "forks/forka.h"
#include "pipe_fifos/pipe.h"
#include "pipe_fifos/fifo.h"
#include "files/read_write.h"

int fdtoson[2];
int fdfromnephew[2];
int fdfromson[2];

int msgdelivered, msgdone;

struct msg_interrupt {
	pid_t pid;
	int   no;
};

#define MSGSIZE		sizeof(struct msg_interrupt)
#define sndson(x)  	write(in_pipe(fdtoson),x,strlen(x))

/** handler():
 *  il gestore del genitore invia il messaggio al figlio
 */
void handler(int signo, siginfo_t *info, void *context) {
	struct msg_interrupt *ptr;
	ptr=(struct msg_interrupt *)malloc(sizeof(struct msg_interrupt));
	
	/* Writing the data structure */
	ptr->pid = info->si_pid;
	ptr->no=signo;
	
	/* Sending the structure to the son-server */
	printf("MSG received from %d as %d: [%s]\n", info->si_pid, signo,strsignal(signo));
	
	write(in_pipe(fdtoson),ptr,sizeof(struct msg_interrupt));
	free(ptr);
	msgdelivered=1;
	/* Uccido chi mi ha chiamato:  kill(info->si_pid,9); */

}

void killer(int signo, siginfo_t *info, void *context) { printf("It is a far, far better thing that I do."); exit(1); }

/** set_handler():
 *  Inizializzazione dei gestori del padre 
 */
void set_handler() {
	int i;
	struct sigaction ssiga; 
	
	sigemptyset(&ssiga.sa_mask);
	sigfillset(&ssiga.sa_mask);
	ssiga.sa_flags = SA_SIGINFO;
	ssiga.sa_handler = handler;
	for (i=1; i<=NSIG; i++) sigaction(i, &ssiga, NULL);
}


void set_killer() {
	int i;
	struct sigaction ssiga; 
	sigemptyset(&ssiga.sa_mask);
	sigfillset(&ssiga.sa_mask);
	ssiga.sa_flags = SA_SIGINFO;
	ssiga.sa_handler = killer;
	for (i=1; i<=NSIG; i++) sigaction(i, &ssiga, NULL);
}



int main(void) {
	
	pid_t thread;
	
	printf("main_pid: %d\n",getpid());
	mkpipe(fdtoson);
	msgdelivered=msgdone=0;
	
	if (thread=fork()) {
		set_handler();
		close(in_pipe(fdtoson));
		while (!msgdone); //IN ATTESA DELLA GESTIONE DELL'INTERRUPT
		printf("HANDLED\n");
	} else {
		/* Processo server */
		struct msg_interrupt ptr;
		printf("sonpid: %d\n",getpid());
		
		set_killer();
		close(out_pipe(fdtoson));
		while (!msgdelivered);
		read(out_pipe(fdtoson),&ptr,sizeof(ptr));
		printf("Recv: %d\n", ptr.no);
		exit(0);
	}


	return 0;

}
