#include <sys/mman.h>               
#include <sys/types.h>
#include <sys/stat.h>
#include <stdio.h>                               
#include <fcntl.h>
#include <signal.h>                          
#include <unistd.h>
#include <string.h>
#include <errno.h>
#include <stdlib.h>
#include <stdio.h>
#include <mqueue.h>

/* *************************************************************************
 *
 *  Functions for POSIX shared memory
 *
 * ************************************************************************* */
/*
 * Function CreateShm:
 * Create a POSIX shared memory segment and map it to the current process.
 *
 *
 * Input:  a pathname
 *         the shared memory segment size
 *         the permissions
 *         the fill value
 * Return: the address of the shared memory segment (NULL on error)
 */
static inline void * CreateShm(char * shm_name, off_t shm_size, mode_t perm, char fill) 
{
    void * shm_ptr;
    int fd;
    int flag;
    /* first open the object, creating it if not existent */
    flag = O_CREAT|O_EXCL|O_RDWR;
    fd = shm_open(shm_name, flag, perm);    /* get object file descriptor */
    if (fd < 0) { 
	perror("errore in shm_open");
	return NULL;
    }
    /* set the object size */
    if (ftruncate(fd, shm_size)) {
	perror("errore in ftruncate");
	return NULL;
    }
    /* map it in the process address space */
    shm_ptr = mmap(NULL, shm_size, PROT_WRITE|PROT_READ, MAP_SHARED, fd, 0);
    if (shm_ptr == MAP_FAILED) {
	perror("errore in mmap");
	return NULL;
    }
    memset((void *) shm_ptr, fill, shm_size);                /* fill segment */
    return shm_ptr;
}
/*
 * Function FindShm:
 * Find a POSIX shared memory segment 
 * Input:  a name
 *         the shared memory segment size
 * Return: the address of the segment (NULL on error)
 */
static inline void * FindShm(char * shm_name, off_t shm_size) 
{
    void * shm_ptr;
    int fd;                           /* ID of the IPC shared memory segment */
    /* find shared memory ID */
    if ((fd = shm_open(shm_name, O_RDWR|O_EXCL, 0)) < 0) {
	printf("Cannot open %s\n", shm_name);
	return NULL;
    }
    /* take the pointer to it */
    shm_ptr = mmap(NULL, shm_size, PROT_WRITE|PROT_READ, MAP_SHARED, fd, 0);
    if (shm_ptr == MAP_FAILED) {
	return NULL;
    }
    return shm_ptr;
}
/*
 * Function RemoveShm:
 * Remove a POSIX shared memory segment 
 * Input:  the object name
 * Return: 0 on success, -1 on error
 */
static inline int RemoveShm(char * shm_name)
{
    shm_unlink(shm_name);
    return 0;
}



/**** EASY++ */
static inline void *initSHM(char* NAME, off_t SIZE) {
	void *pos;
	if ((!(pos=FindShm(NAME,SIZE)))&& (!(pos=CreateShm(NAME,SIZE,0666,(char)0)))) 
		exit(1);
	return pos;
}

static inline void exitSHM(char* name) { RemoveShm(name); } 












#include <unistd.h>
#include <stdio.h>
#include <signal.h>
//#include "../shmeme/shmem.h"
#include "../forks/forka.h"

#define N 5

/************* STRUTTURA DATI DEI MESSAGGI *************************/
typedef struct noff {
	int 		data;
	struct noff* 	next;
} msg;

msg* new(int data) {
	msg* tmp=malloc(sizeof(msg));
	tmp->data=data;
	tmp->next=NULL;
	return tmp;
}

msg* pop(msg** ptr) {
	msg* tmp = *ptr;
	if (*ptr) {
		*ptr=(((*ptr)->next));
		return tmp;
	} else return *ptr;
}

void enqueue(int data, msg** ptr) {
	msg *tmp, *prev;
	if (*ptr) {
		tmp = *ptr;
		do prev=tmp; while (tmp=tmp->next);
		prev->next = new(data);
	} else {
		*ptr = new(data);
	}
}

void printall(msg* ptr) {
	msg *tmp;
	tmp = ptr;
	if (ptr)
		do {
			printf("%d\n", tmp->data);
		} while (tmp=tmp->next);
	printf("x\n");
}

int getlen(msg* ptr) {
	int len=0;
	msg *tmp;
	tmp = ptr;
	if (ptr)
		do {
			len++;
		} while (tmp=tmp->next);
	return len;
}
/*******************************************************************/


typedef struct {
	pid_t sonpid[2];
	msg*   mess[3];//Il primo è il padre, gli altri i sonpid
	char  turno;
	char  signal;
	int   waitingson;
} ossessi;

ossessi *ndocojocojo;

static inline int getint(pid_t p) {
	if (p==ndocojocojo->sonpid[0]) return 1;
	else if (p==ndocojocojo->sonpid[1]) return 2;
	else return 0;
}

void  INThandler(int sig, siginfo_t *info, void *context)
{
     char  C;
 
     if (sig==SIGUSR1) 
	   C=0;
     else if (sig==SIGUSR2)
	   C=1;
     
     enqueue(C,&ndocojocojo->mess[getint(getpid())]);

}

void  OUTLEN(int sig, siginfo_t *info, void *context)
{

	int i;
	printf("\n%d\n",getpid());
	for (i=0; i<3; i++)
		printf("Len %d: %d\n",i,getlen(ndocojocojo->mess[i]));
	exit(1);

}

void readsignal(char* where) {
	
	int  v = getint(getpid());
	msg *k, *ptr;
	while (!(ptr=ndocojocojo->mess[v]));
	k=pop(&ndocojocojo->mess[v]);
	
	*where=k->data;
	free(k);
}

void writesignal(char what, pid_t to) {
	int signal;
	if (what<=0) 
		signal=SIGUSR1;
	else
		signal=SIGUSR2;
	kill(to,signal);
}

void set_handler() {
	int i;
	struct sigaction ssiga, ssiga2; 
	
	sigemptyset(&ssiga.sa_mask);
	sigfillset(&ssiga.sa_mask);
	sigdelset(&ssiga.sa_mask,SIGINT);
	ssiga.sa_flags = SA_SIGINFO;
	ssiga.sa_handler = (__sighandler_t)INThandler;
	sigaction(SIGUSR1, &ssiga, NULL);
	sigaction(SIGUSR2, &ssiga, NULL);
	
	sigemptyset(&ssiga2.sa_mask);
	sigdelset(&ssiga2.sa_mask,SIGINT);
	ssiga2.sa_flags = SA_SIGINFO;
	ssiga2.sa_handler = (__sighandler_t)OUTLEN;
	sigaction(SIGINT, &ssiga2, NULL);

	
}

void  main(void)
{
	int i,j;
	ndocojocojo=(ossessi*)initSHM("disgrazia", sizeof(ossessi));
	ndocojocojo->turno=0;
	ndocojocojo->mess[0]=ndocojocojo->mess[1]=ndocojocojo->mess[2]=NULL;
	ndocojocojo->waitingson=0;
	
	srand(time(NULL));
	
	set_handler();
	
	pid_t isfather;
	pid_t isfather2;
	mkfork(&isfather);
	
	if (isfather) {
		ndocojocojo->sonpid[0]=isfather;
		mkfork(&isfather2);
		if (isfather2)
			ndocojocojo->sonpid[1]=isfather2;
	}
	
	if ((isfather)&&(isfather2)) {
		char turno=ndocojocojo->turno;
		for (j=0; j<N; j++) {
			char scelta, dice, trash;
			printf("(%d)attendo...\n",getpid());
			readsignal(&scelta);//È in attesa di ricevere la decisione di un figlio => Chi sceglie non ha ancora scelto.
			printf("\t\tefqt\n");
			writesignal(scelta,ndocojocojo->sonpid[!turno]);
			dice = (char)rand()%2;
			printf("(%d)Arbitro chooses %d ~ Recvs: %d\n",getpid(),(int)dice, scelta);
			
			while (ndocojocojo->waitingson<2);
			ndocojocojo->waitingson=0;
			printf("\t\tcjcj\n");
			
			for (i=0; i<2; i++) {
				writesignal(dice,ndocojocojo->sonpid[i]);
			}
			turno = !turno;
		}
		
	} else {
		char turno=ndocojocojo->turno;
		for (j=0; j<N; j++) {
			//Se è il mio turno
			if (getpid()==ndocojocojo->sonpid[turno]) {
			
				char sent, result;
				sent = rand()%2;
				
				printf("(%d)%d: 'I CHOOSE %d'\n",getpid(),turno,(int)sent);
				
				writesignal(sent,getppid());
				ndocojocojo->waitingson++;
				readsignal(&result);//Si blocca qui -> Attende un risultato => il server non lo invia
				//Commentando infatti questa riga tutto va avanti, e l'ultimo processo
				//a rimanere è il padre: questo perché NON RICEVE IL SEGNALE DA CHI LO INVIA.
				
				//==> c'È un casino con la gestione dei messaggi.
				
				//Però a questo punto ho già inviato un risultato (scritto un sengale)
				//Ed il padre si blocca perchè non glie l'ho inviato uno (??)
				
				if (sent==result) printf("(%d)%d: 'HURRAY!'\n",getpid(),turno);
				else  printf("(%d)%d: 'F*CK!'\n", getpid(),turno);
				turno = !turno;
				
			} else {
				char scelta, result;
				
				printf("\t\t(%d)%d: IWait\n", getpid(),!turno);
				readsignal(&scelta);//Si blocca qui => Attende di ricevere un risultato dal padre
				//Questo perchè a questo punto il punto precedente non ha ancora comunicato una
				//intenzione
				
				printf("\t\t(%d)%d: Got = %d. IWait2\n", getpid(),!turno,scelta);
				ndocojocojo->waitingson++;
				
				readsignal(&result);
				if (scelta!=result) printf("(%d)%d: 'HURRAY!'\n", getpid(),!turno);
				else  printf("(%d)%d: 'F*CK!'\n", getpid(),!turno);
				turno = !turno;
			}
			//sleep(2);
		}
	}
	
	
	
}

