#include "../files/file_edit.h"
#include "../files/parsinglexing.h"

void help() { printf("quit\n"); exit(1); }

/* Esecuzione di un miniscript */

void main(int argc, char* argv[]) {
	
	EFile* arg;
	int len;
	int cnt2=0;
	char *memoryfile, *next, *curr;
	
	
	if (argc==1) help();
	
	arg=Eopen(argv[1],"r");
	memoryfile=fgetalloc(arg);
	Eclose(arg); 

	curr=memoryfile;
	len=strlen(memoryfile);
	/* Fino alla fine della stringa */
	
	
	while (next=atreturn(curr,len)) {
		char diesis;
		int  len2;
		char *tmp, *token;
		int  cnt=0;
		
		if (strcmp(curr,"")==0) break; 
		next[-1]='\0';
		
		if ((sscanf(curr,"%c*",&diesis)==1)&&(diesis=='#')) printf(""); 
		else {
			int i=0;
			pid_t parent;
			char buf[2048];
			
			char *token[80];
			
			while(1) {
        			token[i] = strsep(&curr, " "); 
        			if (!token[i]) break;
        			else { printf("%d: %s\n", cnt2, token[i]); i++; }
        		}
        		if (parent=fork()) {
        			waitpid(parent,NULL,0);
        		} else {
        			execvp(token[0],token);
        			exit(0);
        		}
			
		}
		if (next) curr=next; else break;
		cnt2++;
	}
	
	
	free(memoryfile);
	

}
