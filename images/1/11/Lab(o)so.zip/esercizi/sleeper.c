#include <unistd.h>
#include <stdio.h>
#include <signal.h>

unsigned int i=0;

/** handler():
 *  il gestore del genitore invia il messaggio al figlio
 */
void handler(int signo, siginfo_t *info, void *context) {
	
	printf("%u\n", (int)info->si_pid);
	//Ed io uccido chi mi ha inviato il messaggio
	kill((int)info->si_pid,9);

}

/** set_handler():
 *  Inizializzazione dei gestori del padre 
 */
void set_handler() {
	int i;
	struct sigaction ssiga; 
	
	sigemptyset(&ssiga.sa_mask);
	sigfillset(&ssiga.sa_mask);
	ssiga.sa_flags = SA_SIGINFO;
	ssiga.sa_handler = handler;
	for (i=1; i<NSIG; i++)  sigaction(i, &ssiga, NULL);
}

void main(void) {
	set_handler();
	while (1) {
		sleep(1);
		i++;
	}
}
