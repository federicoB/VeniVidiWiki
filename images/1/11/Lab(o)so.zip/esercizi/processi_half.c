#include "../main_include/default.h"
#include "../pipe_fifos/pipe.h"
#include "../files/read_write.h"

int dpipe[2];

void awrite(char k) {
	int j=1;
	int i;
	char send;
	for (i=0; i<8; i++) {
		send=(char)((k&(j<<i)) ? 1 : 0);
		write(in_pipe(dpipe),&send,sizeof(char));
	}
}

char* aread(char w) {
	static char init=(char)0;
	static int  count=0;
	
	init = init | (w<<(count++));
	if (count==8) {
		char *allocco;
		allocco=(char*)malloc(sizeof(char));
		*allocco=init;
		count=0;
		init=(char)0;
		return allocco;
	}
	return NULL;

}

int main(void) {

	//Valore del figlio. Chiamato padre perché se positivo nel test è il padre
	pid_t padre; 
	
	mkpipe(dpipe);
	

	
	if (padre=fork()) {
		int server=1;
		int cnt=0;
		close(out_pipe(dpipe));
		while (server) {
			char *s, *k;
			
			//SEND
			s=getstring();
			k=s;
			while (*k)
				awrite(*k++);
			awrite(*k);
			free(s);
			//////////////////////////
			
		}
		kill(padre,9);
	} else {
		close(in_pipe(dpipe));
		while (1) {
			
			//RECEIVING
			char buf[1024];
			int i=0;
			char *w;
			char set;
			while(1) {
				do {
					read(out_pipe(dpipe),&set,sizeof(char));
				} while (!(w=aread(set)));
				buf[i]=*w;
				free(w);
				if (!(buf[i++])) break;
			}
			printf("%s", buf);
			////////////////////////
		}
	}

}

