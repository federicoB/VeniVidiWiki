 	

#include <stdio.h>

int
main (void)
{
  char *bp;
  size_t size;
  FILE *stream;
  char k;

  stream = open_memstream (&bp, &size);
  while ((k=getchar())!=EOF)
  	fprintf (stream, "%c", k);
  fflush (stream);
  printf ("\n%s", bp);
  fclose (stream);

  return 0;
}

