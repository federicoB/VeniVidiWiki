#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

#define N 	10

pid_t **matrix;

struct pt {
	int x,y;
};

struct pt* getpos(pid_t self) {
	int i,j;
	struct pt *toret=malloc(sizeof(struct pt));
	for (i=0; i<N; i++)
		for( j=0; j<N; j++)
			if (matrix[i][j]==self) {
				toret->x = i+1;
				toret->y = j+1;
				return toret;
			}
	toret->x = toret->y = 0;
	return toret;
}


void figlio(struct pt *self, struct pt *fath, int *pipe2) {
	int j, got;
	srand(time(NULL)+self->x*self->y);
	int value = random()%(N*N);
	int pip[2];
	
	
	printf("(%d,%d) generato da (%d,%d) = %d\n", self->x, self->y, fath->x, fath->y, value);
	//sleep(1);
	if (self->x < N) {
		pipe(pip);
		pid_t isfather;
		if (isfather=fork()) waitpid(isfather,NULL,0);
		else {
			struct pt nep;
			nep.x = self->x+1;
			nep.y = self->y;
			figlio(&nep,self,pip);
		}
		read(pip[0],&got,sizeof(int));
		close(pip[0]);
		close(pip[1]);
		value += got;
	} 
	write(pipe2[1],&value,sizeof(int));
	close(pipe2[0]);
	close(pipe2[1]);

	if (self->x==1) sleep(1);
	exit(0);
}

void main(void) {

	int 	i,j,k;
	int	fds[2*N];

	k=0;

	printf("(0,0)\n");
	srand(time(NULL));
	
	/* Inizializzazione della matrice */
	matrix=(pid_t**)malloc(sizeof(pid_t*)*N);
	for (j=0; j<N; j++)
		matrix[j]=(pid_t*)malloc(sizeof(pid_t)*N);
		
	printf("(0,0) MAIN\n");
	for (i=0; i<N; i++) {
		pid_t 	tmp;
		pipe(&fds[i*2]);
		if (tmp=fork()) {
			int valore;
			waitpid(tmp,NULL,0);
			read(fds[i*2],&valore,sizeof(int));
			k+=valore;
		} else {
			struct pt me, pa;
			me.x=1; me.y=i+1;
			pa.x=0; pa.y=0;
			figlio(&me,&pa,&fds[i*2]);
		}
	}
	
	printf("VALORE: %d\n", k);
	return;
	

}
