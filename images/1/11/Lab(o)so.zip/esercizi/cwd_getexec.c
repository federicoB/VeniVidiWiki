#include <stdio.h>
#include <stdlib.h>
#include <dirent.h>
#include <sys/stat.h>
#include <string.h>

/** getstatus():
 *  Restituisce l'informazione di stato di un file 
 */
static inline struct stat *getstatus(char* path, int followlink) { 
	struct stat *status;
	status=(struct stat*)malloc(sizeof(struct stat));
	
	/* Controllo se seguo i link o meno */
	if (followlink)
		stat(path, status);
	else
		lstat(path, status);
		
	return status;
}



static int one (const struct dirent *unused) { return 1; }

/**  changearg0():
 *  restituisce una matrice di stringhe, dove si pone l'ultimo
 *  elemento a null e viene cambiato il primo 
 */

char** changearg0(char* arg0, char* argv[], int argvlen) {
	char **ptr;
	char *nargv;
	int i;
	ptr=(char**)malloc(sizeof(char*)*(argvlen+1));
	nargv=(char*)malloc(sizeof(char)*(strlen(arg0)+2));
	strcpy(nargv+2,arg0);
	nargv[0]='.';
	nargv[1]='/';
	ptr[0]=nargv;
	for (i=1; i<argvlen; i++)
		ptr[i]=argv[i];
	ptr[i]=NULL;
	return ptr;
}

int main(int argc, char* argv[]) {
	struct dirent **eps;
	int n  = scandir("./", &eps, one,alphasort);
	int i;
	
	if (n>=0) {
		int cnt;
		for (cnt=0;cnt<n; cnt++) {
			struct stat *status;
		
			status=getstatus(eps[cnt]->d_name,0);
			
			/* Ottengo tutti i file (escludendo le cartelle) eseguibili */
			if (strcmp(eps[cnt]->d_name,argv[0]))
			if ((!(S_ISDIR(status->st_mode)))&&((status->st_mode & S_IXUSR)||(status->st_mode & S_IXGRP)||(status->st_mode & S_IXOTH))) {
				char **argv_n;
				pid_t son;
				int i;
				if (!(son=fork())) {
					argv_n=changearg0(eps[cnt]->d_name,argv,argc);
					if (strcmp(argv[0],argv_n[0])) 
						execv(argv_n[0], argv_n);
					return 1;
				} else waitpid(son,NULL,0);
			}
			
			free(status);
		}
	
	}
	
	return 0;
}
