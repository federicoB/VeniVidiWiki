#include <stdio.h>
#include <stdlib.h>
#include <dirent.h>
#include <sys/stat.h>
#include <string.h>
#include <sys/types.h>
#include <pwd.h>
#include <grp.h>
#include <time.h>

/** getstatus():
 *  Restituisce l'informazione di stato di un file 
 */
static inline struct stat *getstatus(char* path, int followlink) { 
	struct stat *status;
	status=(struct stat*)malloc(sizeof(struct stat));
	
	/* Controllo se seguo i link o meno */
	if (followlink)
		stat(path, status);
	else
		lstat(path, status);
		
	return status;
}



static int one (const struct dirent *unused) { return 1; }

/**  changearg0():
 *  restituisce una matrice di stringhe, dove si pone l'ultimo
 *  elemento a null e viene cambiato il primo 
 */

char** changearg0(char* arg0, char* argv[], int argvlen) {
	char **ptr;
	char *nargv;
	int i;
	ptr=(char**)malloc(sizeof(char*)*(argvlen+1));
	nargv=(char*)malloc(sizeof(char)*(strlen(arg0)+2));
	strcpy(nargv+2,arg0);
	nargv[0]='.';
	nargv[1]='/';
	ptr[0]=nargv;
	for (i=1; i<argvlen; i++)
		ptr[i]=argv[i];
	ptr[i]=NULL;
	return ptr;
}

#define GETCHAR(cond,charok,charnot) ((cond) ? charok : charnot)

inline char get_char_type(struct stat* status) {
	if (S_ISDIR(status->st_mode)) return 'd';
	if (S_ISCHR(status->st_mode)) return 'c';
	if (S_ISBLK(status->st_mode)) return 'b';
	if (S_ISREG(status->st_mode)) return '-';
	if (S_ISFIFO(status->st_mode)) return 'p';
	if (S_ISLNK(status->st_mode)) return 'l';
	if (S_ISSOCK(status->st_mode)) return 's';
}

inline char third_bit(struct stat* status, int code) {
	int sticky = status->st_mode & S_ISVTX;
	int execut = status->st_mode & code;  // CODE = S_IXUSR | S_IXGRP | S_IXOTH
	if (execut && sticky) return 's';
	else if ((!execut) && sticky) return 'S';
	else if (execut) return 'x';
	else return '-';
}

int get_status_string(struct stat* status, char* buffer, int len) {
	return snprintf(buffer,len,"%c%c%c%c%c%c%c%c%c%c", get_char_type(status),\
								 GETCHAR(status->st_mode & S_IRUSR,'r','-'),\
								 GETCHAR(status->st_mode & S_IWUSR,'w','-'),\
								 third_bit(status,S_IXUSR),\
								 GETCHAR(status->st_mode & S_IRGRP,'r','-'),\
								 GETCHAR(status->st_mode & S_IWGRP,'w','-'),\
								 third_bit(status,S_IXGRP),\
								 GETCHAR(status->st_mode & S_IROTH,'r','-'),\
								 GETCHAR(status->st_mode & S_IWOTH,'w','-'),\
								 third_bit(status,S_IXOTH));
}

int main(int argc, char* argv[]) {
	struct dirent **eps;
	int n  = scandir("./", &eps, one,alphasort); //Scaning della cartella corrente
	int i;
	
	if (n>=0) {
		int cnt;
		for (cnt=0;cnt<n; cnt++) {
			struct stat *status;
			char status_str[11];
			char time_buffe[40];
		
			status=getstatus(eps[cnt]->d_name,0);
			strftime(time_buffe,40, "%Y-%m-%d %H-%M-%S",localtime(&status->st_mtime));
			
			//SCRITTURA DELLA STRINGA DEGLI STATI
			get_status_string(status,status_str,11);
			printf("%s %d\t%s%s\t%d\t%s %s\n",	status_str,\
						status->st_nlink,\
						getpwuid(status->st_uid)->pw_name,\
						getgrgid(status->st_uid)->gr_name,\
						(int)status->st_size,\
						time_buffe,\
						eps[cnt]->d_name);
			
			free(status);
		}
	
	}
	
	return 0;
}
