#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>
#include <mqueue.h>

#define MAX_HEIGHT	3

int privateval[]={0,0};

void  Handler1(int sig)
{
     privateval[0]++;
     signal(sig, SIG_IGN);
     if (sig==SIGUSR1) {
     	printf("~ %d handled ~\n",getpid());
     }
     else {
     	printf("%d: wrong handler\n",getpid());
     	exit(1);
     }
     signal(sig, Handler1);
}

void  Handler2(int sig)
{
     privateval[1]++;
     signal(sig, SIG_IGN);
     if (sig==SIGUSR2) {
     	printf("~ %d handled ~\n",getpid());
     }
     else {
     	printf("%d:wrong handler\n",getpid());
     	exit(1);
     }
     signal(sig, Handler2);
}


void set_handler1(struct sigaction *ssiga) {

	signal(SIGUSR1,Handler1);
	
}

void set_handler2(struct sigaction *ssiga) {
	signal(SIGUSR2,Handler2);
}

static int get_random_max(int max,int seed) {
	srandom(time(0));
	if (max>0)
		return random()%max+1;
	else 
		return random();
}

static void wait_signal1() {
	if (!privateval[0]) pause(); 
	privateval[0]--;
}

static void wait_signal2() {
	if (!privateval[1]) pause(); 
	privateval[1]--;
}

void node_pass(int pos) {
	
	printf("(%d)Got new father at pos %d\n", getpid(),pos);
	if (!pos) {
		// Se sono un nodo foglia
		int val = get_random_max(1000,pos+get_random_max(0,0));
		struct sigaction ssiga;
		set_handler1(&ssiga);
		
		while(1) {
			wait_signal1(); //Attendo un segnale
			printf("(%d)Hai vinto la quantità %d!\n",getpid(),val);
			sleep(3);
			kill(getppid(),SIGUSR2); //Segnale inviato dai figli
		}
	} else {
		// Sono un nodo intermedio
		struct sigaction ssiga1, ssiga2;
		
		pid_t child[2];
		printf("(%d)inside\n", getpid());
		if ((child[1]=fork())==0) { set_handler1(&ssiga1); set_handler2(&ssiga2); node_pass(pos-1); }
		else if (child[1]<0) { printf("ERROR FORKING 1ST\n"); exit(1); }
		
		if ((child[2]=fork())==0) { set_handler1(&ssiga1); set_handler2(&ssiga2); node_pass(pos-1); }
		else if (child[2]<0) { printf("ERROR FORKING 1ST\n"); exit(1); }
		
		
		set_handler1(&ssiga1);
		set_handler2(&ssiga2);
		
		while(1) {
			wait_signal1(); 				  //Attendo il segnale dal padre
			printf("(%d)Got first signal\n",getpid());
			kill(child[ get_random_max(1,0)],SIGUSR1); //Invio il segnale ad uno dei figli
			printf("(%d)Sent signal\n",getpid());
			wait_signal2(); 				  //Attnedo il segnale dal figlio
			printf("(%d)Got second signal\n",getpid());
			kill(getppid(),SIGUSR2);		  //Invio il segnale al padre
		}
	}
}


void main(void) {
	
	struct sigaction ssiga1, ssiga2;
	set_handler1(&ssiga1);
	set_handler2(&ssiga2);
	
	pid_t inizio;
	printf("(%d)init\n",getpid());
	inizio=fork();
	
	if (!inizio) { set_handler1(&ssiga1); set_handler2(&ssiga2); node_pass(MAX_HEIGHT); }
	else if (inizio<0) { printf("ERROR FORKING START\n"); exit(1); }
	
	while (1) {
		kill(inizio,SIGUSR1);
		wait_signal2();
		sleep(3);
	}
}
