#include <stdio.h>
#include <dirent.h>
#include <sys/stat.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/** getstatus():
 *  Restituisce l'informazione di stato di un file 
 */
static inline struct stat *getstatus(char* path, int followlink) { 
	struct stat *status;
	status=(struct stat*)malloc(sizeof(struct stat));
	
	/* Controllo se seguo i link o meno */
	if (followlink)
		stat(path, status);
	else
		lstat(path, status);
		
	return status;
}

int iscorh(char *str) {
	int len = strlen(str);
	//return 1;
	return (((str[len-1]=='c')||(str[len-1]=='h'))&&(str[len-2]=='.'));
}

static int one (const struct dirent *unused) { return 1; }

int main(int argc, char* argv[]) {
	struct dirent **eps1, **eps2;
	int kind[] = {0,0,0,0,0,0,0,0};
	
	//Conto che ci siano tutti gli argomenti necessari
	if (argc<3) { printf("non abbastanza argomenti\n"); exit(1); }
	
	int n1  = scandir(argv[1], &eps1, one,alphasort);
	int i, j;
	
	if (n1>=0) {
		int cnt;
		for (cnt=0;cnt<n1; cnt++) {
			struct stat *status1;
			int n2 = scandir(argv[2], &eps2, one, alphasort);
			
			if (n2>=0) {
			  int cnt2;
			  int hasmatch = 0;
			
			  for (cnt2=0; cnt2<n2; cnt2++) {
			
				
				struct stat *status2;
				if (strcmp(eps1[cnt]->d_name,eps2[cnt2]->d_name)==0)
				   hasmatch++; 
			
			  }
		
			if ((!hasmatch)&&(iscorh(eps1[cnt]->d_name))) printf("%s/%s not in %s\n", argv[1], eps1[cnt]->d_name, argv[2]);
			
			}
			
		}
	
	}
	
	n1  = scandir(argv[2], &eps1, one,alphasort);
	
	if (n1>=0) {
		int cnt;
		for (cnt=0;cnt<n1; cnt++) {
			struct stat *status1;
			int n2 = scandir(argv[1], &eps2, one, alphasort);
			
			if (n2>=0) {
			  int cnt2;
			  int hasmatch = 0;
			
			  for (cnt2=0; cnt2<n2; cnt2++) {
			
				
				struct stat *status2;
				if (strcmp(eps1[cnt]->d_name,eps2[cnt2]->d_name)==0)
				   hasmatch++; 
			
			  }
		
			if ((!hasmatch)&&(iscorh(eps1[cnt]->d_name))) printf("%s/%s not in %s\n", argv[2], eps1[cnt]->d_name, argv[1]);
			
			}
			
		}
	
	}
	
	printf("\n");
	
	return 0;
}
