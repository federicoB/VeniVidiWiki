#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>


#include "../files/stringbuf.h"

#define BUFFSIZE 	(4*1024)

char buffer[BUFFSIZE];
char buftmp[BUFFSIZE];
int fd1, fd2;

static inline void invertwrite(off_t size, off_t pos1, off_t pos2) {
	int i;
	pread (fd1, buffer, size, pos1);
	revcpy(buffer, buftmp, (int)size);
	putchar('(');
	for (i=0; i<(int)size; i++)
		putchar(buftmp[i]); 
	printf(")\n\n");
	pwrite(fd2, buftmp, size, pos2);
}
		
		
int main(int argc, char *argv[]) {

	struct stat buf;
	off_t size, cunt, last, cock, tobuf;
	char *file1, *file2;
	
	
	if (argc<=2) {
		printf("USAGE: %s <filein> <fileout>\n",argv[0]);
		exit(1);
	}
	
	file1 = argv[1];
	file2 = argv[2];
	stat(file1, &buf);
	size = buf.st_size;
	last = size-(size/BUFFSIZE)*BUFFSIZE;
	
	if (!((fd1=open(file1,O_RDONLY))&&(fd2=open(file2,O_WRONLY|O_CREAT|O_TRUNC,0666)))) { perror("ERROR ACCESSING FILES"); exit(1); }
	
	if (last>0) {
		tobuf=last;
		cock=0;
		cunt=(size/BUFFSIZE)*BUFFSIZE;
	} else {
		tobuf=BUFFSIZE;
		last=tobuf;
		cunt=((size-tobuf<0) ? 0 : size-tobuf);
		cock=0;
	}
	printf("size: %d\n", size);
	do {	
		printf("cunt: %d, cock: %d, last: %d\n",cunt,cock,last);
		invertwrite(tobuf,cunt,cock);
		if (cunt<=0) break;
		if (cunt>=BUFFSIZE) {
			cock+=tobuf;
			cunt-=tobuf;
		} else {
			cunt=0;
			cock+=tobuf;
			invertwrite(last,cunt,cock);
			if (cunt<=0) break;
		}
		
	} while (1);
	close(fd1);
	close(fd2);
	
	return 0;
}

