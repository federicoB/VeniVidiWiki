#include "../main_include/default.h"

#define SLEEPCNST 3

#ifndef N
#define N 9
#endif

#ifndef P
#define P 0.5
#endif

int attuali;

static inline float getflt() {
	float j, k;
	j =  rand();
	j /= RAND_MAX;
	return j;
}

void func(int signo) {
	kill(getppid(),signo);
}
void esiste(int signo) {
	attuali++;
}

void figlio(int i, float p) {
	signal(SIGUSR1, func);
	while (1) {
		if (getflt()>=p) { printf("%i dorme...\n", i); sleep(SLEEPCNST); }
		else { printf("%i esce...\n", i); exit(1); }
	}
}

int main(void) {
	int i;
	pid_t terminated[N];
	float p=0.3;
	
	attuali=0;
	srand((unsigned)(time(0))); 
	
	for (i=0; i<N; i++) {
		if (!(terminated[i]=fork())) {
			figlio(i,p);
		} else attuali++;
	}
	
	signal(SIGUSR1, esiste);
	
	while (attuali) {
		for (i=0; i<N; i++) {
			if (terminated[i]) {
				printf("Analizzando %i\n", i);
				int save=attuali;
				
				kill(terminated[i],SIGUSR1);
				sleep(SLEEPCNST);
				attuali--;
				//printf("attuali: %i save: %i", attuali, save);
				if (!(save==attuali)) {
					printf("addio\n"); //vuol dire che non è arrivato il gestore => non c'è il processo
					terminated[i]=0;
				} else printf("ESISTE\n");
			}
		}
	}
	
	return 0;
	
}
