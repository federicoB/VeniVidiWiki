/** Questo programma effettua una chiamata concatenata dei programmi,
    lanciando al programma corrente l'output del precedente, e fornendo
    il suo output al successivo come input (pipe) */
#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>

#ifndef MAX
#define MAX 3
#endif

int main(int argc, char **argv)
{
  int status;
  int i;

  int pipes[2];
  pid_t pid[2];
  
  if (argc<=2) return 1;
  
  for (i=0; i<2; i++) {
  	int j=i*2;
  	pipe(pipes+j);
  }
  
  for (i=0; i<2; i++) {
  	pid[i]=fork();
  	if (pid[i] == 0) {
  		if (i==0) {
  			dup2(pipes[1], 1);
      			execvp(argv[2],argv+2);
  		} else if (i==1) {
  			char k, buf[1024];
  			int i=0;
  			dup2(pipes[0], 0);

  			while ((k=getchar())!=10) {
  				if ((k!=' ')&&(k!='\n'))
  					buf[i++]=k;
  				else {
  					buf[i]='\0';
  					if (strcmp(buf,argv[1])) {
  						printf("%s", buf);
  						putchar(k);
  					} 
  					i=0;
  				}
  			}
  			buf[i]='\0';
  			if (strcmp(buf,argv[1])) {
  				printf("%s", buf);
  				putchar(k);
  			} 
  			i=0;
	      		exit(0);
  		} 
  	}
  }

  for (i = 0; i < 2; i++)
    waitpid(pid[i],NULL,0);

}
