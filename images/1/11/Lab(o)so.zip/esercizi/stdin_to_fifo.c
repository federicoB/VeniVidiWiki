/** file: stdin_to_fifo.c
  * author: Giacomo Bergami
  * brief: Questo programma crea eventualmente nel percorso del primo argomento
  *        un file fifo, e scrive all'interno del buffer il contenuto dello stdin 
  */
#include <stdio.h>
#include <errno.h>
#include <ctype.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

int main(int argc, char *argv[])
{
    int fd;

    /* Check if an argument was specified. */
    

    if (argc != 2) {
        printf("Usage : %s <string to be sent to the server>n", argv[0]);
        exit (1);
    }
    
    //Creates a fifo file 
    mkfifo(argv[1], 0666);

    //Opens the pipe for writing
    fd = open(argv[1], O_WRONLY);

    //Writes the pipe from stdin
    while (1) {
       char buffer[1024];
       scanf("%s",buffer);
       write(fd, buffer, strlen(buffer));
       
       /* writes the CR */
       buffer[0]='\n';
       write(fd, buffer, 1);
    }
}

