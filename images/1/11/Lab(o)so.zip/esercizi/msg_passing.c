/* si decide una chiave, e si dice che si vuole creare un canale di comunicazione
   con quella chiave: non essendoci ... la chiave...
   
   Una volta creato il canale, le flag sono quelle sono simili a quelle
   della open, e quindi .... 
   
   Ricopia l'esercizio precedente:
*/
#define 	ML 40	/*lunghezza del messaggio*/
#define 	MT 44 	/*tipo del dato*/
#define		NT 10000 /*numero dei tentativi*/

       struct ourmsgbuf {
            long mtype;
            char mtext[ML];
       };

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/msg.h>


struct ourmsgbuf buf={MT, "testing"};
 
int main(int argc, char* argv[]) {
  int i;
#ifdef SHITTY
  int p2c=msgget(IPC_PRIVATE,IPC_CREAT|0400);
  int c2p=msgget(IPC_PRIVATE,IPC_CREAT|0400);
#else
  int p2c=msgget(IPC_PRIVATE,IPC_CREAT);
  int c2p=msgget(IPC_PRIVATE,IPC_CREAT);
#endif
  switch (fork()) {
     case -1: fprintf(stderr, "forkerror\n");
              exit(1);
     case 0:  close(p2c);
              close(c2p);
              
              for (i=0; i<NT; i++) {
                 int n=msgrcv(p2c,&buf, ML,MT, 0);
                 printf("%d %d %s\n",i,ML,buf.mtext);
                 msgsnd(c2p,&buf,n,0);
              }
              break;
     default:
              close(p2c);
              close(c2p);
              for (i=0; i<NT; i++) {
                 msgsnd(p2c,&buf,ML,0);
                 msgrcv(c2p,&buf,ML,MT,0);
              }
              break;
  
  }

}
