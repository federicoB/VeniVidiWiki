#include <stdio.h>
#include <dirent.h>
#include <sys/stat.h>

/** getstatus():
 *  Restituisce l'informazione di stato di un file 
 */
static inline struct stat *getstatus(char* path, int followlink) { 
	struct stat *status;
	status=(struct stat*)malloc(sizeof(struct stat));
	
	/* Controllo se seguo i link o meno */
	if (followlink)
		stat(path, status);
	else
		lstat(path, status);
		
	return status;
}



static int one (const struct dirent *unused) { return 1; }

int main(void) {
	struct dirent **eps;
	int kind[] = {0,0,0,0,0,0,0,0};
	int n  = scandir("./", &eps, one,alphasort);
	int i;
	
	if (n>=0) {
		int cnt;
		for (cnt=0;cnt<n; cnt++) {
			struct stat *status;
		
			printf("%s",eps[cnt]->d_name);
			status=getstatus(eps[cnt]->d_name,0);
			
			if (S_ISDIR(status->st_mode))		{ printf(" DIR\n"); kind[0]++; }
			else if (S_ISCHR(status->st_mode)) 	{ printf(" CHAR-dev\n"); kind[1]++; }
			else if (S_ISBLK(status->st_mode)) 	{ printf(" BLOCK-file\n"); kind[2]++; }
			else if (S_ISREG(status->st_mode)) 	{ printf(" FILE\n"); kind[3]++; }
			else if (S_ISFIFO(status->st_mode)) 	{ printf(" FIFO\n"); kind[4]++; }
			else if (S_ISLNK(status->st_mode)) 	{ printf(" LINK\n"); kind[5]++; }
			else if (S_ISSOCK(status->st_mode)) 	{ printf(" SOCKET\n"); kind[6]++; }
			else 					{ printf(" (UNKWNOWN)\n"); kind[7]++; }
			
			free(status);
		}
	
	}
	
	printf("\n");
	
	for (i=0; i<8; i++)
		if (kind[i]) 
			switch (i) {
				case 0: printf("Directories: %d\n", kind[i]); break;
				case 1: printf("Char-Device: %d\n", kind[i]); break;
				case 2: printf("Block-Files: %d\n", kind[i]); break;
				case 3: printf("Stand-Files: %d\n", kind[i]); break;
				case 4: printf("Fifos-Files: %d\n", kind[i]); break;
				case 5: printf("Links-Files: %d\n", kind[i]); break;
				case 6: printf("Socket-File: %d\n", kind[i]); break;
				default: printf("UnknownKind: %d\n", kind[i]); break;
			}
	
	return 0;
}
