#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>


#define VALLETTE	48
#define GIURIE		6

//#define CICLI 		(4+8+12+16+20+24)

typedef struct {
	int pipe[2];
} apipe;
typedef struct {
	int valletta;
	int voto;
} concorso;

apipe communicate_to[GIURIE];

pid_t 		vallette[VALLETTE];
int 		save [GIURIE][VALLETTE];
concorso	analyze[VALLETTE];
concorso	*result;

void  HandlerQUIT(int sig)
{
     printf("CIAO, non l'ho data via abbastanza\n");
}

void  Handler2(int sig)
{
     printf("Grazie a tutti: porterò la pace nel mondo\n");
}

void giurato(int i) {
	int j, ciclo;
	srand(time(NULL)+i);
	ciclo = VALLETTE;
	
	while (ciclo>0) {
		for (j=0; j<ciclo; j++) {
			int prova = random()%10+1;
			//printf("%d : scrivo %d\n", i, prova);
			write(communicate_to[i].pipe[1],(&prova),sizeof(int));
		}
		ciclo-=4;
	}
}

int intcmp(const void* x, const void* y) {
	concorso *a, *b;
	a=(concorso*)x;
	b=(concorso*)y;
	if (a->voto==b->voto) return 0;
	else if (a->voto > b->voto) return -1;
	else return 1;
}

int ciclotomax(int max) {
	int i,j, tmp;
	
	for (i=0; i<VALLETTE; i++)
		result[i].voto=0;
	
	for (j=0; j<max; j++) {
		for (i=0; i<GIURIE; i++) {
			int val;
			read(communicate_to[i].pipe[0],(&val),sizeof(int));
			result[j].voto+=val;
		}
	}
	qsort(result, max, sizeof(concorso), intcmp);
	
	if (max==4)
		for (i=0; i<3; i++) {
			printf("ELIMINATA (%d): numero %d voti %d\n", max,result[i].valletta, result[i].voto);
			kill(vallette[result[i].valletta],SIGUSR1);
		}
	else
		for (i=0; i<4; i++) {
			printf("ELIMINATA (%d): numero %d voti %d\n", max,result[i].valletta, result[i].voto);
			kill(vallette[result[i].valletta],SIGUSR1);
		}
	
	tmp = result[0].valletta;
	
	if (max<=4) printf("vince la %d!!!\n", tmp);
	
	
	result = &result[3];
	return tmp;
}

void main(void) {
	
	
	pid_t elettori[GIURIE];
	signal(SIGUSR1, HandlerQUIT);
	signal(SIGUSR2, Handler2);
	srand(time(NULL));
	
	pid_t tmp;
	int i, vals, bitch;
	
	result=analyze;
	for (i=0; i<VALLETTE; i++) {
		result[i].voto=0;
		result[i].valletta=i;
	}
	
	for (i=0; i<GIURIE; i++)
		pipe(communicate_to[i].pipe);
	
	for (i=0; i<VALLETTE; i++)
		if ((tmp=fork())>0)  vallette[i]=tmp;  
		else if (tmp<0) { printf("ERROR"); exit(1); }
		else {  pause(); return; }
	
	for (i=0; i<GIURIE; i++)
		if ((tmp=fork())>0) { elettori[i]=tmp; waitpid(tmp,NULL,0); }
		else if (tmp<0) { printf("ERROR"); exit(1); }
		else { giurato(i);  return; }
	
	
	printf("smarcato\n");
	
	for (vals=VALLETTE; vals>=4; vals-=4)
		bitch=ciclotomax(vals);
	
	kill(vallette[bitch],SIGUSR2);
	exit(0);
}
