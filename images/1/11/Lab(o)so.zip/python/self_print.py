#!/usr/bin/python
#
# il programma stampa semplicemente se stesso.
import sys

f=open(sys.argv[0],'r')
s = ''
for l in f.readlines():
	s = s + l
print s,
