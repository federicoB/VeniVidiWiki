import fs, sys, os

if (len(sys.argv)>2):
	T1 = fs.fstree(sys.argv[1])
	T2 = fs.fstree(sys.argv[2])
	ls1 = T1.getAllFiles()
	ls2 = T2.getAllFiles()
	for x in ls1:
		for y in ls2:
			if x.split('/')[-1]==y.split('/')[-1]:
				print 'deleting', x 
				os.unlink(x)
				print 'deleting', y
				os.unlink(y)
	T1 = fs.fstree(sys.argv[1])
	T2 = fs.fstree(sys.argv[2])
	for j in T1.getCommonContent(T2):
				print 'deleting', j
				os.unlink(j)
