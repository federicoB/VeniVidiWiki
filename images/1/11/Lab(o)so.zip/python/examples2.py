import os, sys, get_prog_exec, fs



## Inverte le stringe di un file e le mette in output
def ex1():
	if (len(sys.argv)>1):
		file_ = sys.argv[1]
		line= ""
		linec = 1
		for x in open(file_, "r"):
			if linec==1:
				line=x
				linec+=1
			else:
				print x,
				print line,
				linec-=1
		if linec==2:
			print line,

def getCP_SUM(x):
	j = get_prog_exec.getexecout(['md5sum',x])
	return (x,j.split(' ')[0])

def fst(j):
	a, b=j
	return a

# Restituisce la lista delle posizioni di dov'e' situato un elemento in una lista
def getnlis(x,lis):
     i = 0
     l = []
     for k in lis:
             if lis[i]==x:
                     l.extend([i])
             i+=1
     return l


## Elenca tutti i file uguali per md5sum
def ex2():
	#Restituisce per ogni cartella (lista_nome, lista_sum)
	def get_sum_from_folder(p):
		T = fs.fstree(p)
		a = []
		b = []
		for w in T.getAllFiles():
			x, y =getCP_SUM(w)
			a.extend([x])
			b.extend([y])
		return (a,b)
	
	#Ottengo per ogni cartella una lista delle coppie (lista_nome, lista_sum)
	folders = map(lambda x: get_sum_from_folder(x),sys.argv[1:])
	
	#Ottengo l'insieme di tutti i sum
	l = []
	for x in map(lambda x: x[1], folders):
		l.extend(x)
		
	#Per ogni sum ottengo l'insieme dei file corrispondenti
	for x in set(l):
		f = []
		for k in folders:
			for w in getnlis(x,k[1]):
				print x, k[0][w]


def ex3():
	if (len(sys.argv)>=4):
		fis = sys.argv[1]
		if (sys.argv[2].isdigit() and sys.argv[3].isdigit()):
			uno = int(sys.argv[2])
			due = int(sys.argv[3])
			
			minimo = [0,0]
			massimo = [0,0]
			totale = [0,0]
			total  = 0
			matrix = map(lambda x: x.replace('\n','').split(' '),open(fis,'r'))
			minimo[0] = int(matrix[0][uno])
			minimo[1] = int(matrix[0][due])
			massimo[0] = int(matrix[0][uno])
			massimo[1] = int(matrix[0][due])
			
			for row in matrix:
				a = int(row[uno])
				b = int(row[due])
				minimo[0]=min(minimo[0],a)
				minimo[1]=min(minimo[1],b)
				massimo[0]=max(massimo[0],a)
				massimo[1]=max(massimo[1],b)
				totale[0]+=a
				totale[1]+=b
				total+=1
			
			if total:
				print 'min:', minimo[0], 'max:', massimo[0], 'average:', str(totale[0]/total) 
				print 'min:', minimo[1], 'max:', massimo[1], 'average:', str(totale[1]/total) 
				

def bylength(x,y):
	return len(x)-len(y)
	
def ex4():
	
	T = fs.fstree(os.getcwd())
	if (len(sys.argv)>1):
		T = fs.fstree(sys.argv[1])
	for x in sorted(T.getAllFiles(), bylength):
		print x

ex4()
	
