import sys

def get_ls_range(stri):
	ls = []
	for x in range(0,len(stri)-1):
		if (x+2<=len(stri)-1):
			ls+=[stri[x:x+3]]
	return ls

def getmap(ls,stri):
	count = 0
	for x in ls:
		if (stri in x): count+=1
	return count

if (len(sys.argv)>3):
	stringa_ls = get_ls_range(sys.argv[1])
	for x in stringa_ls:
		print x,'\t',getmap(sys.argv[2:],x)
		
