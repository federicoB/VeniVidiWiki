import random
ls = []
for x in file('test','r'):
	ls+=[x.split(' ')[0]]
print random.choice(ls)
