## file: value.py
#  brief: Ottiene le informazioni da file e stampa i valori

import os, sys, fs


## ------------------ Esegue un programma (nell'esempio file) e restituisce la stringa
def getfile_(who):
	file_ = 'out.txt'
	j = os.fork()
	if j:
		os.waitpid(j,0)
		l = ''
		for x in open(file_,'r'):
			return x[len(who)+2:-1]
	
	else:

		fd = os.open(file_, os.O_WRONLY|os.O_CREAT)
		os.dup2(fd,1)

		os.execvp('file', ['file', who])


def getexecout(ls,file_='out.txt'):
	j = os.fork()
	if j:
		os.waitpid(j,0)
		l = ''
		for x in open(file_,'r'):
			l+=x+'\n'
		os.unlink(file_)
		return l.replace('\n','')
	
	else:

		fd = os.open(file_, os.O_WRONLY|os.O_CREAT)
		os.dup2(fd,1)

		os.execvp(ls[0], ls)
		

def getfile(who):
	toret = getfile_(who)
	os.unlink('out.txt')
	return toret

# ------------------------------- ESEMPIO: analogo a killall
def miaex():
	if (len(sys.argv)>1):
		ls = filter(lambda j:j.isdigit(), getexecout(['pidof', sys.argv[1]]).split(' '))
		#while (len(ls)>0):
		for k in ls:
				if os.fork():
					os.execvp('kill', ['kill',  k])
				else:
					print 'killing ', k
		print len(ls)
		#ls =getexecout(['pidof', sys.argv[1]]).split(' ')
		print ls
		
