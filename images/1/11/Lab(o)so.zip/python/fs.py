#!/usr/bin/python
# -*- coding: utf-8 -*-

import os, sys

class FSError: pass

def itera(x,y):
	return range(y+1)[x:]

def rbeslash(str1):
	if len(str1)==0:
		return str1
	if str1[0]=='/':
		str1=str1[1:]
	if len(str1)>0 and str1[-1]=='/':
		str1=str1[:-1]
	return str1

## \brief Verifica se un x è membro di L, restituendo la posizione
#  \param L lista
#  \param x elemento
def iscmember(L,x):
	count=0
        for y in L:
                if (x==y):
                        return count
                else:
                	count+=1
        return -1

## \brief Verifica se un x è membro di L
#  \param L lista
#  \param x elemento
def ismember(L,x):
	if iscmember(L,x)<0:
		return False
	else:
		return True

## \brief Definizione di una classe di tipo albero
class Tree(object):
	def __init__(self,name='rùt'):
		self.value=name
		self.children=[]
	
	def getValue(self):
		return self.value
		
	def setValue(self,name):
		self.value=name
		return name
	
	def addChild(self,c):
		self.children.extend([c])
		return c
	
	def addChildByValue(self,val):
		k=Tree(val)
		self.children.exdent([k])
		return k
	
	def getChildren(self):
		return self.children
		
	def getChildrenNames(self):
		return map(lambda x:x.getValue(),self.children)
	
	def getChild(self,i):
		return self.children[i]
	
	def getChildVal(self,i):
		return self.getChild(i).getValue()
	
	def isNode(self):
		return len(self.children)==0
	
	def getSonIndex(self,x):
		return iscmember(map(lambda x:x.getValue(),self.children),x)
	
	## Naviga l'albero, partendo dal primo figlio indicato come primo elemento
	#della lista: se non è presente o restituisco un errore (update=False)
	#o effettuo l'inserimento nella lista.
	#
	# \param ls 	Lista di elementi lungo il percorso
	# \param update	Valore booleano, per effettuare l'aggiornamento nell'albero oppure no
	def SurfTree(self,ls,update):
		if (ls==[]):
			return self
		else:
			k=self.getSonIndex(ls[0])
			if k<0:
				if not update:
					raise (ls[0], 'not found')
				else:
					son=Tree(ls[0])
					self.addChild(son)
					self.children[-1].SurfTree(ls[1:],update)
			else:
				return self.children[k].SurfTree(ls[1:],update)
	
	## Effettua la navigazione dell'albero, con eventuale aggiornamento,
	#partendo dalla stringa indicata in path: si parte comunque sempre 
	#dalla radice dell'albero, e considerando sempre per prima i figli
	#
	# \param path	Percorso da analizzare
	# \param update	Valore booleano, per effettuare l'aggiornamento nell'albero oppure no
	def SurfTreePath(self,path,update):
		path=rbeslash(path)
		self.SurfTree(path.split('/'),update)
	
	## Funzione utilizzata per stampare (come debugging) gli elementi dell'albero.
	# essa è equivalentemente invocabile facendo conversione a stringa o facendo
	# stampa sul corrente tipo di dato.
	# \param i 	Posizione iniziale: inizializzare con 0
	def Stampa(self,i):
		st=''
		st+=self.value+'['+str(len(self.children))+']\n'
		for s in self.children:
				for x in itera(1,i+2):
					st+=' '
				st+='|-'
				st+=s.Stampa(i+3)
		return st
			

	def __str__(self):
		return self.Stampa(0)



## fstree
#  Gestione del fs
class fstree(Tree):
	def __init__(x,name):
		ls=[]
		for root, dirs, files in os.walk(name):
			ls+=(map(lambda x:root+'/'+x,files)+map(lambda x:root+'/'+x,dirs))
		super(fstree,x).__init__(name)
		for j in ls:
			x.SurfTreePath(j[len(name):],True)
	
	# ---------- CONFRONTO TRA DUE CARTELLE DI FS	
	#Restituisce gli elementi comuni a T1 ed a T2 in una coppia
	def getCommon(x,y):
		def common(T1,T2):
			import sys
			from copy import copy
			if T1.isNode() or T2.isNode():
				return ([],[])
			else:
		
				subT1=filter(lambda x:ismember(T2.getChildrenNames(),x),T1.getChildrenNames())
				subT2=filter(lambda x:ismember(T1.getChildrenNames(),x),T2.getChildrenNames())
				ret1=copy(subT1)
				ret2=copy(subT2)
				for x in subT1:
					lsub1,lsub2=common(T1.getChildren()[T1.getSonIndex(x)],T2.getChildren()[T2.getSonIndex(x)])
					ret1+=lsub1
					ret2+=lsub2
				ret1=map(lambda x:T1.getValue()+'/'+x,ret1)
				ret2=map(lambda x:T2.getValue()+'/'+x,ret2)
				return (ret1,ret2)
	
		return common(x,y)
	
	#Restituisce gli elementi non comuni a T1 e T2 in una 
	def getDiffer(x,y):
	
		def differ(T1,T2):
			import sys
			from copy import copy
			if T1.isNode() or T2.isNode():
				return ([],[])
			else:
		
				subT1=filter(lambda x:ismember(T2.getChildrenNames(),x),T1.getChildrenNames())
				subT2=filter(lambda x:ismember(T1.getChildrenNames(),x),T2.getChildrenNames())
				ret1=filter(lambda x:not ismember(T2.getChildrenNames(),x),T1.getChildrenNames())
				ret2=filter(lambda x:not ismember(T1.getChildrenNames(),x),T2.getChildrenNames())
				for x in subT1:
					lsub1,lsub2=differ(T1.getChildren()[T1.getSonIndex(x)],T2.getChildren()[T2.getSonIndex(x)])
					ret1+=lsub1
					ret2+=lsub2
				ret1=map(lambda x:T1.getValue()+'/'+x,ret1)
				ret2=map(lambda x:T2.getValue()+'/'+x,ret2)
				return (ret1,ret2)
		
		return differ(x,y)
	
	def getDifferDirs(x,y):
		import os
		a,b = x.getDiffer(y)
		return filter(lambda k:os.path.isdir(k),(a+b))
		
	def getCommonDirs2(x,y):
		import os
		a,b = x.getCommon(y)
		return (filter(lambda k:os.path.isdir(k),a),filter(lambda k:os.path.isdir(k),b))
	
	def getCommonDirs(x,y):
		import os
		a,b = x.getCommon(y)
		return filter(lambda k:os.path.isdir(k),a)
	
	def getDifferFiles(x,y):
		import os
		a,b = x.getDiffer(y)
		return filter(lambda k:not os.path.isdir(k),(a+b))
	
	def getCommonFiles2(x,y):
		import os
		a,b = x.getCommon(y)
		return (filter(lambda k:not os.path.isdir(k),a),filter(lambda k:not os.path.isdir(k),b))
	
	def getCommonFiles(x,y):
		import os
		a,b = x.getCommon(y)
		return filter(lambda k:not os.path.isdir(k),a)
		
	# ----------- OTTENIMENTO TUTTI I FILES E CARTELLE CORRENTI
	def getFiles(x):
	        import os
	        return filter(lambda l:not os.path.isdir(l),x.getChildrenNames())
	        
	def getAllFiles(x):
		return x.getCommonFiles(x)
	
	def getDirs(x):
		import os
		return filter(lambda l:os.path.isdir(l),x.getChildrenNames())
	
	def getAllFolders(x):
		return x.getCommonDirs(x)
	
	def getRootOnlyElems(x):
		return x.getChildrenNames()
	
	def getRootOnlyDir(x):
		import os
		return filter(lambda k: os.path.isdir(k), x.getRootOnlyElems())
	
	def getRootOnlyFiles(x):
		import os
		return list(set(x.getRootOnlyElems())-set(x.getRootOnlyDir()))
		
	
	# --------------------------- Informazioni generiche
	
	def getSize(x):
		l = 0
		for w in x.getAllFiles():
			l += os.path.getsize(w)
		return l
	
	def getStat(x):
		import os
		return os.stat(x.value)
		
	
	# ------------------------- Ottiene in due folder
	# i files con lo stesso contenuto
	def getCommonContent(x,T):
		from filecmp import cmp
		ls1 = x.getAllFiles()
		ls2 = T.getAllFiles()
		ls3 = []
		for x in ls1:
			for y in ls2:
				if cmp(x,y):
					ls3+=[x,y]
		return list(set(ls3))
		

	


##ANALISI DEGLI ELEMENTI COMUNI
def smista(stri,x,y):
	if stri.startswith(x):
		return stri[len(x):]
	elif stri.startswith(y):
		return stri[len(y):]
	else:
		return stri

def rev_sorttime(x,y):
	return int(os.stat(x).st_ctime-os.stat(y).st_ctime)

def example():
	if (len(sys.argv)>1):
		descr='.'
		if (len(sys.argv)>2):
			descr=sys.argv[2]
		if (sys.argv[1].isdigit()):
			j= sorted(fstree(descr).getRootOnlyFiles(), cmp=rev_sorttime)
			while (len(j)>0) and (os.stat(descr).st_blocks > int(sys.argv[1])):
				u = j.pop(); os.unlink(u); print 'Deleting ', u
		
		 
