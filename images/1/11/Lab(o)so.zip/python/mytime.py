from time import *
from datetime import *

oggi = date.today()
ieri = oggi +timedelta(days=-1)
doma = oggi +timedelta(days=1)
oggi_fl = mktime(oggi.timetuple())
ieri_fl = mktime(ieri.timetuple())
doma_fl = mktime(doma.timetuple())

def inyesterday(x):
	return (ieri_fl<=x) and (x<oggi_fl)

def intoday(x):
	return (oggi_fl<=x) and (x<doma_fl)


