import fs, sys, os

if (len(sys.argv)>2):
	T1 = fs.fstree(sys.argv[1])
	for x in T1.getAllFiles():
		os.link(x,sys.argv[2]+'/'+x.split('/')[-1])
	
