from get_prog_exec 	import *
from fs    		import *
from stat 		import *
from mytime		import *

## Nel terzo percorso, effettua il link dei file uguali tra le due cartelle, mettendo
#  eventualmente quello più recente
def ex0():
	if (sys.argv[0]>=4):
		x = sys.argv[1]
		y = sys.argv[2]
		z = sys.argv[3]
		a=fstree(x)
		b=fstree(y)
		tomake = map(lambda l:z+smista(l,x,y),a.getDifferDirs(b)+a.getCommonDirs(b))
		if not os.path.exists(z):
			os.mkdir(z)
		for w in tomake:
			if not os.path.exists(w):
				os.mkdir(w)
		for w in a.getDifferFiles(b):
			if not os.path.exists(z+smista(w,x,y)):
				os.link(w,z+smista(w,x,y))
		t,u = a.getCommonFiles2(b)
		for q in range(0,len(t)):
			if os.stat(t[q]).st_mtime < os.stat(u[q]).st_mtime:
				os.link(u[q],z+smista(u[q],x,y))
			else:
				os.link(t[q],z+smista(t[q],x,y))

## Mette in output il tipo del file secondo il comando bash "file", e poi il file
def ex1():
	for x in fs.fstree(os.getcwd()).getFiles():
		print getfile(x)+':'
		print '  '+x

## Mette l'elenco di tutti i files presenti nel sottoalbero corrente, mettendo a lato
#  la cartella dov'è contenuto
def ex2():
	arg ='.'
	if len(sys.argv)>1:
		arg = sys.argv[1]
	ls = map(lambda l: l[len(arg):], sorted(fs.fstree(arg).getAllFiles()))
	for x in ls:
		print x[x.rindex('/')+1:]+'\t'+x[:x.rindex('/')+1]

## Effettuo una stampa dei file ordinati per estensione e poi per nome nell'estensione
def ex3():
	def getext(k):
		return k.split('.')[-1]
		
	ls = fs.fstree(os.getcwd()).getFiles()
	#ottengo tutte le estensioni, ordinate
	ext = sorted(list(set(map (lambda x: getext(x),ls))))
	
	for x in ext:
		for w in sorted(filter(lambda w:getext(w)==x,ls)):
			print w
	
## Esegue uno script   out: file1 ... file2 | exe cmd1 ... cmdn
## se file1 o file2 sono più recenti di out, esegue il comando
def ex4():
	if (len(sys.argv)>1):
		file_ = sys.argv[1]
		if os.path.exists(file_):
			stringa=''
			for x in open(file_,'r'):
				stringa=x
				continue
			ls = stringa.split(' ')
			while ls.count(''):
				ls.remove('')
			if ls[0][-1]==':':
				ls[0]=ls[0][:-1]
				tocheck = ls[:ls.index('|')]
				
				main_time=0
				if os.path.exists(tocheck[0]):
					main_time=os.path.getmtime(tocheck[0])
				for x in tocheck[1:]:
					if os.path.exists(x):
						if os.path.getmtime(x)>main_time:
							toexec = ls[ls.index('|')+1:]
							os.execvp(toexec[0], toexec)#(
							return
			else:
				print "File "+file_+" not well formed"
		else:
			print "File "+file_+" doesn't exists"


##Ottiene il numero di directory, file normali, link o file speciali
def ex5():
	import os, sys
	
	
	fil=links=spec=0
	print "Directory:", len(fs.fstree(os.getcwd()).getDirs())
	ls = fs.fstree(os.getcwd()).getFiles()
	for x in ls:
		w = os.stat(x).st_mode
		if S_ISREG(w): fil+=1
		elif S_ISLNK(w): links+=1
		else: spec+=1
	print "Regular File:", fil
	print "Link File:", links
	print "Special Files:", spec

##Controlla se nei in g sono presenti elementi non in p
def ex6():
	g = h = []
	for x in open('groups','r'):
		g+=[x.split(':')[0]]
	for x in open('passwds','r'):
		h+=[x.split(':')[0]]
	set_g = set(g)
	set_h = set(h)
	print len(set_g-set_h)

##Cambia il tempo del file, se questo è stato fatto oggi, mettendolo a ieri.
def ex7():
	for x in fs.fstree(os.getcwd()).getFiles():
		timer = os.path.getctime(x)
		if intoday(timer):
			os.utime(x,(ieri_fl+(timer-oggi_fl),ieri_fl+(timer-oggi_fl)))


	
