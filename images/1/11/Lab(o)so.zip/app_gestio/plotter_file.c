#include "../files/file_edit.h"
#include "args.h"
#include "../forks/forka.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

//Funzione che restituisce il file GNUOCTAVE
char* GNUOCTAVE_2D() {
	EFile* GNU;
	char*  allocco;
	GNU=Eopen("gnuoctave2D", "r");
	allocco=fgetalloc(GNU);
	Eclose(GNU);
	return allocco;
}

//Funzione che restituisce il file GNUPLOT
char* GNUPLOT_2D() {
	EFile* GNU;
	char*  allocco;
	GNU=Eopen("gnuplot2D", "r");
	allocco=fgetalloc(GNU);
	Eclose(GNU);
	return allocco;
}


//Funzione che restituisce il contenuto di un file
char* GetContent(char* path) {
	EFile* GNU;
	char*  allocco;
	GNU=Eopen(path, "r");
	allocco=fgetalloc(GNU);
	Eclose(GNU);
	return allocco;
}

//Funzione che scrive in output il file .m data la funzione2D desiderata
int IstantiateGNU2D(char* output, int low, int hight, int sample, char* function, char* format1, char* format2) {

	char *template,*result;
	char _format[] = "%14.6f";
	char *oFILE;
	int len = 0;
	EFile *OUT;
	

	if (!output) return len;
	if (!function) return len;
	if (!format1) format1=_format;
	if (!format2) format2=_format;
	
	template=GNUOCTAVE_2D();
	asprintf(&oFILE,"%s.m",output);
	len = printf(template,output,low,hight,sample,function,format1,format2);
	result = (char*)malloc(sizeof(char)*len);
	
	if (snprintf(result,len,template,output,low,hight,sample,function,format1,format2)) {
		OUT=Eopen(oFILE,"w");
		EAppendStr(OUT,result);
	} 
	free(result);
	free(template);
	free(oFILE);
	
	template=GNUPLOT_2D();
	asprintf(&oFILE,"%s.plt",output);
	len = printf(template,output,output);
	result = (char*)malloc(sizeof(char)*len);
	
	if (snprintf(result,len,template,output,output)) {
		OUT=Eopen(oFILE,"w");
		EAppendStr(OUT,result);
	} 
	free(result);
	free(template);
	free(oFILE);
	
	return len;
	
} 

void alert(char* msg) {
	printf("%s\n", msg);
	exit(1);
}

//TEST:    ./plotter -F2D="r=2*x" 10 20
int  main(argc, argv)
 int argc;
 char **argv;
{
	char *others;
	
	char *Function2D, *file2D, *outv, *oFILE;
	char *param1, *param2;
	int limit2D=0;
	int count_found=0;
	
	Function2D=file2D=outv=param1=param2=(char*)NULL;
	
	int set_low, set_hight, set_sample;
	set_sample=1000;
	asprintf(&outv,"out");
	
	
	
	
	struct option lo[] = {
		{"F2D",	required_argument,0,'F'},//FUNZIONE
		{"f2D",	required_argument,0,'f'},//file
		{"out",	required_argument,0,'o'},
		{0,0,0,0}
	
	};
	
	/* Inizio a riconoscere i parametri */
	START_CYCLE(argc,argv,lo)
		case 'F':
			if (!limit2D) {
				Function2D=HAS_ARG;
				limit2D++;
			} else alert("Found exceeding -F Argument");
			printf("ok\n");
			break;
		case 'f':
			if (!limit2D) {
				Function2D=GetContent(HAS_ARG);
				limit2D++;
			} else alert("Found exceeding -f Argument");
			printf("ok\n");
			break;
		case 'o':
			free(outv);
			outv=HAS_ARG;
			break;
		default:
			exit(1);
	
	END_CYCLE;
	
	printf("%s\n", outv);
	
	/* Riconosco gli argomenti per il plotting 2D */
	if (limit2D) {
		if (REMAINING_ARGS(argc)<2) alert("Missing 2 numbers");
		printf("ok\n");
		
		while (others=GET_NEXT_OPTIND(argc,argv)) {
			switch(++count_found) {
				case 1:
					if (others[0]=='/') others[0]='-';
					set_low=atoi(others);
					break;
				case 2:
					if (others[0]=='/') others[0]='-';
					set_hight=atoi(others);
					break;
				case 3:
					set_sample=atoi(others);
					break;
				case 4:
					param1=param2=others;
					break;
				case 5:
					param2=others;
					break;
				default:
					break;
			}
		}
		
		
		/* Inizio a generare il file */
		
		
		IstantiateGNU2D(outv,set_low, set_hight, set_sample,Function2D,param1,param2);
		return 0;
	}
	
	return 1;
}
