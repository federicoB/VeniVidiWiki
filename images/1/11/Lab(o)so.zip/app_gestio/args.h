#ifndef _ARGS_
#define _ARGS_

#include <stdio.h>
#include <stdlib.h>
#include <getopt.h>

#define IS_EOOPT(ptr) (((((ptr)->name)||((ptr)->has_arg)||((ptr)->flag)||((ptr)->val))==0) ? 1 : 0)

/** mkshortopt():
 *  Given the struct option data structure, it returns the correspondent
 *  shortopts char, by allocation of a string 
 */  
char* mkshortopt(struct option* longopt) {
	int 		cnt_chars=0;
	struct option 	*tmp;
	char 		*toret, *ctmp;
	
	
	//Counts the chars to allocate
	tmp=longopt;
	while (!IS_EOOPT(tmp)) {
		if (!(tmp->flag)) {
			switch (tmp->has_arg) {
				case no_argument:
					cnt_chars++;
					break;
				
				case required_argument:
					cnt_chars+=2;
					break;
				
				case optional_argument:
					cnt_chars+=3;
					break;
				
				default:
					exit(1);
			
			}
		}
		*tmp++;
	}
	tmp=longopt;
	cnt_chars++;
	ctmp=toret=(char*)malloc(sizeof(char)*cnt_chars);
	
	
	//Creation of the substirng
	while (!IS_EOOPT(tmp)) {
		if (!(tmp->flag)) {
			switch (tmp->has_arg) {
				case no_argument:
					*ctmp++=(char)tmp->val;
					break;
				
				case required_argument:
					*ctmp++=(char)tmp->val;
					*ctmp++=':';
					break;
				
				case optional_argument:
					*ctmp++=(char)tmp->val;
					*ctmp++=':';
					*ctmp++=':';
					break;
				
				default:
					exit(2);
			
			}
		}
		*tmp++;
	}
	*ctmp++='\0';
	
	return toret;
	
}

//Calls getopt_long using mkshortopt()
#define GETOPT_L(argc,argv,longk,optptr) getopt_long(argc,argv,mkshortopt(longk),longk,optptr)

//Does the matching using mkshortopt()
#define WHILE_GETOPT_L(argc,argv,longk,optptr,val) while(((val)=GETOPT_L(argc,argv,longk,optptr))!=-1)

//Obtains the long name of the current pace
#define LONGNAME(struc,opt)		((struc)[opt].name)

//The pointer to the value of the argument
#define HAS_ARG				(optarg)

//At the end of the cycle, returns if there are some other arguments
#define HAS_OTHER_ARGS(argc) 		(optind<(argc))

//Counts the remaining argc(s)
#define REMAINING_ARGS(argc)		((argc)-optind+1)

//If there is another arg, returns its char pointer
#define GET_NEXT_OPTIND(argc,argv)	(HAS_OTHER_ARGS(argc) ? ((argv)[optind++]) : ((char*)0) )




//Defines the cycles to retrieve args. 
#define START_CYCLE(argc,argv,longk)	do {\
						int option_index = 0;\
						int c;\
						WHILE_GETOPT_L(argc,argv,longk,&option_index,c) { \
						switch(c) {			
#define END_CYCLE			 } } } while(0)


#endif
