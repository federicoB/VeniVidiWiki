#include "args.h"
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>

void help() {

	printf("\n --in / -i (arg) : sostituisce lo stdin con il file arg\n \
--out /-o (arg) : sostituisce lo stdout con il file arg\n \
--help / -h     : visualizza questa schermata\n\n");
	       exit(0);
}

int main(int argc, char* argv[]) {


	char *input, *output;
	int  fdin, fdout;
	int  pos;
	
	input = output =  NULL;
	fdin = fdout = pos = 0;
	
	struct option lo[] = {
		{"in",	required_argument,0,'i'},//FUNZIONE
		{"out",	required_argument,0,'o'},//file
		{"help",no_argument	 ,0,'h'},
		{0,0,0,0}
	};
	
	START_CYCLE(argc,argv,lo)
		case 'i':
			input = HAS_ARG;
			break;
		case 'o':
			output= HAS_ARG;
			break;
		case 'h':
		default:
			help();
	END_CYCLE;

	if (input) {
		fdin = open(input, O_RDONLY);
		dup2(fdin,STDIN_FILENO);
	} 
	if (output) {
		fdout = open(output, O_WRONLY | O_TRUNC | O_CREAT, S_IRUSR | S_IRGRP | S_IWGRP | S_IWUSR);
		dup2(fdout,STDOUT_FILENO);
	}
	
	execvp(argv[optind],argv+optind);
	
}
