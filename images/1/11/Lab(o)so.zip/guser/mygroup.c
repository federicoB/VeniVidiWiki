#include <stdio.h>
#include <grp.h>


#define MAX_GROUPS 25

int main(int argc, char* argv[])
{
  int result;
  int i;
  gid_t groups[MAX_GROUPS];

  result = getgroups(MAX_GROUPS,groups);

  for(i = 0;i < result; i++)
  {
    struct group* grp;

    grp = getgrgid(groups[i]);

    printf("%s ",grp->gr_name);
  }

  printf("\n");
  return 0;
}
