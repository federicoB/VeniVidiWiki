#include <stdio.h>

void main(int argc, char* argv[]) {
	int x,y;
	if (argc==1) {
		scanf("%d%d",&x,&y);
		
	} else {
		x=atoi(argv[1]);
		if (argc>2) y=atoi(argv[2]); else y=x;
	}
	printf("%d\n",x+y);
}
