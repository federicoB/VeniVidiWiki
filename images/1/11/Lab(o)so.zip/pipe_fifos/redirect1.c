#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
int main()
{
 
#ifdef OPEN
    int file;
    if (((file = open("myfile.txt", O_APPEND | O_WRONLY | O_CREAT)) < 0)||(dup2(file,1) < 0))    return 1;
#else
    FILE *file;
    if (((file = fopen("myfile.txt","w"))==NULL)||(dup2(fileno(file),1) < 0))    return 1;
#endif
    printf("to file\n");
    return 0;
}
