#include <sys/stat.h>
#include <stdio.h>
#include <poll.h>
#include <stdio.h>
#include <fcntl.h>
#include <stdlib.h>

#ifndef _FIFO_H_
#define _FIFO_H_

//mkfifo(nomefile, 0)  : creazione di un file fifo

/** getfdpolled()
 * Data la struttura dati pollfd, il numero dei campi, il timeout e la maschera
 * che si vuole cercare, restituisce (-1) se 
 * nessun elemento aveva quella maschera, altrimenti il numero con quella 
 * maschera 
 */
static inline int getfdpolled(struct pollfd* polls, unsigned int n, int timeout, int mask) {
	int i;
	int cn;
	while (1) {
		while ((cn=poll(polls, n, timeout))<0);
		for (i=0; i<n; i++)
			if (polls[i].revents & mask) return i;
	}
}

/* ESEMPIO DI ALLOCAZIONE:

   struct pollfd *pfd;
   pfd=(struct pollfd*)malloc(sizeof(struct pollfd)*(argc-1));

   for (i=0; i<argc-1; i++) {
   	pfd[i].fd=open(argv[i+1], O_RDONLY);
   	pfd[i].events=POLLIN;
   }
*/

#endif
