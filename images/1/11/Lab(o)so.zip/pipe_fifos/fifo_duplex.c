/** file: pipe_poll_duplex.c
 *  author: Giacomo Bergami
 *  brief: Questo programma legge da n fifo e scrive nella pipe da stdin
 */

#include <poll.h>
#include <stdio.h>
#include <fcntl.h>
#include <stdlib.h>
#include <unistd.h>

int waitforpoll(struct pollfd* pfd, int n, int timeout) {
	int i;
   	int j=poll(pfd,n,timeout); //numero degli elementi in cui poll è vero.
   	if (j>=0) {
   		for (i=0; i<n; i++) 
   			if (pfd[i].revents & POLLIN)
   	   			return i;
   	}
}

int main(int argc, char *argv[]) {
   int p1, p2;
   
  
   
       //Creates a fifo file 
    mkfifo(argv[2], 0666);

    //Opens the pipe for writing
  int fd = open(argv[2], O_WRONLY);
  
  
  if (fork()) {

	close(STDOUT_FILENO);
      while (1) {
       char buffer;
       scanf("%c",&buffer);
       write(fd, &buffer, sizeof(char));
    }
  
  } else {
  
  	int fd2=open(argv[1], O_RDONLY);
  	close(STDIN_FILENO);
  	while (1) {
  		char buf;
		read(fd2, &buf, sizeof(char));
		putchar(buf);
  	}
  
  }
  
}
