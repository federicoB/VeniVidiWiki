//Pipe serve solamente per fornire uno scambio di informazioni 
#include <stdio.h>

#define in_pipe(fd)	(fd)[1]
#define out_pipe(fd)	(fd)[0]

#define mkpipe(fd)	if(pipe(fd) < -1){ fprintf(stderr, "ERROR PIPE creation"); exit(1); }

//Redirezione nell'input nella Pipe
#define redirect_to_input(pipe,new)  	dup2((pipe)[1],new);
//Redirezioen dall'output della Pipe
#define redirect_from_out(pipe,new)  	dup2(new,(pipe)[0]);
