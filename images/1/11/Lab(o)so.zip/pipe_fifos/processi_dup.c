#include "../main_include/default.h"
#include "../pipe_fifos/pipe.h"
#include "../files/read_write.h"
#include <stdio.h>
#include <errno.h>
#include <ctype.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <poll.h>
#include <stdio.h>
#include <fcntl.h>
#include <stdlib.h>


int dpipe[2];

void awrite(char k, int in) {
	int j=1;
	int i;
	char send;
	for (i=0; i<8; i++) {
		send=(char)((k&(j<<i)) ? 1 : 0);
		write(in,&send,sizeof(char));
	}
}

char* aread(char w) {
	static char init=(char)0;
	static int  count=0;
	
	init = init | (w<<(count++));
	if (count==8) {
		char *allocco;
		allocco=(char*)malloc(sizeof(char));
		*allocco=init;
		count=0;
		init=(char)0;
		return allocco;
	}
	return NULL;

}

int waitforpoll(struct pollfd* pfd, int n, int timeout) {
	int i;
   	int j=poll(pfd,n,timeout); //numero degli elementi in cui poll è vero.
   	if (j>=0) {
   		for (i=0; i<n; i++) 
   			if (pfd[i].revents & POLLIN)
   	   			return i;
   	}
}




int main(int argc, char* argv[]) {

   int fd;
   struct pollfd pfd;
   mkfifo(argv[1], 0666);
   fd = open(argv[1], O_WRONLY);
   pfd.fd=open(argv[2], O_RDONLY);
   pfd.events=POLLIN;
   
   if (fork()) {
   
	    //Writes the pipe from stdin
	    while (1) {
	       char buffer[1024];
	       scanf("%s",buffer);
	       printf("ok: %s\n", buffer);
	       write(fd, buffer, strlen(buffer));
	       
	       /* writes the CR */
	       buffer[0]='\n';
	       write(fd, buffer, 1);
	    }
   
   } else {
	  
	   char buf[1024];
	   
	   while (1) {
	   	int k = waitforpoll(&pfd,1,-1);
	   	int nr=read(pfd.fd,buf,1024);
	   	write(1,buf,nr);
	   }
   
   }

}

