#include <sys/types.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <stdlib.h>

#include "pipe.h"



/* Questo programma effettua la redirezione dello 
   standard output da un programma in esecuzione ad un
   file, utilizzando delle pipe */

int main(){
	int fd[2];
	int child1_fd;
  	char *path;
  	
  	//path=get_current_dir_name();

	mkpipe(fd);
	mkfork(&child1_fd);

	if(child1_fd == 0){

	    // closing pipe reading
	    close(out_pipe(fd));
	    // closing stdout and redirecting to fd
	    redirect_to_input(fd,1);

	    execl("./sum", "./sum", NULL);

	   /*Chiusura corretta:
	   
	    close(fd[1]);
	    exit(0);*/
    
	} else {
	    char p[1];
	    char *buf;
	    FILE* outf;

	    // closing pipe writing
	    close(in_pipe(fd));
	    
	    //CREATING FILE
	    outf = fopen("path", "w");
	    
	    //Redirecting STDOUT to file
	    dup2(fileno(outf),1);

	    /* Some writing */
	    while (read(fd[0],p,1)>0)
	    	printf("%c", p[0]);

	    printf("child is done\n");

	    exit(0);
  	}
}

