/** file: pipe_poll_example.c
 *  author: Giacomo Bergami
 *  brief: Questo programma legge da n fifo e butta il contenuto in stdout
 */

#include <poll.h>
#include <stdio.h>
#include <fcntl.h>
#include <stdlib.h>

int waitforpoll(struct pollfd* pfd, int n, int timeout) {
	int i;
   	int j=poll(pfd,n,timeout); //numero degli elementi in cui poll è vero.
   	if (j>=0) {
   		for (i=0; i<n; i++) 
   			if (pfd[i].revents & POLLIN)
   	   			return i;
   	}
}

int main(int argc, char *argv[]) {
   int p1, p2;
   
   struct pollfd *pfd;
   pfd=(struct pollfd*)malloc(sizeof(struct pollfd)*(argc-1));
   
   int i;
   for (i=0; i<argc-1; i++) {
   	pfd[i].fd=open(argv[i+1], O_RDONLY);
   	pfd[i].events=POLLIN;
   }
  
   char buf[1024];
   
   while (1) {
   	int k = waitforpoll(pfd,argc-1,-1);
   	int nr=read(pfd[k].fd,buf,1024);
   	write(1,buf,nr);
   }
   
}
