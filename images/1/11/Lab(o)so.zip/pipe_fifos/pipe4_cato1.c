#include <sys/types.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <stdlib.h>

#include "pipe.h"
#include "../forks/forka.h"

/* Questo programma accetta un comando del tipo: 

    cato bannedword cmds ....
    
   e restituisce l'output del comando privato della
   bannedword */

int main(int argc, char* argv[]){
	int fd[2];
	int child1_fd;
  
  	if (argc<=2) return 0;
  
  	char *nasty = argv[1];

	mkpipe(fd);
	mkfork(&child1_fd);

	if(child1_fd == 0){
	    char buf[4028];
	    int len=0;
	    // closing pipe writing
	    close(in_pipe(fd));
	    // closing stdout and redirecting to fd
	    while ((read(fd[0],&buf[len++],1)>0)) {
	    	if ((buf[len-1]==' ')||buf[len-1]=='\n') {
	    		char tmp = buf[len-1];
	    		buf[len-1]='\0';
	    		if (strcmp(buf,nasty)) printf("%s%c",buf,tmp);
	    		len=0;
	    	}
	    }
    
	} else {
	    char p[1];
	    char *buf;
	    FILE* outf;

	    // closing pipe reading
	    close(out_pipe(fd));
	    
	    //Redirecting STDOUT to pipe
	    dup2(in_pipe(fd),1);

	    execvp(argv[2], argv+2);

	    exit(1);
  	}
}

