#include <sys/types.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <stdlib.h>


#define mkfork(val)	do { (val)[0] = fork(); if((val)[0] < 0){ fprintf(stderr, " CHILD creation error"); exit(1); } } while(0)

#include "../forks/forka.h"
#include "pipe.h"

#define MAX

typedef struct {
	int fd[2];
} pfd;

/* Questo programma effettua la redirezione dello 
   standard output da un programma in esecuzione ad un
   file, utilizzando delle pipe */

int main(){
	int fd[2];
	int child1_fd;
  	char *path;
  	
  	//path=get_current_dir_name();

	mkpipe(fd);
	mkfork(&child1_fd);

	if(child1_fd == 0){

	    // closing pipe reading
	    close(fd[0]);
	    // closing stdout and redirecting to fd
	    dup2(fd[1],1);

	    
	    execl("./num", "./num", NULL);
    
	} 
	 {
	    FILE* outf;

	    // closing pipe writing
	     
	    close(fd[1]);
	    
	    //CREATING FILE
	    outf = fopen("pathening", "w+");
	    
	    //replace standard input with input part of pipe
	    dup2(fd[0], 0);
	    
	    //replace standard output with file writing
	    dup2(fileno(outf),1);
	    execl("./num", "./num", NULL);

	    //printf("child is done\n");

	    exit(0);
  	}
}

