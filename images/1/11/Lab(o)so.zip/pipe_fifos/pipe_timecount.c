#include <stdio.h>
#include "pipe.h"
#include "../forks/forka.h"
#include <time.h>
#include <string.h>

void fillalphabet(char* buf, int len) {
	char map[]="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
	static int c=0;
	int i;
	for (i=0; i<len-1; i++) {
		buf[i]=map[(c++)%strlen(map)];
	}
	buf[len-1]=(char)0;
}

int main(void) {
	
	int NS[2];
	int SN[2];
	float time;
	
	pid_t son;
	clock_t start,stop;
	
	mkpipe(NS);
	mkpipe(SN);
	
	mkfork(&son);
	
	start = clock();
	
	if (son) {
	
		int i,j;
		char buf_send[40];
		char buf_recv[40];
		close(NS[0]);//Scrive su NS1
		close(SN[1]);//Legge  da SN0
		fillalphabet(buf_send,40);
		
		for (j=0; j<100000; j++) {
			write(NS[1],buf_send,40);
			read(SN[0],buf_recv,40);
			printf("%d, ", j, buf_recv);
		}
	
	} else {
		int i;
		char buf_recv[40];
		close(NS[1]);//Legge  da NS0
		close(SN[0]);//Scrive su SN1
		for (i=0; i<100000; i++) {
			read(NS[0],buf_recv,40);
			write(SN[1],buf_recv,40);
		}
		return 0;
	
	}
	
	printf("\n\nTime elapsed: %f\n\n", (((double)clock()-start) / CLOCKS_PER_SEC));
	
	
}
