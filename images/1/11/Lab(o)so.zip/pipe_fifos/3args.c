#include <stdio.h>
#include <stdlib.h>

int main(int argc, char* argv[]) {
	
	int i,*nums;
	
	nums=(int*)malloc(sizeof(argc-1));
	
	if (!nums) return -1;

	if (argc==1) {
		char buf1[1024],buf2[1024],buf3[1024];
		if (scanf("%s%s%s", buf1, buf2, buf3)==3) {
#ifndef OUT
			printf("%s %d %d\n", buf1, atoi(buf2)+atoi(buf1), atoi(buf2)+atoi(buf1)+atoi(buf3));
#else
			printf("%s %s %s\n", buf1, buf2, buf3);
#endif
			//return 0;
		}
		else return -1;
	}

	for (i=1; i<argc; i++)  {
#ifndef OUT
		nums[i-1]=atoi(argv[i]);
		if ((i-1)>0) nums[i-1]=nums[i-1]+nums[i-2];
		printf("%d ", nums[i-1]);
#else
		printf("%s ", argv[i]);
#endif
	}


#ifdef LAST
	printf("last!:\n");
#endif

	
}
