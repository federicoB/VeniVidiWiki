#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/types.h>
#include <string.h>

//Pipe serve solamente per fornire uno scambio di informazioni 
#define in_pipe(fd)	(fd)[1]
#define out_pipe(fd)	(fd)[0]

int main() {

       int     fd[2], nbytes;
        pid_t   childpid;
        char    string[] = "Hello, world!\n";
        char    readbuffer[80];

        pipe(fd);
        
        if((childpid = fork()) == -1)
        {
                perror("fork");
                exit(1);
        }

        if(childpid == 0)
        {
                close(fd[0]);
                dup2(STDIN_FILENO,fd[1]);
	        printf("ciao ciao");
	        //while(1);
                /* Send "string" through the output side of pipe */
                //write(fd[1], string, (strlen(string)+1));
                //printf("tentativo!! e se non bastasse, ti scrivo ancora, and again, and again, and again.");
                exit(0);
        }
        else
        {
                close(fd[1]);

		waitpid(childpid,NULL,0);

                /* Read in a string from the pipe */
                nbytes = read(fd[0], readbuffer, sizeof(readbuffer));
                printf("Received string %s\n", readbuffer);
        }
        
        return(0);

	
}
