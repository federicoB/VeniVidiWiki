#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>

typedef struct {
	int fd[2];
} pfd;

int main(int argc, char **argv)
{
  pfd x[1];
  int pid;

  char *cat_args[] = {"./num",NULL};
  char *grep_args[] = {"./num",  NULL};

  // make a pipe (fds go in pipefd[0] and pipefd[1])

  pipe(x[0].fd);

  pid = fork();

  if (pid == 0)
    {


      // replace standard input with input part of pipe
      dup2(x[0].fd[0], 0);

      // close unused hald of pipe
      close(x[0].fd[1]);

      // execute grep

      execvp(*grep_args, grep_args);
    }
  else
    {

      // replace standard output with output part of pipe
      dup2(x[0].fd[1], 1);

      // close unused unput half of pipe
      close(x[0].fd[0]);

      // execute cat

      execvp(*cat_args, cat_args);
    }
}
