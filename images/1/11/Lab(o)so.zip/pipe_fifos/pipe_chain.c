/** Questo programma effettua una chiamata concatenata dei programmi,
    lanciando al programma corrente l'output del precedente, e fornendo
    il suo output al successivo come input (pipe) */
#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>

#ifndef MAX
#define MAX 3
#endif

int main(int argc, char **argv)
{
  int status;
  int i;

  // arguments for commands; your parser would be responsible for
  // setting up arrays like these

  char *cat_args[] = {"./num",NULL};
  char *grep_args[] = {"./num", NULL};
  char *cut_args[] = {"./num",  NULL};

  // make 2 pipes (cat to grep and grep to cut); each has 2 fds

  int pipes[(MAX-1)*2];
  pid_t pid[MAX];
  for (i=0; i<MAX-1; i++) {
  	int j=i*2;
  	pipe(pipes+j);
  }
  
  for (i=0; i<MAX; i++) {
  	pid[i]=fork();
  	if (pid[i] == 0) {
  		if (i==0) {
  			dup2(pipes[1], 1);
  			//ESECUZIONE
      			execvp(*cat_args, cat_args);
      			//CONTROLLA USCITA
  		} else if (i==MAX-1) {
  			dup2(pipes[(i-1)*2], 0);
  			//ESECUZIONE
	      		execvp(*cut_args, cut_args);
	      		//CONTROLLA USCITA
  		} else {
  			dup2(pipes[(i-1)*2], 0);
	  		dup2(pipes[i*2+1], 1);
	  		//ESECUZIONE
	  		execvp(*grep_args, grep_args);
	  		//CONTROLLA USCITA
  		}
  	}
  }

  for (i = 0; i < MAX; i++)
    waitpid(pid[i],NULL,0);
}
