#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include "../shmeme/shmem.h"
#include "../pipe_fifos/pipe.h"
#include "forka.h"

/** WAITING **/
#include <poll.h>
#include <stdio.h>
#include <fcntl.h>
#include <stdlib.h>


/* mettere a posto la comunicazione con un livello in più */
#ifndef N
#define N 3
#endif

#define SLEEP_RATE  	0
#define MAX(x,y)	((x>y) ? x : y)
#define MIN(x,y)	((x<y) ? x : y)

#define finedimondo 1


int fd[2];
int* pos;

// -------------------- Funzioni di inizializzazione/chiusura 


void communicate(int level, int *fd_frompadre, int *fd_topadre) {

	printf("init level %d\n", level);
	pid_t sx, dx;
	int fd[8];
	
	mkpipe(fd);		//Pipe per la comunicazione padre->figlo sx
	mkpipe((fd+2));		//Pipe per la comunicazione padre->figlo dx
	mkpipe((fd+4));		//Pipe per la comunicazione figlo sx->padre
	mkpipe((fd+6));		//Pipe per la comunicazione figlo dx->padre
	
	mkfork(&sx); 
	if (!sx) {
		
		/* FIGLIO SINISTRO */
		struct pollfd SX[2];
		
		printf("init level %d sx\n", level);
		srand(time(NULL)+3*(level+1));
		
		if (level) { printf("leveldown\n"); communicate(level-1,fd,fd+4); }
		
		SX[0].fd=(fd+4)[1];
		SX[0].events = POLLOUT;	
		SX[1].fd=fd[0];	
		SX[1].events = POLLIN;
		
		//Se invece sono una foglia
		while (finedimondo) {
			int tmp = rand()%10+1;
			int ret;

			poll(SX,2,-1);
			if (SX[0].revents & POLLIN) {
				read (out_pipe(fd),  &ret,sizeof(int));
				printf("%ds ~ recv = %d\n", level,ret);
			}
			write(in_pipe(fd+4),&tmp,sizeof(int));
			
			
			sleep(SLEEP_RATE);
		}
		exit(1);
	} 
	
	mkfork(&dx);
	if (!dx) {
		
		/* FIGLIO DESTRO */
		struct pollfd DX[2];
		printf("init level %d dx\n", level);
		srand(time(NULL)+2*(level+1));
		
		if (level) { printf("leveldown\n"); communicate(level-1,fd+2,fd+6); }
		
		DX[0].fd=(fd+6)[1];
		DX[0].events = POLLOUT;	
		DX[1].fd=(fd+2)[0];	
		DX[1].events = POLLIN;
		
		//Se invece sono una foglia
		while (finedimondo) {
			int tmp = rand()%10+1;
			int ret;
			
			poll(DX,2,-1);
			if (DX[0].revents & POLLIN) {
				read (out_pipe(fd+2),  &ret,sizeof(int));
				printf("%ds ~ recv = %d\n", level,ret);
			}
			write(in_pipe(fd+6),&tmp,sizeof(int));
				
			sleep(SLEEP_RATE);
		}
		exit(1);
	}
	
	/* PROCESSO PADRE */
	srand(time(NULL)+(level+1));
	char start=(char)1;
	int i;
	
	
	//INIT
	int get[2];
	int sum=-1;
	int ret=-1;
	int sonrecv=0;
	
	while (finedimondo) {
		
		struct pollfd FX[6];
		
		//Inizializzazione delle strutture dati
		FX[0].fd=(fd+4)[0];
		FX[0].events = POLLIN;	
		FX[1].fd=(fd+6)[0];	
		FX[1].events = POLLIN;
		FX[2].fd=(fd)[1];
		FX[2].events = POLLOUT;
		FX[3].fd=(fd+2)[1];
		FX[3].events = POLLOUT;
		
		if ((fd_frompadre)&&(fd_topadre)) {
			FX[4].fd=(fd_frompadre)[0];
			FX[4].events = POLLIN;
			FX[5].fd=(fd_topadre)[1];
			FX[5].events = POLLOUT;
		} else {
			FX[4].fd=1;
			FX[4].events = POLLOUT;
			FX[5].fd=1;
			FX[5].events = POLLOUT;
		}
	
		poll(FX,6,-1);
		
		
		
		if (FX[0].revents & POLLIN) 
			read(out_pipe(fd+4),&get[sonrecv++],sizeof(int));
		if ((sonrecv>=2)/*&&(SX[0].revents & POLLOUT)*/) {
			sonrecv=0;
			printf("%df ~ recv (%d,%d)\n", level,get[0],get[1]);
			sum = get[0]+get[1];
		}
		if (FX[1].revents & POLLIN) 
			read(out_pipe(fd+6),&get[sonrecv++],sizeof(int));
		if ((sonrecv>=2)/*&&(SX[0].revents & POLLOUT)*/) {
			sonrecv=0;
			printf("%df ~ recv (%d,%d)\n", level,get[0],get[1]);
			sum = get[0]+get[1];
		}
		if ((fd_frompadre)&&(fd_topadre))
			write(in_pipe(fd_topadre),  &sum,sizeof(int));
		
		write(in_pipe(fd),  &sum,sizeof(int));
		write(in_pipe(fd+2),&sum,sizeof(int));
		
		if ((fd_frompadre)&&(fd_topadre)&&(FX[4].revents & POLLIN)) {
			read(out_pipe(fd_frompadre),&sum,sizeof(int));
			printf("{%df ~ recv [%d]}\n", level,sum);
		}
		sleep(SLEEP_RATE);
	}
	
}


void main(void) {

	communicate(N,NULL,NULL);

}
	
