#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/wait.h>

//Il parametro ptr è una stringa che identifica il figlio eseguito.
//Il padre aspetta sempre che il figlio termini l'esecuzione
#define begin_childfork(ptr)	do { pid_t child; int retnum;  \
			if ((child=fork())>0) { printf("waiting\n");\
		  		waitpid(child, &retnum, 0); printf("exit\n");\
		  		if ((WEXITSTATUS(retnum))) {\
		  		  printf("Aborting: error %d in forked child [%s]\n", WEXITSTATUS(retnum), ptr);\
		  		  exit(1);\
		  		}\
			} else {

#define end_childfork }} while(0);


//Funzione che controlla che il forking sia andato a buon fine
#define mkfork(val)	do { (val)[0] = fork(); if((val)[0] < 0){ fprintf(stderr, " CHILD creation error"); exit(1); } } while(0)
//Funzione che controlla che l'attesa vada a buon fine
#define my_waitpid(pid) if (waitpid(pid,NULL,0)<0) { fprintf(stderr, "waitpid error"); exit(1); }
