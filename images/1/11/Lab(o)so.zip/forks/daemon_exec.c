/* Esercizio: 15 febbraio 2011 */
/* questo programma può essere molto utile nel caso dei 
   demoni, la cui operazione può non sempre andare */
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/wait.h>

int main(int argc, char* argv[]) {

    int status;
    pid_t pid;
    
    do {
	    if ((pid = fork())>0) {
	      /* caso del padre; nota: bisogna anche controllare
		 il caso in cui venga restituito un valore negativo*/
	      waitpid(pid, &status,0);
	      printf("exit %d\n", WEXITSTATUS(status));
	      sleep(2);
	    } else {
	      execvp(argv[1], argv+1);
	      exit(-1); /* non deve mai accadere */
	    }
    } while (1);  //WEXITSTATUS(status):: in questo caso esce solo per terminazione 0
}
