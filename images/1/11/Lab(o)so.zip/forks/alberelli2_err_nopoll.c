#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include "../shmeme/shmem.h"
#include "../pipe_fifos/pipe.h"
#include "forka.h"

/* mettere a posto la comunicazione con un livello in più */
#ifndef N
#define N 0
#endif

#define SLEEP_RATE  0

#define finedimondo 1


int fd[2];
int* pos;

// -------------------- Funzioni di inizializzazione/chiusura 

void communicate(int level, int *fd_padre) {

	printf("init level %d\n", level);
	pid_t sx, dx;
	int fd[8];
	
	mkpipe(fd);		//Pipe per la comunicazione padre->figlo sx
	mkpipe((fd+2));		//Pipe per la comunicazione padre->figlo dx
	mkpipe((fd+4));		//Pipe per la comunicazione figlo sx->padre
	mkpipe((fd+6));		//Pipe per la comunicazione figlo dx->padre
	
	mkfork(&sx); 
	if (!sx) {
		
		/* FIGLIO SINISTRO */
		int self_fd[4];
		char start=(char)1;
		
		srand(time(NULL)+2*(level+1));
		//Sviluppo l'albero se non sono già arrivato in fondo
		if (level) {
			mkpipe(self_fd);mkpipe(self_fd+2);
			if (fork()) communicate(level-1,self_fd);
		}
		
		printf("init level %d sx\n", level);
		
		while (finedimondo) {
			int val = rand()%10+1;
			int ret;
			
			if ((level)&&(!start)) {
				int from_sons, from_daddy;
				//Se sono padre, leggo le letterine dei figli dalla mia controparte
				read(in_pipe(self_fd),&from_sons,sizeof(int));
				
				//Lo comunico al loro nonno
				write(in_pipe(fd+4),&from_sons,sizeof(int));
				
				//Leggo cosa dice il nonno
				read (out_pipe(fd), &from_daddy,sizeof(int));
				
				printf("{%ds ~ received from parent: %d}\n", level, ret);
				
				//Glielo dico ai nipoti
				write(in_pipe(self_fd+2),&from_daddy,sizeof(int));
			}
			
			write(in_pipe(fd+4),&val,sizeof(int));
			read (out_pipe(fd), &ret,sizeof(int));
			
			printf("%ds ~ received from parent: %d\n", level, ret);
			if ((level)&&(!start)) {
				//Glielo dico ai nipoti
				write(in_pipe(self_fd),&ret,sizeof(int));
			}
			start=0;
			sleep(SLEEP_RATE);
		}
		exit(1);
	} 
	
	mkfork(&dx);
	if (!dx) {
		
		/* FIGLIO DESTRO */
		int self_fd[4];
		char start=(char)1;
		
		srand(time(NULL)+2*(level+2));
		//Sviluppo l'albero se non sono già arrivato in fondo
		if (level) {
			mkpipe(self_fd);mkpipe(self_fd+2);
			if (fork()) communicate(level-1,self_fd);
		}
		
		printf("init level %d dx\n", level);
		
		while (finedimondo) {
			int val = rand()%10+1;
			int ret;
			
			if ((level)&&(!start)) {
				int from_sons, from_daddy;
				//Se sono padre, leggo le letterine dei figli dalla mia controparte
				read(in_pipe(self_fd),&from_sons,sizeof(int));
				
				//Lo comunico al loro nonno
				write(in_pipe(fd+6),&from_sons,sizeof(int));
				
				//Leggo cosa dice il nonno
				read (out_pipe(fd+2), &from_daddy,sizeof(int));
				
				printf("{%ds ~ received from parent: %d}\n", level, ret);
				
				//Glielo dico ai nipoti
				write(in_pipe(self_fd+2),&from_daddy,sizeof(int));
			}
			write(in_pipe(fd+6),&val,sizeof(int));
			read(out_pipe(fd+2),&ret,sizeof(int));
			printf("%dd ~ received from parent: %d\n", level,ret);
			if ((level)&&(!start)) {
				//Glielo dico ai nipoti
				write(in_pipe(self_fd),&ret,sizeof(int));
			}
			start=0;
			sleep(SLEEP_RATE);
		}
		exit(1);
	}
	
	/* PROCESSO PADRE */
	srand(time(NULL)+(level+1));
	char start=(char)1;
	int i;
	
	while (finedimondo) {
		int val_sx, val_dx, out, res;
		if (start) {
			read(out_pipe(fd+4), &val_sx, sizeof(int));
			read(out_pipe(fd+6), &val_dx, sizeof(int));
			start=0;
		} else {
			read(out_pipe(fd+4), &val_sx, sizeof(int));
			read(out_pipe(fd+6), &val_dx, sizeof(int));
		}
		printf("%df ~ received (%d,%d)\n",level,val_sx,val_dx);
		out = val_sx+val_dx;
		
		if (!fd_padre) printf("non faccio niente\n");
		else {
			/* spedisco sopra i valori */
			write(in_pipe(fd_padre+2),&out,sizeof(int));
			/* leggo da mio padre */
			read(out_pipe(fd_padre),&res,sizeof(int));
			printf("{%df ~ received from parent: %d}\n", level,res);
			/* comunico notizie del nonno ai figli */
			write(in_pipe(fd), &res, sizeof(int));
			write(in_pipe(fd+2), &res, sizeof(int));
		}
		/* comunico la mia notizia ai figli */
		write(in_pipe(fd), &out, sizeof(int));
		write(in_pipe(fd+2),&out,sizeof(int));
		sleep(SLEEP_RATE);
	
	}

}


void main(void) {

	communicate(N,NULL);

}
	
