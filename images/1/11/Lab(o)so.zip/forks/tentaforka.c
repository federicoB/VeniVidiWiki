#include "forka.h"
#include <string.h>

/**  todigit():
 *  Funzione che converte la stringa str in numero.
 *  Se tutti i caratteri di str sono solo cifre,
 *  allora todigit restituisce lo stesso puntatore
 *  passato in toret e viene aggiornato il suo contenuto,
 *  altrimenti toret non viene modificata, e viene restituito un
 *  puntatore a null */
int* todigit(char* str, int*toret) {
	int j;
	for (j=0; j<strlen(str); j++)  {
		if (!isdigit(str[j])) return NULL;
	}
	*toret = atoi(str);
	return toret;
}

/**  mkprocpid():
 *  Assegna al processo un preciso pid 
 */
void mkprocpid(int j) {
	char not_done=(char)1;
	if (getpid()!=j) {
		waitpid(j,NULL,0);
		printf("Ok: no process %d exists\n", j);
		while (not_done) {
			pid_t son=fork();
			if (son>0) {
				if (son==j) exit(0);
				else  kill(son,9);
			} else if (son==0) {
				if (getpid()!=j) exit(1);
				not_done=(char)0;
			}
		}
	}

}

int main(int argc, char* argv[]) {
	
	int j;
	if ((argc==1)||(!todigit(argv[1],&j)))  exit(0);
	mkprocpid(j);
	
	printf("PID:%d\n", getpid());
	
	return (0);
	
}
