/************************************************************************/
/* Autore 	: Vincenzo Ferrari 					*/
/* Data 	: 27/08/2010 						*/
/* Licenza	: Creative Commons BY - NC - SA Ver. 3.0		*/
/* Email	: ferrari@cs.unibo.it || wilk3ert@gmail.com		*/
/* Sito Web	: http://www.wilky.it/					*/
/* Info Licenza	: http://creativecommons.org/licenses/by-nc-sa/3.0/	*/
/************************************************************************/

/* 								03 febbraio 2010								*/
/*
Esercizio2: (5 punti): Scrivere in C un programma che stampi quanti file, quanti link simbolici, file speciali, quante
directory sono presenti nella directory corrente.
*/

#include <stdio.h>
#include <sys/types.h>
#include <dirent.h>
#include <errno.h>

int main(int argc, char* argv[])
{
	DIR *dd;
	struct dirent *curDir;
	int countFR, countLS, countFS, countD;
	int ris;
	
	countFR = countLS = countFS = 0;
	countD = -2;
	
	/* Apre la directory */
	if((dd = opendir(".")) == NULL) perror("main:");
	/* Legge un file alla volta della directory */
	while(curDir = (readdir(dd)))
	{
		switch(curDir->d_type)
		{
			/* Per i file regolari ... */
			case DT_REG:
				countFR++;
			break;
			/* Per le directory ... */
			case DT_DIR:
				countD++;
			break;
			/* Per i link simbolici ... */
			case DT_LNK:
				countLS++;
			break;
			/* Per i file a blocchi ... */
			case DT_BLK:
				countFS++;
			break;
			/* Per i file a caratteri ... */
			case DT_CHR:
				countFS++;
			break;
		}
	}
	printf("Nella directory corrente sono presenti: \n");
	printf("- %d file regolari\n", countFR);
	printf("- %d link simbolici\n", countLS);
	printf("- %d file speciali\n", countFS);
	printf("- %d directory\n", countD);
	
	if(ris = (closedir(dd)) == -1) perror("main:");
}
