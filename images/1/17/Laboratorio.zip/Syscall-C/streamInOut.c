/************************************************************************/
/* Autore 	: Vincenzo Ferrari 					*/
/* Data 	: 27/08/2010 						*/
/* Licenza	: Creative Commons BY - NC - SA Ver. 3.0		*/
/* Email	: ferrari@cs.unibo.it || wilk3ert@gmail.com		*/
/* Sito Web	: http://www.wilky.it/					*/
/* Info Licenza	: http://creativecommons.org/licenses/by-nc-sa/3.0/	*/
/************************************************************************/

/* 								14 luglio 2009								*/
/*
Esercizio1 (obbligatorio): (20 punti) Scrivere un programma in linguaggio C denominato “stampallafine” che tramite la
chiamata open_memstream (leggere il man!) salvi tutto cio' che riceve da standard input in una stringa. Quando lo
standard input termina, l'intera stringa deve essere copiata sullo standard output.
(Ricordate di definire la costante _GNU_SOURCE prima di includere stdio.h)
*/

#define _GNU_SOURCE
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <errno.h>
#include <string.h>

int main(int argc, char* argv[])
{
	char *ptr;
	char *v;
	size_t size, sizeloc, nmemb;
	FILE *in;
	int ris;
	
	/* Ptr è il puntatore all'area di memoria allocata dinamicamente per l'input */
	/* In è il file descriptor dell'input */
	if((in = open_memstream(&ptr, &sizeloc)) == NULL) perror("main:");
	while(scanf("%m[a-z % ? ! _ - 0-9 ^]", &v)) /* soluzione alquanto pacchiana */
	{
		/* fprintf scrive sul file in ciò che è letto da input */
		fprintf(in, "%s", v);
	}
	fclose(in);
	fprintf(stdout, "%s\n", ptr);
	free(ptr);
	free(v);

	return 0;
}
