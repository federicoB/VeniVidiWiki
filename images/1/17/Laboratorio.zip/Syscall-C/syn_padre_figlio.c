/************************************************************************/
/* Autore 	: Vincenzo Ferrari 					*/
/* Data 	: 27/08/2010 						*/
/* Licenza	: Creative Commons BY - NC - SA Ver. 3.0		*/
/* Email	: ferrari@cs.unibo.it || wilk3ert@gmail.com		*/
/* Sito Web	: http://www.wilky.it/					*/
/* Info Licenza	: http://creativecommons.org/licenses/by-nc-sa/3.0/	*/
/************************************************************************/

/* Il processo padre e il processo figlio si sincronizzano tramite le SIGNAL */

#include <stdio.h>
#include <unistd.h>
#include <errno.h>
#include <signal.h>
#include <sys/types.h>
#include <stdlib.h>

pid_t pidParent, pidChild1, pidChild2;

void sigHandler(int signo)
{
	int status;
	
	if(signo == SIGCHLD)
	{
		wait(&status);
		printf("Il figlio è terminato con status %d.\n", status>>8);
	}
	
	return;
}

int main(int argc, char* argv[])
{
	pid_t pid;
	int i;
	
	pidParent = getpid();
	
	printf("Pid del genitore : %d\n", getpid());
	
	/* SIGCHLD viene inviata al padre quando un figlio termina */
 	/* Si può prelevare lo status del figlio terminante con una wait() all'interno del gestore dei segnali */
	if(signal(SIGCHLD, sigHandler) == SIG_ERR) perror("signal():");
	
	/* Primo figlio */
	if((pid = fork()) == 0)
	{
		/* Il figlio si ferma con pause(), ossia si risveglierà quando gli arriverà un segnale */
		printf("Creazione del 1° figlio con pid %d.\n", getpid());
		pause();
		exit(0);
	}
	else if(pid < 0) perror("fork():");
	else pidChild1 = pid;
	
	sleep(2);
	
	printf("Il pid del 1° è %d\n", pidChild1);
	
	/* Secondo figlio */
	if((pid = fork()) == 0)
	{
		/* Il figlio anche qui si ferma con pause() in attesa di un segnale */
		printf("Creazione del 2° figlio con pid %d.\n", getpid());
		pause();
		exit(0);
	}
	else if(pid < 0) perror("fork():");
	else pidChild2 = pid;
	
	sleep(2);
	
	printf("Il pid del 2° è %d\n", pidChild2);
	
	printf("Uccisione del primo figlio con pid %d.\n", pidChild1);
	
	/* Il padre ammazza i figli con kill(pid, SIGKILL) */
	if(kill(pidChild1, SIGKILL) == -1) perror("kill():");
	
	sleep(2);
	
	printf("Uccisione del secondo figlio con pid %d.\n", pidChild2);
	
	if(kill(pidChild2, SIGKILL) == -1) perror("kill():");
	
	sleep(2);
	
	printf("E ora anche il padre termina.\n");
	
	return 0;
}
