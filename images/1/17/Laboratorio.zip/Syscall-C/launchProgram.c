/************************************************************************/
/* Autore 	: Vincenzo Ferrari 					*/
/* Data 	: 27/08/2010 						*/
/* Licenza	: Creative Commons BY - NC - SA Ver. 3.0		*/
/* Email	: ferrari@cs.unibo.it || wilk3ert@gmail.com		*/
/* Sito Web	: http://www.wilky.it/					*/
/* Info Licenza	: http://creativecommons.org/licenses/by-nc-sa/3.0/	*/
/************************************************************************/

/* Lancia il programma passato per parametro dal processo figlio */

#include <stdio.h>
#include <sys/wait.h>
#include <unistd.h>
#include <stdlib.h>

int main(int argc, char* argv[])
{
	pid_t pidChild;
	pid_t pidParent;
	pid_t pid;
	
	pidParent = getpid();
	
	if((pidChild = fork()) == -1) perror("fork():");
	
	pid = getpid();
	
	/* Il genitore si mette in attesa del figlio e poi termina */
	if(pid == pidParent)
	{
		if(waitpid(pidChild, NULL, 0) != pidChild) perror("waitpid():");
		exit(0);
	}
	/* Il figlio lancia il comando passato per parametro e termina */
	else
	{
		execvp(argv[1], &argv[1]);
		exit(0);
	}
}
