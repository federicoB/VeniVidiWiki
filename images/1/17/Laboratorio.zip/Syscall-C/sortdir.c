/************************************************************************/
/* Autore 	: Vincenzo Ferrari 					*/
/* Data 	: 27/08/2010 						*/
/* Licenza	: Creative Commons BY - NC - SA Ver. 3.0		*/
/* Email	: ferrari@cs.unibo.it || wilk3ert@gmail.com		*/
/* Sito Web	: http://www.wilky.it/					*/
/* Info Licenza	: http://creativecommons.org/licenses/by-nc-sa/3.0/	*/
/************************************************************************/

/* Esercizio1 (obbligatorio): (20 punti) Usando le chiamate opendir, readdir, closedir, qsort realizzare un programma in */
/* linguaggio C che metta in output la lista dei file della directory corrente in ordine alfabetico inverso. */
/* (l'output deve essere equivalente a quello del comando “ls . | sort -r”). */

#include <stdio.h>
#include <sys/types.h>
#include <dirent.h>
#include <stdlib.h>

static int compare(const void * a, const void * b)
{
	return strcmp(* (char * const *) a, * (char * const *) b);
}

int main(int argc, char* argv[])
{
	/* La struttura dirent vale per un singolo file e non per tutto il contenuto della cartella */
	struct dirent *curDir;
	struct dirent allFiles[1024];
	char *stringhe[1024][255];
	/* Il tipo DIR vale per una singola directory */
	DIR *dd;
	int ris, i, count;
	count = 0;
	
	/* Apre la directory corrente */
	if((dd = opendir(".")) == NULL)
	{
		perror("main:");
		exit(1);
	}
	
	/* La legge */
	while(curDir = readdir(dd))
	{
		/* Memorizza tutti i file presenti */
		if(curDir->d_type == DT_REG)
		{
			allFiles[count] = *curDir;
			count++;
		}
	}
	
	/* Stampa i file in ordine di lettura */
	for(i=0; i<=count; i++)
		printf("%s\n", allFiles[i].d_name);
	/* Salva i nomi in una matrice di stringhe */
	for(i=0; i<=count; i++)
		stringhe[i][0] = allFiles[i].d_name;
	
	/* Li ordina */
	qsort(stringhe[1], count, sizeof(char *), compare);
	
	/* E li ristampa */
	for(i=0; i<=count; i++)
		printf("%s\n", allFiles[i].d_name);
	
	if((ris = closedir(dd)) == -1)
	{
		perror("main:");
		exit(1);
	}
	
	return 0;
}
