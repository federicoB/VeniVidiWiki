/************************************************************************/
/* Autore 	: Vincenzo Ferrari 					*/
/* Data 	: 27/08/2010 						*/
/* Licenza	: Creative Commons BY - NC - SA Ver. 3.0		*/
/* Email	: ferrari@cs.unibo.it || wilk3ert@gmail.com		*/
/* Sito Web	: http://www.wilky.it/					*/
/* Info Licenza	: http://creativecommons.org/licenses/by-nc-sa/3.0/	*/
/************************************************************************/

/* Operation on files
 * Creat | Open | Read | Write | Close */
 
#include <stdio.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <fcntl.h>

void errorHandler()
{
	perror("main");
	exit(1);
}

void main(int argc, char* argv[])
{
	int fd;
	int ris;
	char *buf[5];

	printf("Apertura del file %s in corso... ", argv[1]);
	/* Apertura di un file passato per parametro in modalità read&write */
	fd = open(argv[1], O_RDWR);
	if (fd == -1) 
	{
		printf("\nFile %s non trovato.\n", argv[1]);
		printf("Creo il file %s... ", argv[1]);
		/* Se il file non c'è, creazione dello stesso in read&write per utente e solo read per gruppo e altri */
		fd = creat(argv[1], S_IRUSR | S_IWUSR | S_IRGRP | S_IROTH);
		if (fd == -1) errorHandler();
	}
	printf("fatto.\n");

	printf("Lettura in corso... ");
	/* Lettura di 5 byte dal file */
	ris = read(fd, buf, 6);
	if (ris == -1)
		printf("\nErrore durante la lettura: impossibile leggere il file %s.\n", argv[1]);
	else
	{
		printf("fatto.\n");
		printf("La stringa letta è: '%s'\n", (char *)buf);
	}

	printf("Scrittura in corso... ");
	/* Scrittura di 10 byte (la stringa) nel file */
	ris = write(fd, "ciao ciao\n", 10);
	if (ris == -1) 
		printf("\nErrore durante la scrittura: impossibile scrivere sul file %s.\n", argv[1]);
	else
		printf("fatto.\n");

	printf("Chiusura in corso... ");
	/* Chiusura del file */
	ris = close(fd);
	if (ris == -1) errorHandler();
	printf("fatto.\n");
}
