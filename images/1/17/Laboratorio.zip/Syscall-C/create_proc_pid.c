/************************************************************************/
/* Autore 	: Vincenzo Ferrari 					*/
/* Data 	: 27/08/2010 						*/
/* Licenza	: Creative Commons BY - NC - SA Ver. 3.0		*/
/* Email	: ferrari@cs.unibo.it || wilk3ert@gmail.com		*/
/* Sito Web	: http://www.wilky.it/					*/
/* Info Licenza	: http://creativecommons.org/licenses/by-nc-sa/3.0/	*/
/************************************************************************/

/* 								20/1/2005								*/
/*
Esercizio 2 (“miopid”) (10 punti)
Scrivere un programma “miopid” in linguaggio C che esegua un processo con il pid desiderato.
Il programma deve contenere una istruzione
printf(“PID=%d\n”,getpid());
Il programma
miopid 3333
tramite l'istruzione precedente deve stampare proprio
PID=3333
(hint: per tentativi, attenzione a non creare loop di fork con processi che non terminano).
*/

#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
#include <errno.h>

int main(int argc, char* argv[])
{
	int pidChild;
	int pidArg;
	int pidParent;
	int status;
	
	pidParent = getpid();
	
	/* Trasformazione da stringa a intero del parametro */
	pidArg = atoi(argv[1]);
	
	/* Controllo per i PID minori o uguali all'attuale */
	if(pidArg <= pidParent)
	{
		printf("Spiacente ma il PID richiesto non può essere utilizzato.\n");
		printf("Riprovare con un PID maggiore.\n");
		printf("Uscita.\n");
		exit(EXIT_SUCCESS);
	}
	
	while(1)
	{
		/* vfork() blocca il padre finché il figlio non termina. Utile per sincronizzazione */
		if((pidChild = vfork()) == 0)
		{
			/* Se il PID cercato è l'attuale, stampa ed esce */
			if(getpid() == pidArg) printf("PID = %d\n", getpid());
			_exit(0);
		}
		else if(pidChild < 0) perror("vfork():");
		else
		{
			/* Se è stato trovato il PID, esce */
			if(pidChild >= pidArg) break;
		}
	}
		
	return 0;
}
