/************************************************************************/
/* Autore 	: Vincenzo Ferrari 					*/
/* Data 	: 27/08/2010 						*/
/* Licenza	: Creative Commons BY - NC - SA Ver. 3.0		*/
/* Email	: ferrari@cs.unibo.it || wilk3ert@gmail.com		*/
/* Sito Web	: http://www.wilky.it/					*/
/* Info Licenza	: http://creativecommons.org/licenses/by-nc-sa/3.0/	*/
/************************************************************************/

/* 								19 luglio 2010								*/
/*
Esercizio1 Linguaggio C (obblicatorio) : (20 punti) Scrivere un programma che crei un processo figlio. Il processo genitore e il processo figlio devono essere collegati da due pipe, una per la comunicazione genitore-figlio, una per la comunicazione figlio-genitore. Il processo figlio deve rispedire al genitore ogni messaggio ricevuto dalla pipe di input nell'altra (echo). Il processo genitore deve per 100.000 volte spedire un messaggio di 40 byte al processo figlio e aspettare da questo che il messaggio venga rispedito.
Scopo dell'esercizio è di verificare quanto tempo viene impiegato per il "ping" di 100.000 messaggi su pipe.
*/

/*								AGGIUNTE 								*/
/* - Gestisce i segnali quali SIGINT (CTRL+C) per evitare di attendere troppo tempo caso mai MAXMSG fosse troppe grande */
/*																	*/

#include <stdlib.h>
#include <errno.h>
#include <stdio.h>
#include <unistd.h>
#include <sys/timeb.h>
#include <signal.h>

#define MAXBYTE 40
#define MAXMSG 10000000
#define DEBUG

/* Le pipe hanno due canali: fd[0] per leggere, fd[1] per scrivere */

static struct timeb init, now;
static pid_t pid;

/* Gestore dei segnali */
static void sigHandler(int signo)
{
	if(signo == SIGINT)
	{
		/* Se è il figlio esce subito */
		if(pid == 0) exit(EXIT_SUCCESS);
		
		printf("\nSegnal CTRL+C catturato!\n");
		
		/* Timestamp finale */
		if(ftime(&now) == -1) perror("ftime now :");
		
		printf("In tutto sono stati impiegati %ld secondi.\n", now.time - init.time);
	
		exit(EXIT_SUCCESS);
	}
	return;
}

/* Gestore dell'errore */
static void errHandler(char* err)
{
	perror(err);
	exit(EXIT_FAILURE);
}

int main(int argc, char* argv[])
{
	int fdPtoC[2]; /* file descriptor per la pipe da parent a child */
	int fdCtoP[2]; /* file descriptor per la pipe da child a parent */
	char buf[MAXBYTE];
	int i;
	
	/* Inizializzazione del gestore delle signal */
	if (signal(SIGINT, sigHandler) == SIG_ERR) errHandler("signal :");
	
	/* Timestamp iniziale */
	if(ftime(&init) == -1) perror("ftime init :");
	
	/* Creazione della pipe da parent a child */
	if(pipe(fdPtoC) == -1) perror("pipe PtoC :");
	
	/* Creazione della pipe da child a parent */
	if(pipe(fdCtoP) == -1) perror("pipe CtoP :");
	
	/* Creazione del processo figlio */
	if((pid = fork()) == -1) perror("fork :");
	/* Il padre esegue ... */
	else if(pid > 0)
	{
		/* Chiusura del canale inutilizzato */
		if(close(fdPtoC[0]) == -1) perror("close fdPtoC[0] :");
		
		for(i=0; i<MAXMSG; i++)
		{
			/* Scrittura sul canale */
			if(write(fdPtoC[1], "012345678901234567890123456789012345678\n", MAXBYTE) == -1) perror("write PtoC :");
#ifdef DEBUG
			printf("Il padre ha scritto.\n");
#endif
			/* Lettura della pipe e attesa del figlio */
			if(read(fdCtoP[0], &buf, MAXBYTE) == -1) perror("read CtoP");
#ifdef DEBUG
			printf("Il padre ha letto: %s", buf);
#endif
		}
		/* Chiusura dell'ultimo canale */
		if(close(fdPtoC[1]) == -1) perror("close fdPtoC[1] :");
	}
	/* Il figlio esegue ... */
	else
	{
		/* Chiusura del canale inutilizzato */
		if(close(fdCtoP[0]) == -1) perror("close fdCtoP[0] :");
		
		for(i=0; i<MAXMSG; i++)
		{
			/* Lettura della pipe e attesa del padre */
			if(read(fdPtoC[0], &buf, MAXBYTE) == -1) perror("read CtoP");
#ifdef DEBUG
			printf("Il figlio ha letto: %s", buf);
#endif
			/* Scrittura sul canale */
			if(write(fdCtoP[1], &buf, MAXBYTE) == -1) perror("write CtoP :");
#ifdef DEBUG
			printf("Il figlio ha scritto: %s", buf);
#endif
		}
		/* Chiusura dell'ultimo canale */
		if(close(fdCtoP[1]) == -1) perror("close fdCtoP[1] :");
		exit(EXIT_SUCCESS);
	}
	
	/* Timestamp finale */
	if(ftime(&now) == -1) perror("ftime now :");
		
	printf("In tutto sono stati impiegati %ld secondi.\n", now.time - init.time);
	
	exit(EXIT_SUCCESS);
}
