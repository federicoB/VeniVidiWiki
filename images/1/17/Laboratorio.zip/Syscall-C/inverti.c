/************************************************************************/
/* Autore 	: Vincenzo Ferrari 					*/
/* Data 	: 27/08/2010 						*/
/* Licenza	: Creative Commons BY - NC - SA Ver. 3.0		*/
/* Email	: ferrari@cs.unibo.it || wilk3ert@gmail.com		*/
/* Sito Web	: http://www.wilky.it/					*/
/* Info Licenza	: http://creativecommons.org/licenses/by-nc-sa/3.0/	*/
/************************************************************************/

/* 								23 settembre 2009 								*/
/*
Esercizio1 (obbligatorio): (25 punti) Scrivere un programma che inverta i byte di un file: il primo byte del file in output sia l'ultimo del file in input, il secondo in output sia il penultimo dell'input e cosi' via. Il programma deve operare su file di ogni dimensione usando un buffer di 4K byte.
(usare stat o fstat per leggere la dimensione del file, leggere blocchi da 4k con pread, invertirli localmente e scriverli nella posizione giusta nel nuovo file con pwrite).
Sintassi: inverti file_input file_output.
Se si vuole creare un file con 1MB di dati random per fare una prova usare: dd if=/dev/urandom of=file_input bs=1024 count=1024 applicando inverti due volte al file casuale deve tornare il file dato. 
*/

#include <unistd.h>
#include <sys/stat.h>
#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <fcntl.h>

#define SIZEOFBUF 4096

int main(int argc, char* argv[])
{
	char buf[SIZEOFBUF];
	struct stat file_state;
	int ris;
	int fdin, fdout;
	int i;
	int fileSize;
	int pos;
	char *cw;
	
	pos = 0;
	
	/* Apertura del file passato per parametro argv[1] */
	if((fdin = open(argv[1], O_RDONLY)) == -1)
	{
		perror("main:");
		printf("Attenzione: il file %s non è stato trovato. Uscita.\n", argv[1]);
		exit(1);
	}
	
	/* Apertura del file passato per parametro argv[2] */
	if((fdout = open(argv[2], O_RDWR)) == -1)
	{
		if((fdout = creat(argv[2], S_IRUSR | S_IWUSR | S_IRGRP | S_IROTH)) == -1)
		{
			perror("main:");
			printf("Attenzione: il file %s non è stato trovato.\n", argv[2]);
			printf("Ho provato a creare il file di output ma è occorso un errore. Uscita.\n");
			exit(1);
		}
	}
	
	/* Viene riempita la struttura stat per le informazioni sul file */
	if((ris = stat(argv[1], &file_state)) == -1)
	{
		perror("main:");
		exit(1);
	}
	
	/* Controllo necessario se argv[1] ha una dimensione minore di 4kb */
	if((fileSize = file_state.st_size) <= SIZEOFBUF)
	{
		/* Legge argv[1] e scrive in argv[2] */
		if((ris = read(fdin, &buf, file_state.st_size)) == -1) perror("main:");
		for(i=1;i<file_state.st_size;i++)
			if((ris = write(fdout, &buf[file_state.st_size - i], 1)) == -1) perror("main:");
	}
	else
	{
		/* Legge e scrive con blocchi di 4k */
		while(fileSize >= SIZEOFBUF)
		{
			fileSize -= SIZEOFBUF;
			if((ris = pread(fdin, &buf, SIZEOFBUF, fileSize)) == -1) perror("main:");
			for(i=1; i<=SIZEOFBUF; i++ , pos++)
			{
				if((ris = pwrite(fdout, &buf[SIZEOFBUF - i], 1, pos)) == -1) perror("main:");
			}
		}
		
		/* Se ci manca ancora qualcosa da leggere, lo legge e lo scrive */
		if(fileSize > 0)
		{
			if((ris = pread(fdin, &buf, fileSize, 0)) == -1) perror("main:");
			for(i=1; i<=fileSize; i++, pos++)
			{
				if((ris = pwrite(fdout, &buf[fileSize - i], 1, pos)) == -1) perror("main:");
			}
		}
	}
	
	
	/* Chiusura dei file descriptor */
	if((ris = close(fdin)) == -1) perror("main:");
	if((ris = close(fdout)) == -1) perror("main:");
	
	printf("\npos = %d - fileSize = %d\n", pos, fileSize);
	
	return 0;
}
