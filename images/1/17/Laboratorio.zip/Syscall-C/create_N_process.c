/************************************************************************/
/* Autore 	: Vincenzo Ferrari 					*/
/* Data 	: 27/08/2010 						*/
/* Licenza	: Creative Commons BY - NC - SA Ver. 3.0		*/
/* Email	: ferrari@cs.unibo.it || wilk3ert@gmail.com		*/
/* Sito Web	: http://www.wilky.it/					*/
/* Info Licenza	: http://creativecommons.org/licenses/by-nc-sa/3.0/	*/
/************************************************************************/

/* Esercizio di pratica per creare più processi alla volta */

#include <stdio.h>
#include <unistd.h>
#include <errno.h>
#include <sys/types.h>
#include <signal.h>
#include <stdlib.h>

#define MAXPROC 5

/* Gestore dei segnali */
static void sigHandler(int signo)
{
	/* SIGUSR1 è un segnale definito dall'utente: serve per svegliare il genitore in questo caso */
	if(signo == SIGUSR1) return;
	
	/* SIGCHLD è un segnale inviato dal figlio al padre quando termina */
	if(signo == SIGCHLD) return;
	
	return;
}

int main(int argc, char* argv[])
{
	pid_t pidParent;
	pid_t pidChild[MAXPROC];
	pid_t pid;
	int i;
	
	pidParent = getpid();
	
	/* Inizializzazione del gestore delle signal */
	if (signal(SIGCHLD, sigHandler) == SIG_ERR) perror("signal :");
	if (signal(SIGUSR1, sigHandler) == SIG_ERR) perror("signal :");
	
	/* Con questo ciclo vengono creati N processi */
	for(i=0; i<MAXPROC; i++)
	{
		/* I figli entrano qui */
		if((pid = fork()) == 0)
		{
			printf("Il %d° processo figlio con pid %d è stato creato.\n", i, getpid());
			/* Il figlio appena creato risveglia il padre e si mette in attesa */
			kill(pidParent, SIGUSR1);
			pause();
			printf("Il %d° processo figlio con pid %d sta terminando.\n", i, getpid());
			exit(EXIT_SUCCESS);
		}
		else if(pid < 0) perror("fork():");
		else
		{
			/* Il padre riempie il vettore di pid dei figli e si mette in attesa perché vengano creati uno dopo l'altro */
			pidChild[i] = pid;
			printf("Il padre si mette in attesa che il %d° figlio con pid %d si metta a sua volta in attesa.\n", i, pidChild[i]);
			pause();
		}
	}
	
	/* Con questo ciclo vengono uccisi tutti i figli, uno dopo l'altro */
	for(i=0;i<5;i++)
	{
		printf("Risveglio il figlio #%d.\n", i);
		/* Il padre risveglia i figli e poi si mette in attesa per farli andare in ordine */
		kill(pidChild[i], SIGUSR1);
		/* Si risveglierà con la SIGCHLD */
		pause();
	}

	printf("Il genitore ha terminato dopo l'ultimo figlio.\n");
	
	exit(EXIT_SUCCESS);
}
