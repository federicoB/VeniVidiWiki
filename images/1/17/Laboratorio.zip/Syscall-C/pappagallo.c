/************************************************************************/
/* Autore 	: Vincenzo Ferrari 					*/
/* Data 	: 27/08/2010 						*/
/* Licenza	: Creative Commons BY - NC - SA Ver. 3.0		*/
/* Email	: ferrari@cs.unibo.it || wilk3ert@gmail.com		*/
/* Sito Web	: http://www.wilky.it/					*/
/* Info Licenza	: http://creativecommons.org/licenses/by-nc-sa/3.0/	*/
/************************************************************************/

/* Programma che copia lo standard input sullo standard output */

#include <unistd.h>

#define SIZE 20

void main(void)
{
	char buf[SIZE];
	int ris, ris2;

	while (ris != -1)
	{
		if ((ris = read(STDIN_FILENO, buf, SIZE)) == -1)
			perror("main");
		if ((ris = write(STDOUT_FILENO, buf, ris)) == -1)
			perror("main");
	}
}
