/************************************************************************/
/* Autore 	: Vincenzo Ferrari 					*/
/* Data 	: 27/08/2010 						*/
/* Licenza	: Creative Commons BY - NC - SA Ver. 3.0		*/
/* Email	: ferrari@cs.unibo.it || wilk3ert@gmail.com		*/
/* Sito Web	: http://www.wilky.it/					*/
/* Info Licenza	: http://creativecommons.org/licenses/by-nc-sa/3.0/	*/
/************************************************************************/

/* Programma che tramite le syscall inotify_init e inotify_add_watch, avverta quando il file preso in input viene aperto e modificato */
/* e notifiche le azioni rispettivamente con "il file è stato aperto" e "il file è stato modificato". */
/* Il programma termina quando il file viene cancellato. */

/* Usare "CAT" per aprie e modificare il file. */
/* Ad esempio: */
/* - cat prova */
/* - cat > prova */

#include <sys/inotify.h>
#include <stdlib.h>
#include <stdio.h>
#include <errno.h>

#define SIZE sizeof(struct inotify_event)

/* Gestore degli errori */
void errHandler(char* err)
{
	perror(err);
	exit(1);
}

void terminate(int fd)
{
	int ris;
	
	if((ris = close(fd)) == -1) errHandler("close(): ");
	exit(1);
}

int main(int argc, char* argv[])
{
	int ris;
	int fd;
	uint32_t wd;
	
	/* Con la inotify_init si ha a disposizione un file descriptor */
	if((fd = inotify_init()) == -1) errHandler("inotify_init(): ");
	/* Con la inotify_add_watch è possibile associare al fd avuto sopra con un file passato per parametro ad esempio, tenendo conto dei vari
	   eventi, come IN_OPEN o IN_MODIFY o _IN_DELETE_SELF.
	   E' possibile comunque specificare IN_ALL_EVENTS per gestire ogni tipo di evento. */
	if((wd = inotify_add_watch(fd, argv[1], IN_OPEN | IN_MODIFY | IN_DELETE_SELF)) == -1) errHandler("inotify_add_watch(): ");
	
	while(1)
	{
		struct inotify_event event;
		
		/* La read crea una struttura inotify_event, settando i vari campi.
		   In particolare il campo mask (una maschera di bit) che permette di gestire i vari eventi */
		if((ris = read(fd, &event, SIZE)) < SIZE) errHandler("read(): ");
		
		/* Se il file è stato aperto */
		if(event.mask & IN_OPEN)
			printf("il file è stato aperto\n");
		/* Se il file è stato modificato */
		else if(event.mask & IN_MODIFY)
			printf("il file è stato modificato\n");
		/* Se il file è stato cancellato */
		else if(event.mask & IN_DELETE_SELF) 
		{
			printf("il file è stato cancellato\n");
			terminate(fd);
		}
	}

	return 0;
}
