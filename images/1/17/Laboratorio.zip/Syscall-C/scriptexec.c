/************************************************************************/
/* Autore 	: Vincenzo Ferrari 					*/
/* Data 	: 27/08/2010 						*/
/* Licenza	: Creative Commons BY - NC - SA Ver. 3.0		*/
/* Email	: ferrari@cs.unibo.it || wilk3ert@gmail.com		*/
/* Sito Web	: http://www.wilky.it/					*/
/* Info Licenza	: http://creativecommons.org/licenses/by-nc-sa/3.0/	*/
/************************************************************************/

/* 								23 giugno 2009								*/
/*
Esercizio1 (obbligatorio): (15 punti) Scrivere un programma in linguaggio C denominato “scriptexec” che venga
richiamato con un solo parametro: il nome di un file che contiene un elenco di comandi con i rispettivi parametri, uno per riga.
Le righe che iniziano per '#' sono commenti.
Il programma esegue uno dopo l'altro i comandi presenti nel file.
(E' vietato l'uso di chiamate quali system o popen).
*/

/* ATTENZIONE I PARAMETRI DEL COMANDO NON SONO GESTITI */

#include <unistd.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <errno.h>
#include <sys/wait.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>

int main(int argc, char* argv[])
{
	int fd;
	int ris, i;
	char buf;
	char *cmd;
	pid_t pid;
	int countDim;
	int offset;
	
	i = 0;
	
	/* Conta l'offset per pread */
	offset = 0;
	
	/* Apertura del file */
	if((fd = open(argv[1], O_RDONLY)) == -1) perror("main:");
	
	/* Ciclo infinito finché non si arriva a EOF */
	while(1)
	{
		/* Conta la lunghezza del comando letto da file */
		countDim = 0;

		/* Legge un byte alla volta: se arriva a EOF, termina */
		if((ris = read(fd, &buf, 1)) == 0) break;

		countDim++;
		offset++;
		
		/* Se trova una stringa di commento la legge (scarta) fino alla fine */
		if(strncmp(&buf, "#", 1) == 0)
			while(strncmp(&buf, "\n", 1) != 0)
			{
				read(fd, &buf, 1);
				offset++;
			}
		else
		{
			/* Altrimenti legge l'intera stringa, ossia il comando */
			while(strncmp(&buf, "\n", 1) != 0)
				if((ris = read(fd, &buf, 1)) == -1) 
				{
					perror("read:");
					exit(0);
				}
				else
				{
					offset++;
					countDim++;
				}
			
			/* Non conoscendo la dimensione di ogni comando, allochiamo la dimensione appena letta */
			cmd = (char *)malloc(sizeof(char)*countDim-1);
			
			/* Dopodiché rileggiamo la stringa e la carichiamo direttamente nell'area appena allocata */
			if((ris = pread(fd, cmd, countDim-1, offset - countDim)) == -1)
			{
				perror("pread:");
				exit(0);
			}
			
			/* Crea un processo figlio che eseguirà il comando */
			if((pid = fork()) == -1) perror("fork:");
			
			/* Se è il figlio esegue il comando e poi termina */
			if(pid == 0)
			{
				/* Il figlio lancia il comando */
				if(execlp(cmd, cmd, (char *) 0) == -1) perror("execlp:");
				exit(0);
			}
			
			/* Il genitore aspetta la terminazione del figlio */	
			if((pid = waitpid(pid, NULL, 0)) != pid) perror("waitpid:");
			
			/* Libera l'area allocata */
			free(cmd);
		}
	}
	
	exit(0);
}
