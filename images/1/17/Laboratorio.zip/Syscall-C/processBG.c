/************************************************************************/
/* Autore 	: Vincenzo Ferrari 					*/
/* Data 	: 27/08/2010 						*/
/* Licenza	: Creative Commons BY - NC - SA Ver. 3.0		*/
/* Email	: ferrari@cs.unibo.it || wilk3ert@gmail.com		*/
/* Sito Web	: http://www.wilky.it/					*/
/* Info Licenza	: http://creativecommons.org/licenses/by-nc-sa/3.0/	*/
/************************************************************************/

/* Scrivere un programma che metta in background 
 * un programma passato come parametro */

#include <unistd.h>

void main(int argc, char *argv[])
{
	if(!vfork()) execvp(argv[1], &argv[1]);
}
