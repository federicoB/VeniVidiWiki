/************************************************************************/
/* Autore 	: Vincenzo Ferrari 					*/
/* Data 	: 27/08/2010 						*/
/* Licenza	: Creative Commons BY - NC - SA Ver. 3.0		*/
/* Email	: ferrari@cs.unibo.it || wilk3ert@gmail.com		*/
/* Sito Web	: http://www.wilky.it/					*/
/* Info Licenza	: http://creativecommons.org/licenses/by-nc-sa/3.0/	*/
/************************************************************************/

/* 								23 giugno 2009								*/
/*
Esercizio2 (10 punti): Scrivere un programma (linguaggio C) che incrementi un contatore ogni secondo. Quando riceve
un segnale SIGUSR1 il programma deve stampare il valore attuale del contatore.
*/

#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <errno.h>
#include <signal.h>

#define TOTSEC 5

int counter;
pid_t pidChild, pidParent;

/* Gestore dei segnali */
void sigHandler(int signo)
{
	/* Ogni volta che viene catturato il segnale SIGUSR1, il padre stampa il contatore */
	if(signo == SIGUSR1)
	{
		if(getpid() == pidParent)
			printf("Catturato segnale SIGUSR1. Il contatore è %d.\n", counter);
	}
	
	/* Quando si interrompe con l'interrupt CTRL+C, viene ucciso il figlio dal genitore */
	if(signo == SIGINT)
	{
		printf("\nCTRL + C catturato. Uccido il figlio.\n");
		if(kill(pidChild, SIGKILL) == -1) perror("kill():");
		exit(EXIT_SUCCESS);
	}
	
	return;
}

int main(int argc, char* argv[])
{
	/* Inizializzazione delle variabili */
	counter = 0;
	pidParent = getpid();
	
	/* Inizializzazione dei segnali */
	if(signal(SIGUSR1, sigHandler) == SIG_ERR) perror("signal():");
	if(signal(SIGINT, sigHandler) == SIG_ERR) perror("signal():");
	
	/* Creazione del processo figlio */
	if((pidChild = fork()) == 0)
	{
		/* Il figlio ogni TOTSEC secondi invierà un segnale SIGUSR1 al padre */
		while(1)
		{
			sleep(TOTSEC);
			if(kill(pidParent, SIGUSR1) == -1) perror("kill():");
		}
		
		exit(EXIT_SUCCESS);
	}
	else if(pidChild < 0) perror("fork():");
	else
	{
		/* Il padre ogni secondo incrementerà di 1 il contatore */
		while(1)
		{
			counter++;
			sleep(1);
		}
	}
	
	return(0);
}
