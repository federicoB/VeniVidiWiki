/************************************************************************/
/* Autore 	: Vincenzo Ferrari 					*/
/* Data 	: 27/08/2010 						*/
/* Licenza	: Creative Commons BY - NC - SA Ver. 3.0		*/
/* Email	: ferrari@cs.unibo.it || wilk3ert@gmail.com		*/
/* Sito Web	: http://www.wilky.it/					*/
/* Info Licenza	: http://creativecommons.org/licenses/by-nc-sa/3.0/	*/
/************************************************************************/

/* Copia il contenuto del file argv[1] in argv[2]  */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/stat.h>
#include <fcntl.h>

void errorHandler()
{
	perror("main");
	exit(1);
}

void main(int argc, char *argv[])
{
	int fd1, fd2;
	int ris;
	char *rd[1];

	/* Apertura del file sorgente */
	fd1 = open(argv[1], O_RDWR);

	/* Apertura del file destinatario */
	if (fd1 == -1) errorHandler();
	fd2 = open(argv[2], O_RDWR);
	/* Se non esiste, viene creato */
	if (fd2 == -1)
	{
		fd2 = creat(argv[2], S_IRUSR | S_IWUSR | S_IRGRP | S_IROTH);
		if (fd2 == -1) errorHandler();
	}

	/* Lettura e scrittura di un byte alla volta dal file sorgente al destinatario */
	while((read(fd1, rd, 1)) != 0)
	{
		ris = write(fd2, rd, 1);
		if (ris == -1) perror("main");
	}

	/* Chiusura dei file */
	ris = close(fd1);
	if (ris == -1) errorHandler();
	ris = close(fd2);
	if (ris == -1) errorHandler();
}
