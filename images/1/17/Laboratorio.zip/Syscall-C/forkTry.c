/************************************************************************/
/* Autore 	: Vincenzo Ferrari 					*/
/* Data 	: 27/08/2010 						*/
/* Licenza	: Creative Commons BY - NC - SA Ver. 3.0		*/
/* Email	: ferrari@cs.unibo.it || wilk3ert@gmail.com		*/
/* Sito Web	: http://www.wilky.it/					*/
/* Info Licenza	: http://creativecommons.org/licenses/by-nc-sa/3.0/	*/
/************************************************************************/

/* Test per provare la fork e la waitpid */

#include <stdio.h>
#include <sys/wait.h>
#include <unistd.h>
#include <stdlib.h>

int main(int argc, char* argv[])
{
	pid_t pidChild;
	pid_t pidParent;
	
	pidParent = getpid();
	
	/* Genera un processo figlio */
	pidChild = fork();
	
	/* Il figlio ha immediatamente pidChild = 0 */
	if(pidChild == 0)
	{
		printf("Sono il figlio e il mio pid è %d\n", pidChild);
		printf("Ora aspetto 2 secondi\n");
		sleep(2);
		
		/* Se qui non termina, terminerà dopo con pid diverso dal padre */
		/*exit(0);*/
	}
	/* Altrimenti è il genitore */
	else printf("Sono il padre e il mio pid è %d\n", pidParent);
	
	if(getpid() != pidParent)
	{
		printf("Sono il figlio con pid %d\n", getpid());
		exit(0);
	}
	
	/* Il padre aspetta il figlio con la waitpid */
	if(waitpid(pidChild, NULL, 0) != pidChild) printf("errore\n");
	
	printf("Ciao, il mio pid è %d\n", getpid());
	
	exit(0);
}
