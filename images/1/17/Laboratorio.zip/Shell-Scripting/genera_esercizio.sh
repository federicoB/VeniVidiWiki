#!/bin/sh

#########################################################################
# Autore 	: Vincenzo Ferrari 					#
# Data 		: 27/08/2010 						#
# Licenza	: Creative Commons BY - NC - SA Ver. 3.0		#
# Email		: ferrari@cs.unibo.it || wilk3ert@gmail.com		#
# Sito Web	: http://www.wilky.it/					#
# Info Licenza	: http://creativecommons.org/licenses/by-nc-sa/3.0/	#
#########################################################################


# Script che genera un template per un esercizio d'esame sulle syscall.
# Il nome del file è passato per parametro

touch $1
cat > $1 << ENDOFTEMPLATE
/*

*/

#include <stdlib.h>
#include <errno.h>

void errHanlder(char* err)
{
	perror(err);
	exit(1);
}

int main(int argc, char* argv[])
{
	int i, ris;
	
	return 0;
}
ENDOFTEMPLATE
