#!/bin/sh

#########################################################################
# Autore 	: Vincenzo Ferrari 					#
# Data 		: 27/08/2010 						#
# Licenza	: Creative Commons BY - NC - SA Ver. 3.0		#
# Email		: ferrari@cs.unibo.it || wilk3ert@gmail.com		#
# Sito Web	: http://www.wilky.it/					#
# Info Licenza	: http://creativecommons.org/licenses/by-nc-sa/3.0/	#
#########################################################################

# Scrivere uno script che prende in input da linea di comando il nome di due directory ed elimina (da entrambe le
# directory) tutti i file che hanno lo stesso nome e lo stesso contenuto.

for file1 in $(find $1 -type 'f')
do
	for file2 in $(find $2 -type 'f')
	do
		if [ $file1 == $file2 ] && [ `md5sum $file1` == `md5fum $file2` ]
	done
done
