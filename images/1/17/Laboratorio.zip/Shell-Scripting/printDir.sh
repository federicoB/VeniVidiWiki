#!/bin/sh

#########################################################################
# Autore 	: Vincenzo Ferrari 					#
# Data 		: 27/08/2010 						#
# Licenza	: Creative Commons BY - NC - SA Ver. 3.0		#
# Email		: ferrari@cs.unibo.it || wilk3ert@gmail.com		#
# Sito Web	: http://www.wilky.it/					#
# Info Licenza	: http://creativecommons.org/licenses/by-nc-sa/3.0/	#
#########################################################################


# 03 febbraio 2010
# Scrivere in bash un programma che stampi quanti file, quanti link simbolici, file speciali, quante
# directory sono presenti nella directory corrente.

countD=-1
countFR=0
countLS=0
countFS=0

# $(find . -type f) è l'equivalente di `find . -type f`. Entrambi sono command substitution
for file in $(find . -type f) # La variabile file scandisce ogni singolo file regolare (f)
do
	countFR=`expr $countFR + 1` # Metodo per incrementare una dannata variabile
done
for file in $(find . -type d)
do
	countD=`expr $countD + 1`
done
for file in $(find . -type l)
do
	countLS=`expr $countLS + 1`
done
for file in $(find . -type p) $(find . -type s)
do
	countFS=`expr $countFS + 1`
done
echo "Nella cartella corrente sono presenti: "
echo "- $countD directory"
echo "- $countFR file regolari"
echo "- $countFS file speciali"
echo "- $countLS link simbolici"
