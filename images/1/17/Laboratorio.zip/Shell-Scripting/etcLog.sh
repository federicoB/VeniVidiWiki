#!/bin/sh

#########################################################################
# Autore 	: Vincenzo Ferrari 					#
# Data 		: 27/08/2010 						#
# Licenza	: Creative Commons BY - NC - SA Ver. 3.0		#
# Email		: ferrari@cs.unibo.it || wilk3ert@gmail.com		#
# Sito Web	: http://www.wilky.it/					#
# Info Licenza	: http://creativecommons.org/licenses/by-nc-sa/3.0/	#
#########################################################################


# 10/2/2005

# Esercizio 3 - Etc log (4 punti)
# Si crei un file di log degli accessi ai file presenti in /etc avvenuti nelle ultime 24 ore. Le informazioni devono
# comprendere: il nome del file, il nome del proprietario, l'ora di accesso. Si dovrà anche contrassegnare quel/quei file che
# hanno subito delle modifiche.

dirBase=`pwd`

rm etc.log 2> /dev/null
touch etc.log
cd /etc/
# find
# -type f : cerca solo i file regolari
# -atime -1 : implica nella ricerca i file ACCEDUTI entro 24h (-1 = 1*24h)
# -maxdepth 1 : circoscrive la ricerca alla cartella passata (in questo caso ".")
# 2> /dev/null : lo stderr è redirezionato a NULL
for file in `find . -type f -atime -1 -maxdepth 1 2> /dev/null`
do
	# echo -n : elimina lo "\n" e scrive tutto su una riga
	# Viene scritto il file etc.log
	# basename : elenca solo il nome del file, senza il suo path
	echo -n "`basename $file` " >> $dirBase/etc.log
	# stat -c %U : username del proprietario del file
	echo -n "`stat -c %U $file` " >> $dirBase/etc.log
	# stat -c %x : ora di accesso, presa eliminando anche i vari secondi con awk
	echo -n `stat -c %x $file | awk -F. '{print $1}' | awk '{print $2}'` >> $dirBase/etc.log
	# find -mtime -1 : implica nella ricerca i file MODIFICATI entro 24h
	# -z : se la stringa è nulla
	if [ -z `find $file -maxdepth 1 -mtime -1 -type f` ]; then
		echo >> $dirBase/etc.log
	else
		echo " Modified" >> $dirBase/etc.log
	fi
done
