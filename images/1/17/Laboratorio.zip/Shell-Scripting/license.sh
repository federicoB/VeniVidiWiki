#!/bin/sh

#########################################################################
# Autore 	: Vincenzo Ferrari 					#
# Data 		: 27/08/2010 						#
# Licenza	: Creative Commons BY - NC - SA Ver. 3.0		#
# Email		: ferrari@cs.unibo.it || wilk3ert@gmail.com		#
# Sito Web	: http://www.wilky.it/					#
# Info Licenza	: http://creativecommons.org/licenses/by-nc-sa/3.0/	#
#########################################################################


for file in `find . -type f`
do
	tmp=$file.tmp
	touch $tmp
	cat > $tmp << ENDOFLICENSE
##
# Autore 	: Vincenzo Ferrari 					#
# Data 		: 17/09/2010 						#
# Licenza	: Creative Commons BY - NC - SA Ver. 3.0		#
# Sito Web	: http://www.wilky.it/					#
# Info Licenza	: http://creativecommons.org/licenses/by-nc-sa/3.0/	#
##
ENDOFLICENSE
	cat $file >> $tmp
	cat $tmp > $file
	rm $tmp
done
