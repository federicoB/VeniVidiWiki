#!/bin/sh

#########################################################################
# Autore 	: Vincenzo Ferrari 					#
# Data 		: 27/08/2010 						#
# Licenza	: Creative Commons BY - NC - SA Ver. 3.0		#
# Email		: ferrari@cs.unibo.it || wilk3ert@gmail.com		#
# Sito Web	: http://www.wilky.it/					#
# Info Licenza	: http://creativecommons.org/licenses/by-nc-sa/3.0/	#
#########################################################################


# Generare un file grande 100MB

# if è il file in input, in questo caso il device zero contenente byte di zero
# of è il file di output
# bs è il numero di bytes (100M = 100MB)
# count è il numero dei blocchi da copiare
dd if=/dev/zero of=bigfile bs=100M count=1
