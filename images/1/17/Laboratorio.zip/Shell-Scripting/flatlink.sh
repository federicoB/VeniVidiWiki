#!/bin/sh

#########################################################################
# Autore 	: Vincenzo Ferrari 					#
# Data 		: 27/08/2010 						#
# Licenza	: Creative Commons BY - NC - SA Ver. 3.0		#
# Email		: ferrari@cs.unibo.it || wilk3ert@gmail.com		#
# Sito Web	: http://www.wilky.it/					#
# Info Licenza	: http://creativecommons.org/licenses/by-nc-sa/3.0/	#
#########################################################################


# 15 gennaio 2009

# Esercizio 3 Script: (10 punti)
# scrivere uno script bash flatlink con due parametri:
# flatlink a b
# dove a e' una directory e b e' una directory vuota.
# Al termine dell'esecuzione la directory b deve contenere un link ad ogni file (non alle directory) contenuti in tutto il
# sottoalbero con radice in a.
# b e' flat: non contiene sottodirectory, al contrario a puo' contenere sottodirectory.
# Es:
# se a contiene a1 a2 a3 a4 a5, a1 a2 sono dir e gli altri file
# a1 contiene a11 a12 a13, dove solo a11 e' una dir
# a11 contiene a111
# a2 contiene a21 e a22
# b al termine deve contenere a3 a4 a5 a12 a13 a111 a21 a22 link ai file omonimi in a.

a=0

for file in $( ls -R $1 | egrep -v 'd' )
do
	# Soluzione stupida. Elimina la prima riga di 'egrep'
	a=`expr $a + 1`
	if [ ! $a -eq 1 ]
	then
		ln -s -t $2 $file
	fi
done
