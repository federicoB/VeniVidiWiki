#!/bin/sh

#########################################################################
# Autore 	: Vincenzo Ferrari 					#
# Data 		: 27/08/2010 						#
# Licenza	: Creative Commons BY - NC - SA Ver. 3.0		#
# Email		: ferrari@cs.unibo.it || wilk3ert@gmail.com		#
# Sito Web	: http://www.wilky.it/					#
# Info Licenza	: http://creativecommons.org/licenses/by-nc-sa/3.0/	#
#########################################################################


#Programma che fa CD su una directory passata per parametro

if [ -n "$1" ] # Se è stato inserito un parametro
then
	cd $1
	if [ `pwd` != "$1" ] # Se il risultato di pwd è diverso dal parametro
	then
		echo "Somethings wrong!"
	else # Altrimenti notifico
		echo "CD avvenuta ;)"
	fi
else # Altrimenti se non è stato passato nulla
	echo "Attenzione: devi specificare la directory su cui fare CD!"
fi
