#!/bin/sh

#########################################################################
# Autore 	: Vincenzo Ferrari 					#
# Data 		: 27/08/2010 						#
# Licenza	: Creative Commons BY - NC - SA Ver. 3.0		#
# Email		: ferrari@cs.unibo.it || wilk3ert@gmail.com		#
# Sito Web	: http://www.wilky.it/					#
# Info Licenza	: http://creativecommons.org/licenses/by-nc-sa/3.0/	#
#########################################################################


# 19 Luglio 2010

# Esercizio 3 Script: (10 punti): Lo script deve prendere in input un file e invertire le righe pari con quelle dispari.
# Se l'input è:
#	hello
#	world
#	goodbye
#	moon
# l'output deve essere:
#	world
#	hello
#	goodbye
#	moon

# NON FUNZIONA

count=1

rm output
touch output
rm tmp
touch tmp

for ROWS in $(cat $1)
do
	if [ `expr $count % 2` -eq 0 ]
	# Se è una riga pari salva l'attuale per poi scriverla successivamente
	then
		echo "$ROWS è pari"
		"$ROWS" >> tmp
		tac tmp >> output
	# Altrimenti scrive prima la precedente e poi l'attuale
	else
		echo "$ROWS è dispari"
		"$ROWS" > tmp
	fi
	
	count=`expr $count + 1`
done
