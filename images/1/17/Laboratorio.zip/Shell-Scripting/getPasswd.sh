#!/bin/sh

#########################################################################
# Autore 	: Vincenzo Ferrari 					#
# Data 		: 27/08/2010 						#
# Licenza	: Creative Commons BY - NC - SA Ver. 3.0		#
# Email		: ferrari@cs.unibo.it || wilk3ert@gmail.com		#
# Sito Web	: http://www.wilky.it/					#
# Info Licenza	: http://creativecommons.org/licenses/by-nc-sa/3.0/	#
#########################################################################


# Programma che prende in input la password dell'utente senza mostrare l'echo

oldmode=`stty -g`

echo "Inserire il nickname del nuovo utente :"
read user
echo "Inserire la password dell'utente $user :"
stty -echo # Disattiva echo da terminale
read password
stty $oldmode # Riattivazione del vecchio mode
echo "L'utente $user ha inserito la password $password"
