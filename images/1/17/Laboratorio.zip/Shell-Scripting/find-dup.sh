#!/bin/sh

#########################################################################
# Autore 	: Vincenzo Ferrari 					#
# Data 		: 27/08/2010 						#
# Licenza	: Creative Commons BY - NC - SA Ver. 3.0		#
# Email		: ferrari@cs.unibo.it || wilk3ert@gmail.com		#
# Sito Web	: http://www.wilky.it/					#
# Info Licenza	: http://creativecommons.org/licenses/by-nc-sa/3.0/	#
#########################################################################


# 25/7/2005

# Esercizio 3 - File duplicati (6 punti)
# Scrivere uno script che prenda in input da riga di comando un insieme di directory e trovi tutti i file nelle directory
# specificate (in modo ricorsivo) che hanno lo stesso contenuto (ma non necessariamente lo stesso filename).
# Suggerimento: utilizzare i comandi find, md5sum, sort, uniq. L'output deve contenere solo i file duplicati, con i pathname
# di tutte le repliche.
# Esempio di ouput:
# aa45341430391cbcb7969935926b9257 ./include/linux.h
# aa45341430391cbcb7969935926b9257 ./modulo1/include/linux.h
# d2547d041aaafbfb00b3d0a9c5536506 ./include/stats.h
# d2547d041aaafbfb00b3d0a9c5536506 ./modulo2/codice.h

# Scansione tutti gli argomenti passati per parametro
# $@ è la stringa di argomenti, utile proprio per i cicli for
for arg in $@
do
	# Se l'argomento passato è una cartella
	if [ -d $arg ]; then
		# Allora ripetiamo la solfa per tutte quante le cartelle passate
		for subarg in $@
		do
			# Cerchiamo i doppioni e li stampiamo a video
			find $subarg -type f -exec md5sum {} \; 2> /dev/null | sort | uniq -w 32 -d --all-repeated=separate
		done
	fi
done

# -exec md5sum {} \; esegue l'md5 sul file selezionato
# 2> /dev/null redireziona lo stderr a fancu
# sort li ordina
# uniq stampa soltanto le righe che fanno match i primi 32 caratteri (l'md5 è di 32 caratteri), -d stampa solo le linee duplicate, --all-repeated=separate separa le linee duplicate con uno spazio
