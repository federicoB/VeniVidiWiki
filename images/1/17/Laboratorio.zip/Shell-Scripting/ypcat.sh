#!/bin/sh

#########################################################################
# Autore 	: Vincenzo Ferrari 					#
# Data 		: 27/08/2010 						#
# Licenza	: Creative Commons BY - NC - SA Ver. 3.0		#
# Email		: ferrari@cs.unibo.it || wilk3ert@gmail.com		#
# Sito Web	: http://www.wilky.it/					#
# Info Licenza	: http://creativecommons.org/licenses/by-nc-sa/3.0/	#
#########################################################################

# 23 settembre 2009
# Esercizio 3 Script: (10 punti): ypcat group fornisce il file dei gruppi, ypcat passwd e' il file degli utenti.
# Fare uno script bash che elenchi quali sono gli utenti nominati nel file group che in realta' non esistono piu' (cioe' non
# appartengono al file passwd). Una prova effettuata il 22 settembre alle 23:54 ne conta 28.

count=0

# awk -F : "L'opzione -F e i : indica che il separatore tra i vari campi non è lo spazio ma i due punti"
for userGroup in `cat /etc/group | awk -F : '{print $1}'`
do
	for userPass in `cat /etc/passwd | awk -F : '{print $1}'`
	do
		if [ $userGroup = $userPass ]; then
			count=`expr $count + 1`
		fi
	done
	if [ $count -eq 0 ]; then
		echo $userGroup
	fi
	count=0
done
