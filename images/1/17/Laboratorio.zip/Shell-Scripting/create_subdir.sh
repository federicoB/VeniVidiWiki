#!/bin/sh

#########################################################################
# Autore 	: Vincenzo Ferrari 					#
# Data 		: 27/08/2010 						#
# Licenza	: Creative Commons BY - NC - SA Ver. 3.0		#
# Email		: ferrari@cs.unibo.it || wilk3ert@gmail.com		#
# Sito Web	: http://www.wilky.it/					#
# Info Licenza	: http://creativecommons.org/licenses/by-nc-sa/3.0/	#
#########################################################################


# Per ogni singola estensione, creare una sottodirectory con tale nome e con tanti link simbolici quanti sono i file di tale estensione
# e.g. se esistono i file "a.pdf" "b.pdf" "a.jpg" "b.jpg" "a.txt" "b.txt", allora il programma deve creare
# una cartella "pdf" contenente due link simbolici chiamati "a.pdf" e "b.pdf" e ripetere la stessa cosa per gli altri file

# Scandisce ogni singolo file
# Usa "ls" perché restituisce l'esatto nome del file
for file in $(ls)
do
	# Se il file letto è un file regolare allora...
	if [ -f "$file" ]
	then
		# Si salva l'estensione in "dirExt"
		# Il comando "cut" taglia la parte voluta dopo un certo delimitatore
		# In questo caso taglia l'estensione perché è il secondo argomento (-f2) dopo il separatore "." (-d)
		dirExt=`echo "$file" | cut -d'.' -f2`
		# Se la directory col nome dell'estensione del file non esiste, la crea
		if [ ! -d "$dirExt" ]
		then
			mkdir "$dirExt"
		fi
		# Crea un file con nome identico
		touch "$dirExt/$file"
		# E lo linka, redirezionando lo stdout e stderr in null
		ln --symbolic "$file" "$dirExt/$file" > /dev/null
	fi
done
