# Scrivere uno script “ls.” che faccia il listato dei file di una directory suddivisi per suffisso (in ordine alfabetico di

#########################################################################
# Autore 	: Vincenzo Ferrari 					#
# Data 		: 27/08/2010 						#
# Licenza	: Creative Commons BY - NC - SA Ver. 3.0		#
# Email		: ferrari@cs.unibo.it || wilk3ert@gmail.com		#
# Sito Web	: http://www.wilky.it/					#
# Info Licenza	: http://creativecommons.org/licenses/by-nc-sa/3.0/	#
#########################################################################

# suffisso, e fra i file con lo stesso suffisso in ordine alfabetico).

ls -X | egrep -v '^d'
