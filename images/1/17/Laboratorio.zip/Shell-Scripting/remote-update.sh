#!/bin/sh

#########################################################################
# Autore 	: Vincenzo Ferrari 					#
# Data 		: 27/08/2010 						#
# Licenza	: Creative Commons BY - NC - SA Ver. 3.0		#
# Email		: ferrari@cs.unibo.it || wilk3ert@gmail.com		#
# Sito Web	: http://www.wilky.it/					#
# Info Licenza	: http://creativecommons.org/licenses/by-nc-sa/3.0/	#
#########################################################################


# 03 settembre 2009
# Esercizio 3 Script: (10 punti): Occorre scrivere uno script bash che dato un file e la sua precedente versione a.old
# aggiorni il file a su una macchina remota.
# Es: remote-update /tmp/testfile amleto
# Il file di testo /tmp/testfile deve essere presente nella macchina corrente e nella macchina remota (amleto nell'esempio).
# Nella macchina dove viene digitato il comando deve essere presente anche /tmp/testfile.old con contenuto identico a
# /tmp/testfile. Le modifiche fatte a /tmp/testfile devono essere riportate nel file presente nella macchina remota (senza
# copiare il file!). Usate diff, ssh e patch.
# Per provare lo script controllate il nome della macchina libera di fianco alla vostra e usatela per l'esperimento. Mettete il
# file in /tmp altrimenti sarebbe condiviso.

# Il file in remoto ($2) e il file .old ($1.old) devono essere inizialmente uguali
# Altrimenti si dovrebbe creare un file identico ad amleto in locale

diff $1 $1.old | ssh wilk@192.168.1.36 patch -R $2
diff $1 $1.old | patch -R $1.old
