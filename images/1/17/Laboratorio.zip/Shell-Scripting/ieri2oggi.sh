#!/bin/sh

#########################################################################
# Autore 	: Vincenzo Ferrari 					#
# Data 		: 27/08/2010 						#
# Licenza	: Creative Commons BY - NC - SA Ver. 3.0		#
# Email		: ferrari@cs.unibo.it || wilk3ert@gmail.com		#
# Sito Web	: http://www.wilky.it/					#
# Info Licenza	: http://creativecommons.org/licenses/by-nc-sa/3.0/	#
#########################################################################


# 14 luglio 2009

# Esercizio 3 Script: (15 punti): scrivere uno script bash che scandisca tutto un sottoalbero del file system e cambi la data
# di ultimo accesso di tutti i file acceduti oggi ponendola a ieri. (provare il comando “date -d yesterday”, leggere il manuale
# di “touch”).

dataIeri=`date -d yesterday +%F" "%H:%M`
dataOggi=`date +%F`

subdir() {
# test è come if
# head preleva le prime "-" righe (head -1 = prima riga)
# awk stampa il secondo argomento, ergo viene preso il secondo argomento della prima riga di "ls -l ."
# Perciò se la cartella è vuota, la salta
	if [ `ls -l . | head -1 | awk '{print $2}'` != "0" ]; then
		# Altrimenti scandisce il suo contenuto
		for obj in `ls .`
		do
			# Se il file letto è una cartella, richiama ricorsivamente la funzione
			if [ -d $obj ]; then
				cd $obj
				subdir $obj
			# Altrimenti fa ciò che deve fare
			else
				# Controlla che il file sia stato acceduto oggi
				if [ `ls -l $obj | awk '{print $6}'` = $dataOggi ]; then
					# Se è stato acceduto oggi, lo reimposta a ieri
					touch -d $dataIeri $obj
				fi
			fi
		done
	fi
	cd ..
}

cd $1
subdir $1

# Comando per impostare un file con data di ieri è:
# touch -d `date -d yesterday "+%F %H:%M"` nome_file
# touch -d cambia la data al file mentre date -d imposta la data di un tempo (ieri, oggi, domani), con la formattazione adeguata %FHM...
