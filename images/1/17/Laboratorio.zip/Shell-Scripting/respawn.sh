#!/bin/sh

#########################################################################
# Autore 	: Vincenzo Ferrari 					#
# Data 		: 27/08/2010 						#
# Licenza	: Creative Commons BY - NC - SA Ver. 3.0		#
# Email		: ferrari@cs.unibo.it || wilk3ert@gmail.com		#
# Sito Web	: http://www.wilky.it/					#
# Info Licenza	: http://creativecommons.org/licenses/by-nc-sa/3.0/	#
#########################################################################


# 15/02/2006

# Esercizio 3 – (15 punti)
# Svolgere lo stesso compito dell'esercizio 2 con uno script BASH. Si chiede che lo script controlli ogni 10 secondi la
# presenza del processo da ps, se non esiste piu' lo deve riattivare.

# Ciclo infinito
while [ true ];
do
	# Ogni 10 secondi fa il controllo
	sleep 10
	# ps -e | egrep -o "<processo>" : vuol dire che fa la lista SOLTANTO di quegli elementi che hanno come esatta parola <processo> da ps
	# -z in if vuol dire "= NULL" la stringa
	# Se il processo passato non sta più andando
	if [ -z `ps -e | egrep -o $1` ]; then
		# Lo rilancia in background
		$1 &
	fi
done
