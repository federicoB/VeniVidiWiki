/********************************************************************************/
/*Usare la system call setitimer per creare un programma che stampi l'ora esatta*/
/*a intervalli regolari.La durata dell'intervallo e' specificata in millisecondi*/
/*come parametro.								*/
/********************************************************************************/


#include <sys/time.h>
#include <sys/types.h>
#include <unistd.h>
#include <signal.h>
#include <stdlib.h>

sig_t stampaData()
{
	execlp("date","date",0);
}

int main(int argc, char* argv[]){
	int ris;
	struct itimerval time;
	pid_t cpid;
	sig_t hand;

	/*imposto il periodo(it_interval)ad argv[1].*/
	/*value e' il contatore che decrementa sempre */
	/*quando arriva a 0 manda un segnale e lo risetta*/
	/*al valore di it_interval*/
	time.it_interval.tv_sec=0;
	time.it_interval.tv_usec=atoi(argv[1])*1000;
	time.it_value.tv_sec=0;
	time.it_value.tv_usec=atoi(argv[1])*1000;

	/*specifico il gestore che verra' usato dopo il segnale*/	
	hand = signal(SIGALRM,(sig_t)stampaData);
	
	while(1)
	{
		cpid=vfork();
		
		if(cpid==0)
		{
			/*con setitimer apetto un periodo e mando un segnale*/
			ris=setitimer(ITIMER_REAL,&time,0);
			/*mi addormento fino a quando arriva il segnale*/
			pause();
			/*gestisco il segnale altrimenti terinerebbe il processo*/
			signal(SIGALRM,hand);
		}
	
	}
}
