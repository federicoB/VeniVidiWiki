#!bin/bash

##################################################################################
#Scrivere uno script che faccia il merge di due alberi del file system copiandoli#
#in un terzo. La gerarchia risultante dovrebbe contenere tutti i file e le       #
#directory presenti nel primo o nel secondo albero. Se due file hanno lo stesso  #
#percorso e nomi uguali nei due alberi di partenza i contenuti devono essere     #
#concatenati nel file risultante.						 #
##################################################################################
##################################################################################
#sh merge_2_tree_FS.h <dir1> <dir2> <destdir>					 #
##################################################################################
find $1 > find1	#metto in find1 tutta la lista dei file del primo albero	
find $2 > find2 #metto in find2 tutta la lista dei file del secondo albero

#metto in find12(out) il merge delle due liste senza la dirRoot
cat find1 find2 | awk 'BEGIN {FS="/";OFS="/";out="find12"} {$1=""; print >> out}'

#estraggo dalla lista il path dei file comuni e li metto in comuni
cat find12 | sort | uniq -d > comuni

#copio gli interi alberi nella destdir(NOTA: la seconda cp sovrascrive i file comuni)
cp -r "$1"* $3
cp -r "$2"* $3

#per ogni riga che non fa match con solo "/" concateno il file e li scrivo in destdir
cat comuni | awk '$1!~/^\/$/ { system("cat '$1'" $0 " '$2'" $0 " > '$3'" $0) }'

#rimuovo i file di appoggio che mi sono creato
rm find1 find2 find12 comuni
