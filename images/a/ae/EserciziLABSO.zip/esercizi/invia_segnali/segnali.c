/* Scrivere un programma c che rispedisca al mittente ogni segnale ricevuto  */
/* occorrono opportuni programma campione di esempio per testarne il funzionamento */

#include <unistd.h>
#include <signal.h>
#include <stdio.h>

main(int argc, char *argv[])
{
	int i;
	void rimanda();
	struct sigaction action;

	// sblocca tutti i segnali
	sigemptyset(&action.sa_mask);
	// flag per avere la siginfo_t come secondo parametro
	action.sa_flags = SA_SIGINFO;
	// imposta il gestore
	action.sa_handler = rimanda;

	// associa a tutti i segnali l'azione action
	for (i=1; i<=31; i++) sigaction(i, &action, NULL);

	// attende per un segnale
	while(1) pause();
}

void rimanda(int signo, siginfo_t *info, void *context)
{
	// rimanda il segnale ricevuto al mittente
	kill(info->si_pid, signo);
}
