#!/bin/sh

test -z "$2" && echo "usare: $0 <pid> <segnale>" && exit

# invia il segnale $2 al processo $1
kill -$2 $1

# attende per sempre
while true; do
	sleep 5
done
