#include <unistd.h>

main()
{
	char c;
	while(read(STDOUT_FILENO,&c,1)>0)
		write(STDIN_FILENO,&c,1);

}
