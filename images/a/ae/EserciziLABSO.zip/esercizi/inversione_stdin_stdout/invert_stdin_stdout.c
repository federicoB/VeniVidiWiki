#include <unistd.h>


int main(){

    dup2(1,STDIN_FILENO);  /*modifico STDIN_FILENO*/
    dup2(0,STDOUT_FILENO); /*modifico STDOUT_FILENO*/ 
	execlp("./errato",0);
}
