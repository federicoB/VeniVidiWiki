#!/bin/sh

# Scrivere uno script che prenda come parametro una directory.
# Tutti i file devono essere rinominati ponendo un numero progressivo come prefisso.
# Il numero deve rispecchiare l'ordine del marca temporale di creazione del file (ctime)

find "$*"/* -maxdepth 0 -type f -printf "%C@\t%f\n" | sort -n | awk -F"\t" 'BEGIN { i=1 } { system("mv " $2 " " i "_" $2); i++ }'

# find stampa un elenco nella forma <ctime formato Epoch> \t <nome del file>
# dei file (-type f) contenuti nella cartella passata come parametro, senza
# scendere nelle sottocartelle (-maxdepth 0)

# sort ordina l'elenco sul primo campo (ctime)

# awk inizializza i=1 e poi cicla sull'elenco eseguendo il comando
# mv per rinominare il file ($2) in i_nomefile (i "_" $2) ed incrementa i.

