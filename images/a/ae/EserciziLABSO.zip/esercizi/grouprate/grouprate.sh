#!/bin/bash

# Scrivere uno script che accetta come parametro un file con una lista
# di gruppi e punteggi usando ";" come separatore, tipo:
#
# lso06az03;69,00
# lso06az08;70,00
# lso06az21;65,33
#
# e produca in output una lista dei gruppi in ordine decrescente di punteggio
#
# 70,00 lso06az08
# 69,00 lso06az03
# 65,33 lso06az21

awk -F";" '{ print $2" "$1 }' "$*" | sort -nr

