#!/bin/bash
#########################################################################
#scrivere uno script che lancia un programma e che controlli da ps	#
#(ogni 10 secondi) se è ancora attivo, se non e' attivo lo rilancia	#
#########################################################################

programma="firefox"	#imposto il programma da lanciare
pid=-1			
while true; do
	#se pid=-1 il programma deve essere lanciato
	if [ "$pid" = "-1" ]; then  
		"$programma" & #lancio il programma in background
		pid="$!"       #salvo il pid del programma in pid
	fi
	sleep 10	       #ogni 10 secondi controllo se il programma esiste
	#-p stampa solo la riga del pid specificato
	#(ps -p $pid | grep $pid) ritorna riga vuota se il pid non c'è
	#-z controllo se la stringa è vuota, se è vuota imposto pid=-1 
	test -z "$(ps -p $pid | grep $pid)" && pid=-1
done


