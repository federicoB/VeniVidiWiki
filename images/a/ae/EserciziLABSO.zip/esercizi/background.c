/*Scrivere un programma che metta in background un programma passato */
/*come parametro*/
#include <sys/types.h>
#include <unistd.h>


int main(int argc,char* argv[])
{
	if(!vfork()) execvp(argv[1],&argv[1]);
}
