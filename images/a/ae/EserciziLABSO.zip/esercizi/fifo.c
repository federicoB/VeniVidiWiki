/**************************************************************************************/
/*Scrivere un programma C che prese in input da riga comando il pathname di molteplici*/ 
/*FIFO (almeno 1, numero imprecisato) metta in output tutto cio' che arriva da        */
/*qualsiasi di esse. Il programma non deve usare fork ma una chiamata a scelta        */
/*fra select o poll.                                                                  */
/**************************************************************************************/

#include <stdio.h>
#include <sys/select.h>
#include <unistd.h>
#include <fcntl.h>

int main(int argc, char *argv[])
{

	 int ris,nready;
	 int fd[argc-1];
	 fd_set readset;
	 char* buff[1000];
	 int i,j;

	 if(argc==1)
	 {
		printf("nessun parametro in input");
		return 1;
	 }

	 /*apro i fd di tutti i fifo dati in input*/
	 for(i=1;i<argc;i++)
	 {
		/*apro il file in lettura e rendo la open non bloccante*/
		fd[i-1]=open(argv[i],O_RDONLY|O_NONBLOCK,0);
		if(fd[i-1]<0)
		{
			printf("errore fd open \n");
			return 1;
		}
	   
	 }

	 while(1)
	 {
		FD_ZERO(&readset);
		for(i=0;i<argc-1;i++)
			FD_SET(fd[i],&readset);
	 
	  
		nready = select(fd[argc-2]+1,&readset,NULL,NULL,NULL);
	  
		if(nready < 0)
		{
			printf("errore nella select\n");fflush(stdout);
		}
		else if(nready == 0)
		{
			printf("nessun fd pronto\n");fflush(stdout);
		}else
		{
			/*ciclo su tutti i fd*/
			for(i=0;i<argc-1;i++)
			{
				if((ris=FD_ISSET(fd[i],&readset))!=0)
				{
					if((ris=read(fd[i],&buff,1000))<0)
					{
						printf("err read");fflush(stdout);
					}
					/*stampo a video tutto quello che c'è nel fifo*/
					printf("%s",buff);fflush(stdout);
					/*svuoto il buffer*/
					for(j=0;j<1000;j++)
						buff[j]='\0'; 
				}
			}  
		}
	 }
}
