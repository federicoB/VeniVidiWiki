#!/bin/bash

# Scrivere uno script che accetti come parametro il nome di una directory
# e che produca in output una lista dei nomi e delle dimensioni in Kilobytes
# dei file contenuti nella directory e nelle relative sottodirectory,
# ordinata in ordine decrescente.

find "$*" -type f -exec du {} \; | sort -nr

# cerco nel contenuto della cartella specificata nel parametro ($*)
# tutti i file escludendo le cartelle (-type f) e per ognuno
# eseguo il comando du sul file, che stampa <dimensione> <nome del file>
# poi ordino la lista con sort -nr (numerico, ordine inverso=decrescente)
