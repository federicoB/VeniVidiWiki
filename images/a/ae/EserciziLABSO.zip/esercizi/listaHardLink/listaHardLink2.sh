#!/bin/bash

rm -f hardlink # file dove salvo la lista degli hard link

for file in $(find . -type f)
do
	statfile="$(stat -c"%h:%i" "$file")"
	# assegno a statfile <numero di hard link>:<i-node>
	numLink=$(echo $statfile | awk -F: '{ print $1 }') # primo campo, numero di hard link
	iNode=$(echo $statfile | awk -F: '{ print $2 }') # secondo campo, i node

	# lunghezza del path del file
	lungPath="$(echo $file | sed s/"[^\/]*"//g | wc -m)"
	# con sed sostituisco tutte le occorrenze (g)
	# di qualsiasi carattere diverso da / (con escape \/, per negare [^\/])
	# ripetuto un numero qualsiasi di volte (*)
	# con stringa vuota (//)
	# con wc -m conto il numero di caratteri della stringa ottenuta
	# (cioe' il numero di slash, cioe' la profondita' del path)

	# se il file ha piu' di un hard link stampo <i node>:<lung path>:<file> nel file hardlink
	test "$numLink" -gt 1 && echo "$iNode:$lungPath:$file" >> hardlink
done

# stampo la lista degli hardlink lasciando un'interlinea vuota per ogni file
sort -t: hardlink | awk -F: 'BEGIN { vecchio=-1 } { if (vecchio!=$1 && vecchio!=-1) print ""; print $3; vecchio=$1 }'

# elimino gli hard link col path piu' lungo
sort -t: hardlink | awk -F: 'BEGIN { vecchio=-1 } { if ($1==vecchio) print "rm ",$3; vecchio=$1 }'
