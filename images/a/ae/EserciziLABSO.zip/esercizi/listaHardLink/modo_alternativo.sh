#!/bin/bash

#########################################################################################################################
#Scrivere uno script bash che data una directory cerchi la presenza di file (non directory) che abbiano nel sotto albero# 
#stesso diversi nomi (esistano piu' hard link che puntino allo stesso file). Ne venga stampata la lista			#
#########################################################################################################################
find $1 -type f -printf "%i %p %n\n" | sort | awk 'BEGIN{ old = -1 } { if(old!=$1 && old!=-1) print""; print $2; old=$1; }' 





