/*****************************************************************************/
/*Scrivere una funzione a numero variabile di parametri (v. man stdarg).     */
/*Tutti i parametri passati sono di tipo char*, un elemento di valore 	     */	
/*(char*)0 indica la fine della lista. Ogni parametro identifica un 	     */
/*eseguibile privo di parametri da lanciare (con fork e execlp).             */
/*ad esempio: runall("ls","date","uname",(char*)0);                          */
/*****************************************************************************/
#include <string.h>
#include <stdarg.h>
#include <unistd.h>
#include <stdio.h>
#include <sys/types.h>
#include <stdlib.h>



void stringcopy(char *str, char *strCopied);
void runall(char *first,...);

int main (){
	runall("ls -l" , "date" , "ls" , "date" , (char*)0);
	runall("ls" , (char*)0);
	exit(0);
}
/*funzione aux che copia una stringa fino al delimitatore " "*/
void stringcopy(char *str, char *strCopied)
{
	char i=0;
	while (  (*(str + i)) != ' ')
	{
		*(strCopied  + i) = *(str +i);
		i++;
	}
	*(strCopied + i) = '\0';
	return;
}

/*funzione che prende un numero arbitrario di parametri, 0 identifica la fine*/
void runall(char *first, ...)
{
	pid_t cpid,ris;
	va_list ap;
	char *s=first;//inizializzo s al primo parametro
	int end = 1;
	char *del = " ";
	char *arg = NULL;
	char cmd[20];
	/*inizializzo ap con la sequenza di parametri*/
	va_start(ap,first);
        
		while(end)
		{
		
			if (s!=0)/*non sono all'ultimo parametro*/
			{
				/*tiro fuori gli argomenti*/
				arg = strstr(s, del);
				if(arg!=NULL)	
				{	/*tiro fuori il comando senza argomenti e lo metto in cmd*/
					stringcopy(s, cmd); 
					arg++;
				}
				/*creo un processo figlio per eseguire il comando del parametro*/
				cpid=vfork();
				if(cpid==0)
				{
					if(arg!=NULL)
						execlp(cmd,cmd,arg,(char *)0);
	
					else
						execlp(s,0);
					return;
				}
			}else end=0;
			/*ritorna il prossimo parametro e aggiorna ap*/
			/*type va_arg(va_list ap, type);*/
			s=va_arg(ap,char *);
		}
		va_end(ap);return;
}

