/***************************************************************************/
/*Scrivere la funzione: envfork(int argc, char*argv[]) che accetta in input*/
/*una lista di argomenti sul modello di quella del main() in C, dove ogni  */
/*argomento è il nome di un comando, ed esegue ciascun comando in parallelo*/
/*con execvp limitando però l'environment di esecuzione al solo PATH-/bin  */
/*se argv{"ls","df","who"} allora dovranno normalmente essere eseguiti in  */
/*parallelo solo ls e df(che stanno /bin) e non who (che sta in /usr/bin)  */	
/***************************************************************************/	



#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <sys/stat.h>
#include <sys/types.h>


envfork(int argc, char*argv[])
{
	int i;
	char cmd[100];
	struct stat sb;
	

	for (i=0;i<argc;i++)
	{
		strcpy(cmd,"/bin/");
		strcat(cmd,argv[i]);
		if(stat(cmd,&sb)!=-1)
			if(!vfork())execvp(argv[i],0);
	}
}

int main(int argc, char* argv[])
{
	envfork(argc-1,&argv[1]);
}
