#!/bin/bash
#########################################################################
#Scrivere uno script che prenda come paramteri un file eseguibile e	# 
#un elenco di nomi di file.						#
#lo script deve lanciare l'esseguibile ponendo di volta in volta come 	#
#input i file indicati con il suffisso .in				#
#aggiunto. L'output di ogni esecuzione deve essere confrontato con 	#
#l'output atteso dall'esecuzione che lo script trovera' nel file di 	#
#volta in volta corrispondente con suffisso .out. 			#
#Lo script deve fornire una lista dell'esecuzioni con indicazione 	#
#della corrispondenza (o meno) dell'output prodotto con l'output atteso.#
#########################################################################


cmd=$1
shift #serve per shiftare i parametri di uno a sinistra (perdendo il primo) 
for file in $* 
do
	echo -n "$cmd $file "
	test "$($cmd ${file}.in)" = "$(cat ${file}.out)" && echo ok || echo failed
done


#test restituisce true o false a seconda dell'esito dell'espressione
#&& (then)
#|| (else)
 
