#!bin/bash
##############################################################################  #scrivere uno script: mail_all list_mail "subject" file_mess                 #
#che accetti come parametri un file contenente una lista di e-mail           #
#una stringa da usare come subject e un file di testo, e che manda           #
#singolarmente a ciascun utente della lista una e-mail con il messaggio e con# 
#il subject indicato.							     #	
##############################################################################
for dest in $(cat "$1")#seleziono ciascuno mail
do
	mail -s "$2" $dest < "$3" # -s<oggetto> <destinatario> <file_msg>
done


