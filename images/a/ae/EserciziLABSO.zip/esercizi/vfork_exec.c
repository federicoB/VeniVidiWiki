/********************************************************************************/
/*Scrivere un programma in linguaggio C che attivi un programma e stia in attesa*/
/*se per qualche motivo il programma controllato termina lo deve lanciare       */
/*nuovamente.									*/
/*e.g.										*/
/*        respawn mydeamond -a -b -c						*/
/*attiva mydaemond con i parametri indicati, se mydaemond termina viene 	*/
/*rilanciato nello stesso modo.							*/
/*(Hint usare wait o meglio waitpid).						*/
/********************************************************************************/

#include <sys/wait.h>
#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>
#include <sys/types.h>


main(){
 
	pid_t cpid,ris;
	int status;
	/*faccio un while true perchè nel caso il processo figlio termini lo rilancio*/
	while(1)
	{
		/*la vfork restituisce 0 al figlio e il pid del figlio creato al padre*/
		cpid = vfork();
		if(cpid<0) 
		{
			printf("errore vfork");
			exit(1);
		}
		
		if(cpid==0)
		{
			printf("il pid del figlio e' %ld\n",(long)getpid());
			//execl("/bin/bash","/bin/bash","firefox",0);
			execlp("firefox",0);
		}
		else
		{
			do
			{
				/*non ho messo nessun opzione, in questo caso è bloccante*/ 
				/*(in attesa del segnale dal figlio)*/
				ris=waitpid(cpid,&status,0);
				if(ris<0)
				{
					printf("errore nella waitpid");
					exit(1);
				}
				if (WIFEXITED(status)) 
				{
					printf("exited, status=%d\n", WEXITSTATUS(status));
				} 
				else if (WIFSIGNALED(status)) 
				{
					printf("killed by signal %d\n", WTERMSIG(status));
				}
		       } while (!WIFEXITED(status) && !WIFSIGNALED(status));

		}
	
	}
	
}

/*WIFEXITED(status)::ritorna true se lo status corrisponde ad un child che ha terminato normalmente*/
/*WIFSIGNALED(status)::ritorna true se lo status corrisponde ad un child che ha terminato in modo anormale*/
