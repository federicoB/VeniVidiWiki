/**********************************************************************/
/*Scrivere un programma C che ad intervalli regolari controlli        */
/*se un processo(specificato come parametro) e' ancora in esecuzione. */
/*Il programma termina subito dopo il primo controllo nel quale il    */
/*programma controllato non viene piu' trovato.                       */
/*--il processo controllante e controllato non devono essere "parenti"*/
/*--il processo controllato deve essere qualsiasi                     */
/**********************************************************************/

#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>

main(int argc, char* argv[])
{
	char a[100];
	struct stat sb;
	/*copia una stringa  char *strcpy(char *dest, const char *src);*/
	strcpy(a,"/proc/");
	/*concatena due stringhe char *strcat(char *dest, const char *src);*/
	strcat(a,argv[1]);
	/*se stat restituisce 0 allora il processo esiste*/
	/*sfrutto il fatto che i processi in esecuzione si trovano in /proc*/
	while(!stat(a,&sb))
		sleep(5);
	
	exit(0);
}
