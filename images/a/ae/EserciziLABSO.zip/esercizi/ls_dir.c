/************************************************************************/
/*scrivere un programma C che stampi la lista dei file della directory  */
/*corrente nei quali l'utente ha diritto di lettura scrittura esecuzione*/
/*(a seconda di un parametro -r -w -x)					*/
/************************************************************************/

#include <dirent.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <string.h>

#define r 0
#define w 1
#define x 2

main(int argc,char* argv[])
{
	struct dirent **namelist;
        int n;
	struct stat sb;
	mode_t temp;
	int permessi;

	if(argc==1)
        {
                printf("nessun parametro in input");
                return 1;
        }
	/*analizzo i parametri dati in input e li sostituisco con dei valori interni*/	
	if (!strcmp(argv[1],"-r"))permessi=r;
       	if (!strcmp(argv[1],"-w"))permessi=w;
       	if (!strcmp(argv[1],"-x"))permessi=x;
        
	/*analizzo la cartella corrente e ritorno il numero delle entry e salvo i nomi in namelist*/
	n = scandir(".", &namelist, 0, 0);
        if (n < 0)
 	       perror("scandir");
        else 
	{
 	       	while(n--) /*per ogni entry*/
		{
			/*carico lo stato del file in sb*/
                       if(stat(namelist[n]->d_name,&sb)==-1)
	                       printf("errore stat\n");

			/*prendo solo le entry che corrispondono a file(NO DIR)*/
			if(S_ISREG(sb.st_mode))
			{
				/*in base ai parametri in input*/
				switch(permessi)
				{
					/*stampo a video i file di cui l'utente ha permessi di:*/
					case r:	if((sb.st_mode & S_IRUSR) == S_IRUSR)
							printf("%s\n", namelist[n]->d_name);
						break;
					case w: if((sb.st_mode & S_IWUSR) == S_IWUSR)
							printf("%s\n", namelist[n]->d_name);
						break;
					case x: if((sb.st_mode & S_IXUSR) == S_IXUSR) 
        	     					printf("%s\n", namelist[n]->d_name);
						break;
					/*libero la memoria allocata da scandir*/
	                   		free(namelist[n]);
				}
			}
              	}
			/*libero la memoria allocata da scandir*/
              		free(namelist);
        }

}

/*st_mode è un campo della struttura sb (che è di tipo stat) che mi da il tipo del file	*/
/*e i permessi.										*/
/*MASCHERA|SIGNIFICATO 
/*-----------------------------------------				*/
/*S_IRUSR user read							*/
/*S_IWUSR user write							*/
/*S_IXUSR user execute							*/
/*-----------------------------------------				*/
/*S_IRGRP group read							*/
/*S_IWGRP group write							*/
/*S_IXGRP group execute							*/
/*-----------------------------------------				*/
/*S_IROTH other read							*/
/*S_IWOTH other write							*/
/*S_IXOTH other execute							*/
/************************************************************************/
/*Per determinare facilmente il tipo di file è conveniente utilizzare	*/ 
/*delle macro a disposizione(ad esempio S_ISREG(sb.st_mode) 		*/
/************************************************************************/
/*S_ISREG() 	file regolare						*/
/*S_ISDIR() 	directory						*/
/*S_ISCHR() 	file speciale a carattere				*/
/*S_ISBLK() 	file speciale a blocchi					*/
/*S_ISFIFO() 	FIFO							*/
/*S_ISLNK() 	link simbolico  	non in POSIX.1			*/
/*S_ISSOCK() 	socket 			non in POSIX.1			*/
/************************************************************************/
