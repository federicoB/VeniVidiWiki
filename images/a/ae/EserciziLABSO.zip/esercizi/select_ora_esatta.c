// Scrivere un programma che copi lo standard input nello standard output, aggiungendo in quest'ultimo 
// la riga con l'ora esatta ogni 5 secondi. Il programma deve essere composto da un solo processo 
// (non fare fork).

#include <sys/time.h>
#include <time.h>
#include <sys/types.h>
#include <unistd.h>
#include <sys/select.h>
#include <stdio.h>
#include <stdlib.h>


/* stampa l'ora corrente */
void oraEsatta()
{
           char outstr[200];
           time_t t=time(NULL);
	   strftime(outstr, sizeof(outstr),"%T", localtime(&t));
           printf("%s\n", outstr);
} 



int main(){

	struct timeval time;
	fd_set readset,writeset;
	time.tv_sec=5;
	time.tv_usec=0;
	char buff;
	int nready;

	while(1)
	 {
		FD_ZERO(&readset);			
		FD_SET(STDIN_FILENO,&readset);
	 
		nready = select(STDIN_FILENO+1,&readset,NULL,NULL,&time);
	  
		if(nready == 0) // timeout
		{
			time.tv_sec=5;
			oraEsatta();
		} else // descrittore pronto
		{
			read(STDIN_FILENO,&buff,1);
			write(STDOUT_FILENO,&buff,1);
		}
	}
}
