/************************************************************************/
/*Scrivere un programma C che accetti questa sintassi			*/
/*./filecontrol <nome file> <secondi> <comando> <param1> <param2> ..    */
/*ed effettui le seguenti operazioni:					*/
/*a)controlli lo stato dei file ogni tot secondi			*/
/*b)quando il file viene cancellato, esegua il comando indicato 	*/
/*  passandogli i parametri forniti					*/
/************************************************************************/

#include <sys/stat.h>
#include <unistd.h>
#include <stdlib.h>

int main(int argc, char* argv[])
{
	struct stat sb;
	while(1)
	{
		if(stat(argv[1],&sb)==-1)execvp(argv[3],&argv[3]);
		sleep(atoi(argv[2]));
	}

	
}
