#!/bin/bash
 
# Es 3 2006/02/15
# Svolgere lo stesso compito dell'esercizio 2 con uno script BASH. Si chiede che lo script controlli ogni 10 secondi la
# presenza del processo da ps, se non esiste piu' lo deve riattivare.
 
run=true 

if [ "$#" -e "0" ]; then
	echo Parametri insufficenti
	exit 1
fi

while true; do

	if $run
	then
		$@ &
		run=false
	fi

	sleep 10
	
	r=`ps | grep "$1$"`
	
	if [ ! -n "$r" ]
	then
		run=true
	fi
done