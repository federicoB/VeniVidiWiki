/*
 * Es 1 2006/02/15
 * Scrivere un programma in linguaggio C che attivi un programma e stia in attesa, se per qualche motivo il programma
 * controllato termina lo deve lanciare nuovamente.
 * e.g.
 *      respawn mydeamond -a -b -c
 * attiva mydaemond con i parametri indicati, se mydaemond termina viene rilanciato nello stesso modo.
 * (Hint usare wait o meglio waitpid).
 */

#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <sys/types.h>
#include  <sys/wait.h>
#include  <unistd.h>

/*
 * Funzione d'appoggio per lanciare il demone
 * program : path assoluta o relativa del demone da lanciare
 * argv : argomenti da passare al demone (il vettore deve essere formato con i criteri della funzione execvp)
 * return : ritorna il pid del figlio, e iil figlio non viene creato la funzione non ritona e il processo padre
 * viene terminato
 */
pid_t create_child(char *program, char *argv[]);
 
/*
 * Stampa in modo leggibile la casusa di terminazione di un processo
 * status :  stato del processo terminato
 */
void pr_exit(int status);

int main(int argc, char *argv[]) {
	int i;
	int new_argc; /* Nuovo numero di argomenti del demone da eseguire */
	char **new_argv; /* novo argv per il demone da eseguire */
	pid_t ret;
	int status;
	
	if (argc <= 1) {
		fprintf(stderr, "Troppi pochi argomenti\n");
		exit(1);
	}
	
	new_argc = argc - 1;
	new_argv = malloc(sizeof(char *) * (new_argc + 1) );
	
	/* preparo new_argv */
	for (i = 1; i < argc; i++)
	{
		new_argv[i-1] = argv[i];
	}
	new_argv[new_argc] = NULL;
		
	ret = create_child(argv[1], new_argv );

	while ( (ret = waitpid(ret, &status, 0)) > 0 ) {
		pr_exit(status);
		ret = create_child(argv[1], new_argv);
	}
	
	if (ret < 0) {
		perror("main while ( (ret = wait(NULL)) > 0 )");
		exit(1);
	}
	
	return 0;
}

pid_t create_child(char *program,  char *argv[])
{
pid_t ret;

	ret = fork();
	
	if (ret < 0) {
		perror("create_child ret = fork()");
		exit(1);
	}
	
	if ( ret == 0 ) {
		if (execvp(program, argv) == -1) {
			perror("create_child if (execvp(program, argv) == -1)");
		}
	}
	
	return ret;
}

void pr_exit(int status)
{
	if (WIFEXITED(status))
		printf("normal termination, exit status = %d\n",
			   WEXITSTATUS(status));
	else if (WIFSIGNALED(status))
		printf("abnormal termination, signal number = %d%s\n",
			   WTERMSIG(status),
#ifdef  WCOREDUMP
						WCOREDUMP(status) ? " (core dumped)" : "");
#else
	"");
#endif
	else if (WIFSTOPPED(status))
		printf("child stopped, signal number = %d\n",
			   WSTOPSIG(status));
}
