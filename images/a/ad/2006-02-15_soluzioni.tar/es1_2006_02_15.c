/*
 * Es 1 2006/02/15
 *
 * Scrivere un programma C che prese in input da riga comando il pathname di molteplici FIFO (almeno 1, numero
 * imprecisato) metta in output tutto cio' che arriva da qualsiasi di esse.
 * Il programma non deve usare fork ma una chiamata a scelta fra select o poll.
 */
#include <stdio.h>
#include <errno.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>

#include <sys/types.h>
#include <sys/stat.h>
#include <sys/select.h>
#include <sys/time.h>
#include <sys/stat.h>

#define BUFF_SIZE 32

#define MAX( n1 , n2 ) ( ( n1 > n2 ) ? n1 : n2 )

int main( int argc, char **argv )
{
int *fds; /* futuro vettore di file desriptour delle pipe */
int i, j; /* indice per i cicli for */
int fd_max = 0; /* valore massimo di file descriptour aperto */
int ret, nread;
const int num_files = argc - 1;
char buff[BUFF_SIZE];
struct stat file_info;
fd_set readfds, allset;

	/* Controllo se ci sono abbastanza argomenti */
	if (argc <= 1)
	{
		printf( "Argomenti insufficenti : serve alemno in file FIFO\n" );
		exit( 1 );
	}
	
	/* Alloco lo spazio per i descrittori */
	fds = malloc( sizeof(int) * ( argc - 1 ) );
	if ( fds == NULL )
	{
		perror("Main: fds = malloc( sizeof(int) * ( argc - 1 ) )");
	}
	
	FD_ZERO( &allset );
	
	/* Apro tutte le pipe */
	for ( i = 1; i < argc; i++ )
	{
		fds[i-1] = open( argv[i], O_RDONLY | O_NONBLOCK );
		
		if ( fds[i-1] < 0 ) {
			perror("Main: fds[i-1] = open( argv[i], O_RDONLY | O_NONBLOCK )");
			fprintf(stderr, "File accusato \"%s\"\n", argv[i]);
			exit(1);
		}
	
		if ( fstat( fds[i-1], &file_info) == -1 )  {
			perror("Main: fstat( fds[i-1], &file_info) == -1)");
			exit(1);
		}
		
		if ( !S_ISFIFO( file_info.st_mode ) ) {
			fprintf(stderr, "Main: file \"%s\" is not a FIFO\n", argv[i]);
			exit(1);
		}
		
		FD_SET( fds[i-1], &allset );
		fd_max = MAX( fd_max, fds[i-1] ); /* cerco il valore di fd massimo per la select */
	}
	
	while ( 1 )
	{
		readfds =  allset;	
		ret = select( fd_max + 1, &readfds, NULL, NULL, NULL );
		
		if ( ret == -1 )
		{
			if ( errno == EINTR )		
				continue;
			else
			{
				perror( "Main ret = select( fd_max + 1, &readfds, NULL, NULL, NULL )" );
				exit( 1 );
			}
		}
		
		/* Controllo su quale pipe è avvenuto cosa */
		for ( i = 0; i < num_files; i++ )
		{
			if ( FD_ISSET( fds[i], &readfds ) )
			{
				nread = read( fds[i], buff, BUFF_SIZE );
				
				if ( nread == 0 )
				{
					/* Chiudo la pipe e la riapro */
					close( fds[i] );
					FD_CLR( fds[ i ], &allset );
					fds[ i ] = open( argv[i + 1], O_RDONLY | O_NONBLOCK );
					
					if ( fds[i] < 0 )
					{
						perror( "Main: fds[ i ] = open( argv[ i + 1 ], O_RDONLY | O_NONBLOCK )" );
						exit(1);
					}
					
					FD_SET( fds[ i ], &allset );
					fd_max = MAX( fd_max, fds[ i ] );
				}
				else
				{
					/* Stampo quel che ho a disposizione */
					for ( j = 0; j < nread; j++ ) 
						putchar( buff[ j ] );
				}
			}
		}
	}

	return 0;
}
