/* 
 * Esercizio 1 – 24/01/2006
 * Scrivere un programma C che rispedisca al mittente ogni segnale ricevuto. (occorrono opportuni programmi campione di
 * esempio per provarne il funzionamento).
 */


#include <stdio.h>
#include <errno.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <assert.h> 
#include <signal.h>


sigset_t allsig, blokallsig;

void sig_handler_powerfull(int sig, siginfo_t *info, void *p);

int main(int argc, char **argv)
{
	struct sigaction action;
	sigemptyset(&allsig);
	sigfillset(&blokallsig);

	action.sa_mask = blokallsig;
	action.sa_flags =  SA_SIGINFO;
	action.sa_sigaction = sig_handler_powerfull;
	
	sigaction(SIGUSR1, &action, NULL);
	sigaction(SIGUSR2, &action, NULL);
	/* impostare la sigaction con tutti i segnali da rispedire al mittente */

	printf("Sono pronto a ripetere i segnali al mittente\nIl mio pid e' %d\n", getpid());

	while(1) {

		sigsuspend(&allsig);
	}

	return 0;
}

void sig_handler_powerfull(int sig, siginfo_t *info, void *p)
{
	assert( kill(info->si_pid, sig) != -1 );
	printf("Segnale spedito a %d\n", info->si_pid);
}
