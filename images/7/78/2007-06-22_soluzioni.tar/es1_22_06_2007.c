/*
 * Es 1 2007/06/22
 * Scrivere un programma in C:
 * argcount <arg1> <arg2> ...
 * Che accetti in input una lista di argomenti, e stampa in output il numero di volte con cui copare una argomento,
 * oltre all'argomento stesso
 * Esempio
 * argcount prova esempio prova altroesempio
 * deve dare in output
 * 2 prova
 * 1 esempio
 * 1 altroesempio
 * Nota: l'ordine di elencazione delle coppie non e' importante
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/*
 * Cerca la stringa 'parola' nel vettore 'dizionario' di dimensione 'num_elem'
 * Se la parola viene trovata ritorna l'a posizione in cui e' stata trovata [ 0 ; num_elem - 1 ]
 * altrimenti se la parola non c'e' ritorna -1
 */
int my_find(char *parola, char *dizionario[], int num_elem);

int main(int argc, char **argv)
{
	char **parole = NULL; //Vettore di stringhe in cui memorizzare le parole di argv
	int *count = NULL; //Vettore in cui memorizzare il numero di occorrenze di una parole: count[i] e' il numero di occorenze di parole[i]
	int index_i = 0; //Indice per il vettore parole in cui inserire una parola nuova
	int i, ret;
	
	/* Alloco lo spazio massimo nel per il vettore di parole e del contatore */
	parole = (char **) malloc( sizeof(char *) * (argc - 1) );
	count = (int *) malloc( sizeof(int) * (argc -1) );
	
	for (i = 0; i < (argc - 1); i++) {
		count[i] = 0;
		parole[i] = NULL;
	}
	
	
	for (i = 1; i < argc; i++)
	{
		ret = my_find( argv[i], parole, argc - 1 );
		
		if (ret != -1)
		{
			count[ret]++;
		}
		else
		{
			parole[index_i] = argv[i];
			count[index_i]++;
			index_i++;
		}
	}
	
	/* Stampo le occorenze */
	for (i = 0; i < (index_i); i++)
	{
		printf("%d %s\n", count[i], parole[i]);
	}
	
	free( parole );
	free( count );
	
	return 0;
}


int my_find(char *parola, char **dizionario, int num_elem) {
	int i;
	
	for (i = 0; i < num_elem; i++) 
	{
		if (dizionario[i] != NULL) {
			if (strcmp(dizionario[i], parola) == 0) {
				return i;
			}
		}
	}
	
	return -1;
}
 
