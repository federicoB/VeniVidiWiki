#!/bin/bash

# Es 3 2007/06/22 
# Il comando shell ypcat group > gruppi crea un file contenente una lista dei gruppi definiti sul sistema, tipo:
# nardi:*:3101:
# franchim:*:3379:
# bonazzi:*:5488:
# eraggi:*:5763:
# dbrini:*:4358:
# lso06az07:x:11907:acquaviv,chiarell,koblensa,ldalloli
# scrivere uno script:
# grouplist gruppi
# che accetti come parametro in input il nome del file con la lista di gruppi, estragga tutti e soli i gruppi che cominciano per "lso07az", e
# li stampi nel seguente formato CVS:
# lso07az00;clo,armaroli,franzoso,cgreco
# lso07az01;gemelli,codeca,grassig,mintelis
# lso07az02;mschirin,veronico,marmocch,gurrieri
# lso07az03;lpigliap,gmoretti
# ...
# in ordine crescente di numero di gruppo

if [ ! -n "$1" ]; then
	echo "Manca il mone del file gruppi in input"
	exit 1
fi

if [ ! -f "$1" ]; then
	echo "\"$1\" non e' un file regolare"
	exit 1
fi

cat $1 | awk -F":" '/^lso07az/ { printf $1 ";" $4 "\n" }' | sort
