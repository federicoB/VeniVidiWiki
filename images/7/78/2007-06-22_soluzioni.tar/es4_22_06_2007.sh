#!/bin/bash

# Es 4 2007/06/22 
# Scrivere uno script:
# finduserfile <username> <momedir>
# che accetti come parametri di input u username e una diretory, e che produc in output come risultato tutti e soli i file posseduti
# dall'utente indicato nel sottoalbero del fiesystem specificato, stampandoli in ordine decrescente di dimensione
# Es
# finduserfile mmorsian public_html/
# 468 public_html/2006/lso-04-umps_intro_03.odp
# 416 public_html/lso-02-umps_intro_01.odp
# 412 public_html/2006/lso-02-umps_intro_01.odp
# 364 public_html/lso-04-umps_intro_03-p1.odp

if [ ! -n "$1" ]
then
	echo "specificare un nome utente"
	exit 1
fi

if [ ! -d "$2" ]
then
	echo "\"$2\" non e' una directory"
	exit 1
fi

find $2 -user $1 -type f -exec du {} \; | sort -gr