#/bin/bash

# Es 2 2007/06/22 
# svolgere Es 2 2007/06/22 con uno script bash invece che con un programma C

if [ ! -n "$*" ]
then 
	exit 0
fi

echo $* | sed -e 's/ /\n/g' | sort  | uniq -c | awk '{ print $1 " " $2 }'