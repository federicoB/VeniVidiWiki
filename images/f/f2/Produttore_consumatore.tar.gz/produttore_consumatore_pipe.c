#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <fcntl.h>

/*file descriptor del file condiviso su cui si passano i valori*/
int consume[2], produce[2];

void talk_init() {
	if ((pipe(consume) ||pipe(produce)) < 0)
		perror("pipe error");

//	=== tell_consume(getpid()); ===
//
/*	segnala al produttore che puo iniziare.
*	non necessaria per come e' strutturato il codice del produttore.
*	 se avesse avuto il controllo sul consumo (wait_consume()) 
*	 all'inizio del ciclo si sarebbe dovuta decommentare questa funzione*/
}

void tell_produce(pid_t pid, int num) {	
	if ( (write(produce[1], &num, sizeof(int))) < 0 )
		perror("write error");
}

void wait_produce(int * num) {	/*this call is blocking if there is nothing on buffer*/
if ((read(produce[0], num, sizeof(int))) < 0 )
		perror("read error");

}

void tell_consume(pid_t pid) {
	int num = random() % 10;
	if ( (write(consume[1], &num , sizeof(int))) < 0 )
		perror("write error");  
}

void wait_consume(int * num) {
	if ((read(consume[0], num, sizeof(int))) < 0 )
		perror("read error");
}


int main() {
	int pid;

	talk_init();
	/*crea il file tmpbuffer*/
	if ((pid = fork()) < 0)
		perror("Error creating consumer");
	else if (pid == 0) {	/*consumer*/
		while(1) {
			int ppid;
			int num;
			ppid = getppid();
			wait_produce(&num);
			printf("Consumato %d\n", num);
			fflush(stdout);
			sleep(1);
			tell_consume(ppid);
		}
	}
	else {		/*producer*/
		int num;
		while(1) {
			int x;
			x = random() % 100;
			printf("Prodotto %d\n", x);
			fflush(stdout);
			tell_produce(pid, x);
			wait_consume(&num);
		}

	}


	return(0);
}

