#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <fcntl.h>


#define SIGPRODUCE SIGUSR1	/*segnale che il buffer e' stato riempito*/
#define SIGCONSUME SIGUSR2	/*segnale che il buffer e' stato svuotato*/

/*status mask dei processi*/
static sigset_t old_mask, new_mask, zero_mask, produce_mask, consume_mask;

/*file descriptor del file condiviso su cui si passano i valori*/
int fd;


/*non esegue nulla ma il processo uscira dalla pause*/
static void sig_usr(int signo) { /* one signal handler for SIGUSR1 and SIGUSR2 */
  return;
}

/**/
static void get_out(int signum) {
	exit(1);
}

void talk_init() {
	/*inizializza i signal handlers*/
	if (signal(SIGPRODUCE, sig_usr) == SIG_ERR)
		perror("signal error");
	if (signal(SIGCONSUME, sig_usr) == SIG_ERR)
		perror("signal error");
	if (signal(SIGINT, get_out) == SIG_ERR)
		perror("signal error");
	
	/*inizializza le maschere*/
	sigemptyset(&zero_mask);
	sigemptyset(&new_mask);
	sigaddset(&new_mask, SIGPRODUCE);
	sigaddset(&new_mask, SIGCONSUME);

	sigemptyset(&produce_mask);
	sigemptyset(&consume_mask);
	sigdelset(&produce_mask, SIGPRODUCE);
	sigdelset(&consume_mask, SIGCONSUME);

/*blocca il contenuto della new mask e salva la vecchia maschera in old_mask*/
/*questo perche' non devono essere catturati prima dia aver eseguito la suspend*/
  if (sigprocmask(SIG_BLOCK, &new_mask, &old_mask) < 0)
		perror("error");
	tell_consume(getpid());	/*segnala al produttore che puo iniziare*/
}

void tell_produce(pid_t pid) {
	kill(pid, SIGPRODUCE);   /* tell parent we're done */
}

void wait_produce(void) {
	sigsuspend(&produce_mask);  /* and wait for parent */
      	/* reset signal mask to original value */
	if (sigprocmask(SIG_BLOCK, &new_mask, &old_mask) < 0)
		perror("error");
}

void tell_consume(pid_t pid) {
	kill(pid, SIGCONSUME);     /* tell child we're done */
}

void wait_consume(void) {
	sigdelset(&consume_mask, SIGCONSUME);
		 /* and wait for child */
		sigsuspend(&consume_mask);		
	
		/* reset signal mask to original value */
		if (sigprocmask(SIG_BLOCK, &new_mask, &old_mask) < 0)
		perror("error");
}


int main() {
	int pid;

	talk_init();
	/*crea il file tmpbuffer*/
	if ((fd = open("tmpbuffer", O_RDWR | O_CREAT | O_EXCL, S_IRUSR | S_IWUSR)) < 0)
		perror("error");
	if ((pid = fork()) < 0)
		perror("Error creating consumer");
	else if (pid == 0) {	/*consumer*/
		while(1) {
			int num;
			wait_produce();
			if ((lseek(fd,0,SEEK_SET)) < 0)
		perror("error");
			if ((read(fd,&num,sizeof(int))) < 0)
		perror("error");
			printf("Consumato %d\n", num);
			fflush(stdout);
			tell_consume(getppid());
		}
	}
	else {		/*producer*/
		while(1) {
			int x;
			x = random() % 100;
			if((lseek(fd,0,SEEK_SET)) < 0)
		perror("error");
			if ((write(fd,&x,sizeof(int))) < 0)
		perror("error");
			printf("Prodotto %d\n", x);
			fflush(stdout);
			tell_produce(pid);
			wait_consume();
		}

	}


	return(0);
}

