Mandare in stampa un file alla volta perche' le stampanti del laboratorio impiegano un po' di tempo a caricare i ps fatti in questo modo.
Se avete problemi, scrivetemi:
maurizio.molle@gmail.com