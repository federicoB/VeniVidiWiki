/* 
 * Esercizio 1 20/9/2005
 * Scrivere un programma che faccia il ripetitore di segnali. Richiamato con il numero di un processo come argomento deve
 * rispedire tutti i segnali che riceve al processo indicato come parametro (quelli “gestibili”, non ad esempio il segnale 9).
 * Es:
 * $ ripeti 2525
 * rimandera' tutti i segnali ricevuti al processo 2525
 */

#include <stdio.h>
#include <errno.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <assert.h>
#include <signal.h>

#include <sys/select.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/select.h>
#include <sys/time.h>
#include  <sys/wait.h>

sigset_t allsig;
pid_t pid;

void sig_handler(int sig);

int main(int argc, char **argv)
{
	struct sigaction action;

	assert(argc >= 2);

	pid = atoi(argv[1]);	

	sigemptyset(&allsig);

	assert( signal(SIGUSR1, sig_handler) != SIG_ERR );
	assert( signal(SIGUSR2, sig_handler) != SIG_ERR );
	/* qui bisogna effettuare la signal(segnale, sig_handler) per tutti i segnali da ripetere */

	printf("Sono pronto il mio pid e' %d\n", getpid());

	while(1) {
		sigsuspend(&allsig); 
	}

	return 0;
}

void sig_handler(int sig) {
	assert( signal(sig, sig_handler) != SIG_ERR );

	assert( kill(pid, sig) != -1 );
}
