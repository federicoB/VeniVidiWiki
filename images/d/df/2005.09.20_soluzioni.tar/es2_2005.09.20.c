/*
 * Esercizio 2 20/9/2005
 *  Scrivere un programma che funzioni da “terminale” in grado di comunicare tramite due named pipe (fifo) con un
 * programma gemello.
 * Es. dopo aver creato due fifo di nome f1 e f2 in una finestra si scrive:
 * $ fifoterm f1 f2
 * in un'altra finestra
 * $ fifoterm f2 f1
 * tutto quello che si digita in una finestra deve comparire nella seconda e viceversa.
 * Ogni carattere letto in input deve essere posto su uno dei due fifo (diciamo quello indicata come secondo parametro) e cio'
 * che viene letto dall'altro fifo viene posto in output
 * Suggerimenti (aprire le fifo con parametri O_RDWR | O_NONBLOCK, leggere il manuale di poll o di select).
 */

#include <stdio.h>
#include <sys/types.h>
#include <unistd.h>
#include <assert.h>
#include <sys/select.h>
#include <sys/time.h>
#include <sys/types.h>
#include <stdlib.h>
#include <errno.h>
#include <sys/stat.h>
#include <fcntl.h>

#define MAX(a1,a2) ( ( a1 > a2 ) ? a1 : a2 )
#define DIM 25

int main(int argc, char **argv)
{
int read_pipe, write_pipe, nread, ret;
char buff[DIM];
fd_set allreadfd, readfd;

	assert(argc >= 3);
	
	printf("*** Aspettate che dall'altro terminale qualcuno si colleghi ***\n");
	
	read_pipe = open(argv[1], O_RDONLY | O_NONBLOCK);
	assert(read_pipe != -1);
	
	write_pipe = open(argv[2], O_WRONLY );
	assert(write_pipe != -1);
	
	FD_ZERO(&allreadfd);
	FD_SET(read_pipe, &allreadfd);
	FD_SET(STDIN_FILENO, &allreadfd);
	
	printf("*** Pronti a chatare! premere Ctrl-D per uscire ***\n");
	
	while(1) {
		readfd = allreadfd;
		ret = select(MAX(read_pipe,STDIN_FILENO) + 1, &readfd, NULL, NULL, NULL);
		
		if (ret == -1) {
			if (errno == EINTR) {
				printf("Iterrotto\n");
				continue;
			}
			perror("seclect");
			exit(1);
		}
		
		if (FD_ISSET(STDIN_FILENO, &readfd)) {
			nread = read(STDIN_FILENO, buff, DIM);
			
			if (nread == 0)
				break;
			else
				write(write_pipe, buff, nread);
		}
		
		if (FD_ISSET(read_pipe, &readfd)) {
			nread = read(read_pipe, buff, DIM);
			
			if (nread == 0)
				break;
			else
				write(STDOUT_FILENO, buff, nread);
		}
		
		
	}
	
	close(read_pipe);
	close(write_pipe);
	printf("*** Chat chiusa ***\n");
	return 0;
}
