#!/bin/bash 

#Esercizio 3 20/9/2005
#Scrivere uno script che elenchi tutti i file contenuti nel sottoalbero determinato da una directory, ordinandoli per lunghezza
#del pathname: prima quelli che hanno pathname relativo piu' corto poi via via quelli che hanno path piu' lungo.

if [ ! -n "$1" ] ; then
	echo "Parametro mancante, laciare:"
	echo `basename $0` "percorso_directory" 
	exit 1
fi

if [ ! -d $1 ]; then
	echo $1 "non e' una directory"
	exit 1
fi

find $1 -type f | awk '{ print length($0) ";" $0 }' | sort -g  | cut -d";" -f2