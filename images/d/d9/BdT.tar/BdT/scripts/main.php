<?php
// Costanti per la pagina modello
define("CSS_PATH_TEMPLATE", "/* CSS_PATH */");
define("VERSION_TEMPLATE", "<!-- Version -->");
define("RIGHTMENU_TEMPLATE", "<!-- RightMenu -->");
define("LEFTMENU_TEMPLATE", "<!-- LeftMenu -->");
define("CONTENTS_TEMPLATE", "<!-- Contents -->");
define("AUTH_FAILED_MSG", "Autenticazione fallita!");

function buildAuthTable() {
	return '
		<form method="post" action="index.php">
			<table cellpadding="0" cellspacing="4" margin="0" border="1">
				<tr>
					<td>Username:</td>
					<td><input name="UserName" type="text" maxlength="12"></td>
				</tr>
				<tr>
					<td>Password:</td>
					<td><input name="Password" type="password" maxlength="12"></td>
				</tr>
				<tr>
					<td>&nbsp;</td>
					<td><input type="submit" value="Login"></td>
				</tr>
			</table>
		</form>
	';
}

/*
	Setta il cookie in caso di utenticazione riuscita e ritorna un array cosi' definito:
		<nome-array> {
			"CodSocio"       => <string> CodiceUtente
			"Nome"           => <string> NomeUtente
			"Cognome"        => <string> CognomeUtente
			"TotOreRicevute" => <string> Totale delle ore di servizio ricevute
			"TotOreSvolte"   => <string> Totale delle ore di servizio svolte
			"authError"      => <string> Se questa componente e' settata le altre
			                             componenti non sono definite e authError
			                             contiene il messaggio di errore
		}
*/
function authenticate($userName, $password, $dbmsConnString) {
	$dbref = pg_connect($dbmsConnString) or die();
	$queryResult = pg_exec("
		SELECT CodSocio, Nome, Cognome, TotOreRicevute, TotOreSvolte
		FROM Socio
		WHERE UserName='" . $userName . "' AND Md5Password='" . md5($password) . "'
	");
	
	// Se il risultato esiste ed e' unico, setta il cookie
	if($queryResult && pg_numrows($queryResult) == 1) {
		$result["CodSocio"] = pg_result($queryResult, 0);
		$result["Nome"] = pg_result($queryResult, 1);
		$result["Cognome"] = pg_result($queryResult, 2);
		$result["TotOreRicevute"] = pg_result($queryResult, 3);
		$result["TotOreSvolte"] = pg_result($queryResult, 4);
		$result["authError"] = "";
	}
	else {
		$result["authError"] = AUTH_FAILED_MSG;
	}
	
	pg_close($dbref);
	return $result;
}

function createCookie($userInfo) {
	list($key, $value) = each($userInfo);
	$result = $key . "=" . urlencode($value);
	while(list($key, $value) = each($userInfo)) {
		$result .= "&" . $key . "=" . urlencode($value);
	}
	return $result;
}

function buildCalendar($dayName, $monthName, $yearName) {
	$months = array(
		"Gennaio", "Febbraio", "Marzo", "Aprile", "Maggio", "Giugno", "Luglio", "Agosto", "Settembre", "Ottobre", "Novembre", "Dicembre"
	);
	
	
	$result = "<select name=\"$dayName\">\n";
	for($i = 1; $i <= 31; $i++)
		$result .= "\t<option value=\"$i\">$i</option>\n";
	$result .= "</select>\n";
	
	$result .= "<select name=\"$monthName\">\n";
	for($i = 0; $i < 12; $i++)
		$result .= "\t<option value=\"" . ($i + 1) . "\">$months[$i]</option>\n";
	$result .= "</select>\n";

	$result .= "<select name=\"$yearName\">\n";
	for($i = 2005; $i < 2010; $i++)
		$result .= "\t<option value=\"$i\">$i</option>\n";
	$result .= "</select>\n";
		
	return $result;
}

function buildPage($templatePath, $cssPath, $versionStr, $rightMenu, $leftMenu, $contents) {
	$template = file($templatePath);
	$page = "";
	foreach($template as $line) {
		if(strstr($line, CSS_PATH_TEMPLATE)) {
			$line = str_replace(CSS_PATH_TEMPLATE, $cssPath, $line);
		}
		else if(strstr($line, VERSION_TEMPLATE)) {
			$line = str_replace(VERSION_TEMPLATE, $versionStr, $line);
		}
		else if(strstr($line, RIGHTMENU_TEMPLATE)) {
			$line = str_replace(RIGHTMENU_TEMPLATE, $rightMenu, $line);
		}
		else if(strstr($line, LEFTMENU_TEMPLATE)) {
			$line = str_replace(LEFTMENU_TEMPLATE, $leftMenu, $line);
		}
		else if(strstr($line, CONTENTS_TEMPLATE)) {
			$line = str_replace(CONTENTS_TEMPLATE, $contents, $line);
		}

		$page .= $line;
	}
	
	return $page;
}

function buildUserInfoTable($userInfo) {
	if($userInfo["TotOreSvolte"] >= $userInfo["TotOreRicevute"])
		$balance = $userInfo["TotOreSvolte"] - $userInfo["TotOreRicevute"];
	else
		$balance = "<font color=\"red\">" . ($userInfo["TotOreSvolte"] - $userInfo["TotOreRicevute"]) . "</font>";

	$infoTable = '
		<!-- Menu informazioni utente -->
		<table id="UserInfoTable" border="1">
			<tr>
				<td>Nome:</td>
				<td>' . $userInfo["Nome"] . '</td>
			</tr>
			<tr>
				<td>Cognome:</td>
				<td>' . $userInfo["Cognome"] . '</td>
			</tr>
			<tr>
				<td>Ore svolte:</td>
				<td>' . $userInfo["TotOreSvolte"] . '</td>
			</tr>
			<tr>
				<td>Ore ricevute:</td>
				<td>' . $userInfo["TotOreRicevute"] . '</td>
			</tr>
			<tr>
				<td>Saldo ore:</td>
				<td>' . $balance . '</td>
			</tr>
		</table>
	';
	
	return $infoTable;
}

function buildHomePage() {
	return '
		<p>bla bla..</p>
	';
}
?>
