<?php

// Ritorna il valore di searchtag="valore"
// se presente nella stringa buffer,
// NULL altrimenti
//
function getTag($buffer, $searchtag) {
	if(($buffer = stristr($buffer, $searchtag))) {
		$start = strpos($buffer, "\"");
		$end = strpos($buffer, "\"", $start + 1);
		//echo $start . " " . $end;
		return substr($buffer, $start + 1, $end - $start - 1);
	}
	else
		return NULL;
}

// Ritorna il valore tra <htmltag>valore</htmltag>
// se presente nella stringa buffer,
// NULL altrimenti
//
function getHtml($buffer, $htmltag) {
	if(($buffer = stristr($buffer, "<$htmltag>"))) {
		$start = strpos($buffer, ">") + 1;
		if(($buffer2 = stristr($buffer, "</$htmltag>"))) {
			$length = strlen($buffer) - strlen($buffer2) - strlen("</$htmltag>") + 1;
			return substr($buffer, $start, $length);
		}
	}

	return NULL;
}

// getPresentationInfo() ritorna un array definito come segue
// <nome-array> {
// 	"title"       => <titolo-presentazione>
// 	"description" => <titolo-presentazione>
// 	"chapters"    => {
// 		[0] => {
// 			"title" => <titolo-capitolo-0>
// 			"pagesNum" => <numero-pagine-capitolo-0>
// 			"pages" => {
// 				[0] => <titolo-pagina-0>
// 				[1] => <titolo-pagina-1>
// 				...
// 				[n] => <titolo-pagina-n>
// 			}
// 		}
// 		...
// 		[n] => {
// 			"title" => <titolo-capitolo-n>
// 			"pagesNum" => <numero-pagine-capitolo-n>
// 			"pages" => {
// 				[0] => <titolo-pagina-0>
// 				[1] => <titolo-pagina-1>
// 				...
// 				[n] => <titolo-pagina-n>
// 			}
// 		}
// 	}
//
function getPresentationInfo($source)
{
	$presInfo = NULL;

	$fp = fopen($source, "rt");
	$str = fgets($fp);
	while(!stristr($str, "<PRESENTATION") && !feof($fp))
		$str = fgets($fp);

	if(feof($fp))
		return NULL;

	$presInfo["title"] = getTag($str, "title");
	$presInfo["description"] = "";
	$str = fgets($fp);
	while(!stristr($str, "</PRESENTATION>") && !feof($fp)) {
		$presInfo["description"] .= $str;
		$str = fgets($fp);
	}

	for($i = 0; !feof($fp); $i++) {
		while(!feof($fp) && !stristr($str, "<CHAPTER"))
			$str = fgets($fp);
		
		if(!feof($fp)) {
			$presInfo["chapters"][$i]["title"] = getTag($str, "TITLE");
			$str = fgets($fp);
			for($j = 0; !feof($fp) && !stristr($str, "<CHAPTER"); $j++) {
				while(!feof($fp) && !stristr($str, "<CHAPTER") && !stristr($str, "<PAGE"))
					$str = fgets($fp);

				if(stristr($str, "<PAGE")) {
					$presInfo["chapters"][$i]["pages"][$j] = getTag($str, "TITLE");
					$str = fgets($fp);
				}
			}
			$presInfo["chapters"][$i]["pagesNum"] = ($j - 1);
		}
	}
	
	fclose($fp);
	return $presInfo;
}

// getPageInfo() ritorna un array così definito:
// <nome-array> {
// 	"chapterTitle"    => <titolo-capitolo>
// 	"chapterSubTitle" => <sottotitolo-capitolo>
// 	"pagesNum"        => <numero-pagine-capitolo>
// 	"pageTitle"       => <titolo-pagina>
// 	"pageSubtitle"    => <sottotitolo-pagina>
// 	"paragraphs"      => {
// 		0 => {
// 			"title"    => <title-paragrafo-0>
// 			"subtitle" => <subtitle-paragrafo-0>
// 			"content"  => <contenuto-paragrafo-0>
// 		}
// 		1 => { ... }
// 		n => {
// 			"title"    => <title-paragrafo-n>
// 			"subtitle" => <subtitle-paragrafo-n>
// 			"content"  => <contenuto-paragrafo-n>
// 		}
// 	}
// }
//
function getPageInfo($source, $chapterNo, $pageNo)
{
	$pageInfo = NULL;

	$fp = fopen($source, "rt");
	$str = fgets($fp);
	for($i = 0; ($i <= $chapterNo) && !feof($fp); $i++) {
		while(!feof($fp) && !stristr($str, "<CHAPTER"))
			$str = fgets($fp);
		if($i == $chapterNo) {
			// Becca la roba del chaptero
			$pageInfo["chapterTitle"] = getTag($str, "TITLE");
			$pageInfo["chapterSubtitle"] = getTag($str, "SUBTITLE");
		}

		$str = fgets($fp);
	}
	
	if(feof($fp))
		return NULL;
	
	$pageInfo["pageTitle"] = NULL;
	for($i = 0; ($i <= $pageNo) && !feof($fp); $i++) {
		while(!feof($fp) && !stristr($str, "<PAGE"))
			$str = fgets($fp);
		if($i == $pageNo) {
			// Becca la roba della pagina (tranne il n° di pagine)
			$pageInfo["pageTitle"] = getTag($str, "TITLE");
			$pageInfo["pageSubtitle"] = getTag($str, "SUBTITLE");
		}

		$str = fgets($fp);
	}
	
	if(feof($fp))
		return NULL;

	for($i = 0; !stristr($str, "<PAGE") && !stristr($str, "<CHAPTER") && !feof($fp); $i++) {
		while($str && !stristr($str, "<PARAGRAPH") && !stristr($str, "<PAGE") && !stristr($str, "<CHAPTER"))
			$str = fgets($fp);
			
		if(stristr($str, "<PARAGRAPH")) {
			// Becca l'i-esimo paragrafo
			$pageInfo["paragraphs"][$i]["title"] = getTag($str, "TITLE");
			$pageInfo["paragraphs"][$i]["subtitle"] = getTag($str, "SUBTITLE");
			
			$str = fgets($fp);
			$pageInfo["paragraphs"][$i]["content"] = "";
			while($str && !stristr($str, "<PARAGRAPH") && !stristr($str, "<PAGE") && !stristr($str, "<CHAPTER") && !feof($fp)) {
				$pageInfo["paragraphs"][$i]["content"] .= $str;
				$str = fgets($fp);
			}
		}
	}

	$i = 0;
	while(!stristr($str, "<CHAPTER") && !feof($fp)) {
		if(stristr($str, "<PAGE"))
			$i++;
		$str = fgets($fp);
	}
	
	// i sono le altre pagine del capitolo
	// (i + pageNo + 1) le pagine totali del capitolo
	$pageInfo["pagesNum"] = ($i + $pageNo + 1);

	fclose($fp);
	return $pageInfo;
}

//////////////////
//
define("CSS_PATH", "./css/page.css");
define("PRESENTATION", "./contents/BdT.txt");

/*

*/
define("FAST_BACKWARD_STRING", "Capitolo precedente");
define("FAST_BACKWARD_SIZE"  , "15%");
define("BACKWARD_STRING"     , "Precedente");
define("BACKWARD_SIZE"       , "15%");
define("HOME_STRING"         , "Home Page");
define("HOME_SIZE"           , "40%");
define("FORWARD_STRING"      , "Successivo");
define("FORWARD_SIZE"        , "15%");
define("FAST_FORWARD_STRING" , "Capitolo successivo");
define("FAST_FORWARD_SIZE"   , "15%");

if(isset($HTTP_GET_VARS["chapter"]) && isset($HTTP_GET_VARS["page"])) {
	$presInfo = getPresentationInfo(PRESENTATION);
	if($presInfo && isset($presInfo["chapters"][$HTTP_GET_VARS["chapter"]])) {
		echo "<html>\n<head>\n<title>" . $presInfo["chapters"][$HTTP_GET_VARS["chapter"]]["title"] . "</title>\n";
		echo "<style type=\"text/css\">\n@import url(\"" . CSS_PATH . "\");\n</style>\n</head>\n<body>\n";

		echo "<table width=\"100%\" align=\"center\" id=\"Header\"><tr align=\"center\">\n\t<td width=\"" . FAST_BACKWARD_SIZE . "\">\n";
		// Link al capitolo precedente
		if($HTTP_GET_VARS["chapter"] > 0)
			echo "\t\t<a href=\"" . $HTTP_SERVER_VARS["PHP_SELF"] . "?chapter=" . ($HTTP_GET_VARS["chapter"] - 1) . "&page=0\">" . FAST_BACKWARD_STRING . "</a>\n";
		else
			echo "\t\t" . FAST_BACKWARD_STRING . "\n";

		echo "\t</td>\n\t<td width=\"" . BACKWARD_SIZE . "\">\n";
		
		// Link alla pagina precedente
		if($HTTP_GET_VARS["page"] > 0)
			echo "\t\t<a href=\"" . $HTTP_SERVER_VARS["PHP_SELF"] . "?chapter=" . $HTTP_GET_VARS["chapter"] . "&page=" . ($HTTP_GET_VARS["page"] - 1) . "\">" . BACKWARD_STRING . "</a>\n";
		else if($HTTP_GET_VARS["chapter"] > 0)
			echo "\t\t<a href=\"" . $HTTP_SERVER_VARS["PHP_SELF"] . "?chapter=" . ($HTTP_GET_VARS["chapter"] - 1) . "&page=" . $presInfo["chapters"][$HTTP_GET_VARS["chapter"] - 1]["pagesNum"] . "\">" . BACKWARD_STRING . "</a>\n";
		else
			echo "\t\t" . BACKWARD_STRING . "\n";
			
		// Link alla Home Page
		echo "\t</td>\n\t<td width=\"" . HOME_SIZE . "\">\n\t\t<a href=\"" . $HTTP_SERVER_VARS["PHP_SELF"] . "\">" . HOME_STRING . "</a>\n\t</td><td width=\"" . FORWARD_SIZE . "\">\n";
		
		// Link alla pagina successiva
		if($HTTP_GET_VARS["page"] < $presInfo["chapters"][$HTTP_GET_VARS["chapter"]]["pagesNum"])
			echo "\t\t<a href=\"" . $HTTP_SERVER_VARS["PHP_SELF"] . "?chapter=" . $HTTP_GET_VARS["chapter"] . "&page=" . ($HTTP_GET_VARS["page"] + 1) . "\">" . FORWARD_STRING . "</a>\n";
		else if(isset($presInfo["chapters"][$HTTP_GET_VARS["chapter"] + 1]))
			echo "\t\t<a href=\"" . $HTTP_SERVER_VARS["PHP_SELF"] . "?chapter=" . ($HTTP_GET_VARS["chapter"] + 1) . "&page=0\">" . FORWARD_STRING . "</a>\n";
		else
			echo "\t\t" . FORWARD_STRING . "\n";
			
		echo "\t</td>\n\t<td width=\"" . FAST_FORWARD_SIZE . "\">\n";

		// Link al capitolo successivo
		if(isset($presInfo["chapters"][$HTTP_GET_VARS["chapter"] + 1]))
			echo "\t\t<a href=\"" . $HTTP_SERVER_VARS["PHP_SELF"] . "?chapter=" . ($HTTP_GET_VARS["chapter"] + 1) . "&page=0\">" . FAST_FORWARD_STRING . "</a>\n";
		else
			echo "\t\t" . FAST_FORWARD_STRING . "\n";
		echo "\t</td>\n</tr></table>\n";
		
		if($HTTP_GET_VARS["page"] > 0) {
			$pageInfo = getPageInfo(PRESENTATION, $HTTP_GET_VARS["chapter"], $HTTP_GET_VARS["page"] - 1);
			// Pagina
			echo "<div id=\"Page\">\n";
			
			// Titolo e sottotitolo pagina
			echo "<h1>" . $pageInfo["pageTitle"] . "</h1>\n";
			if($pageInfo["pageSubtitle"])
				echo "<h2>" . $pageInfo["pageSubtitle"] . "</h2>\n";
			
			// Paragrafi
			for($i = 0; isset($pageInfo["paragraphs"][$i]); $i++) {
				echo "\t<div id=\"Paragraph\">\n";
				if($pageInfo["paragraphs"][$i]["title"])
					echo "\t\t<h1>" . $pageInfo["paragraphs"][$i]["title"] . "</h1>\n";
				if($pageInfo["paragraphs"][$i]["subtitle"])
					echo "\t\t<h2>" . $pageInfo["paragraphs"][$i]["subtitle"] . "</h2>\n";
				echo "\t\t<p>\n" . $pageInfo["paragraphs"][$i]["content"] . "\t\t</p>\n\t</div>\n";
			}
			
			echo "<div id=\"PageNo\">Pagina " . $HTTP_GET_VARS["page"] . " di " . $pageInfo["pagesNum"] . "</p>\n</div>";
		}
		else {
			echo "<div id=\"Chapter\">\n\t<h1><a href=\"" . $HTTP_SERVER_VARS["PHP_SELF"] . "?chapter=" . $HTTP_GET_VARS["chapter"] . "&page=1\">" . $presInfo["chapters"][$HTTP_GET_VARS["chapter"]]["title"] . "</a></h1>\n";
			/*
			if($presInfo["chapters"][$HTTP_GET_VARS["chapter"]]["subtitle"])
				echo "\t<h2>" . $presInfo["chapters"][$HTTP_GET_VARS["chapter"]]["subtitle"] . "</h2>\n";
			*/
			echo "</div>\n";
		}
		
		echo "</body>\n</html>\n";
	}
}
else {
	// Home Page
	$presInfo = getPresentationInfo(PRESENTATION);
	if($presInfo) {
		echo "<html>\n<head>\n<title>" . $presInfo["title"] . "</title>\n";
		echo "<style type=\"text/css\">\n@import url(\"" . CSS_PATH . "\");\n</style>\n</head>\n<body>\n";
		echo "<div id=\"Index\">\n<h1>" . $presInfo["description"] . "</h1>\n<ol>\n";

		for($i = 0; isset($presInfo["chapters"][$i]); $i++) {
			//echo "\t<li>" .  . "\n";
			echo "\t<li><a href=\"" . $HTTP_SERVER_VARS["PHP_SELF"] . "?chapter=$i&page=0\">" . $presInfo["chapters"][$i]["title"] . "</a></li>\n";
			if(isset($presInfo["chapters"][$i]["pages"][0])) {
				echo "\t\t<ol>\n";
				for($j = 0; isset($presInfo["chapters"][$i]["pages"][$j]); $j++) {
					echo "\t\t\t<li><a href=\"" . $HTTP_SERVER_VARS["PHP_SELF"] . "?chapter=$i&page=" . ($j + 1) . "\">" . $presInfo["chapters"][$i]["pages"][$j] . "</a></li>\n";
				}
				echo "\t\t</ol>\n";
			}
			echo "\t</li>\n";
		}
		
		echo "</ol>\n</div>\n</body>\n</html>\n";
	}
}
?>
