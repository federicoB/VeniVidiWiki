<?php
include("../scripts/main.php");

define("VERSION", "versione web 1.0");
define("CSS_PATH", "../css/bdt.css");
define("TEMPLATE_PATH", "../scripts/index.inc.html");

define("DBMS_CONN_STRING", "host=localhost dbname=BdT user=UtenteWeb password=34Rq2uiShd8");

/* main function */

	if(isset($HTTP_POST_VARS["UserName"]) && isset($HTTP_POST_VARS["Password"])) {
		$userInfo = authenticate($HTTP_POST_VARS["UserName"], $HTTP_POST_VARS["Password"], DBMS_CONN_STRING);

		if($userInfo["authError"] == "")
			setcookie("BdT", createCookie($userInfo));
	}
	else if(isset($HTTP_COOKIE_VARS["BdT"])) {
		parse_str($HTTP_COOKIE_VARS["BdT"], $userInfo);
	}
	
	// Controlla se l'utente si e' gia' loggato
	if(isset($userInfo) && $userInfo["authError"] == "") {
		$rightMenu = buildUserInfoTable($userInfo);
		$leftMenu = buildUserMenu($userInfo["CodSocio"]);
		
		if(isset($HTTP_GET_VARS["action"])) {
			if($HTTP_GET_VARS["action"] == "request") {
				if(isset($HTTP_POST_VARS["hoursNum"]) && $HTTP_POST_VARS["hoursNum"] > 0) {
					/* controlli!!! */
					$contents = insertRequest(DBMS_CONN_STRING, $userInfo["CodSocio"], $HTTP_POST_VARS["day"], $HTTP_POST_VARS["month"], $HTTP_POST_VARS["year"], $HTTP_POST_VARS["cathegory"], $HTTP_POST_VARS["hoursNum"], $HTTP_POST_VARS["requestDesc"]);
				}
				else
					$contents = buildRequest(DBMS_CONN_STRING, $userInfo["Nome"], $userInfo["Cognome"]);
			}
			else if($HTTP_GET_VARS["action"] == "list") {
				if(isset($HTTP_POST_VARS["CodCategoria"]) && $HTTP_POST_VARS["CodCategoria"] != -1) {
					/* controlli!!! */
					$contents = buildOfferFor(DBMS_CONN_STRING, $userInfo["CodSocio"], $HTTP_POST_VARS["CodSocio"], $HTTP_POST_VARS["CodCategoria"], $HTTP_POST_VARS["DataRichiesta"]);
				}
				else
					$contents = buildList(DBMS_CONN_STRING, $userInfo["CodSocio"]);
			}
			else if($HTTP_GET_VARS["action"] == "confirm")
				$contents = buildConfirm(DBMS_CONN_STRING, $userInfo["CodSocio"]);
		}
		else {
			if(isset($HTTP_POST_VARS["CodSocioOfferente"]) && $HTTP_POST_VARS["CodSocioOfferente"] != -1) {
				$contents = addConfirm(DBMS_CONN_STRING, $userInfo["CodSocio"], $HTTP_POST_VARS["CodSocioOfferente"], $HTTP_POST_VARS["CodCategoria"], $HTTP_POST_VARS["DataRichiesta"]);
			}
			else if(isset($HTTP_POST_VARS["CodCategoria"]) && $HTTP_POST_VARS["CodCategoria"] != -1) {
				/* controlli */
				$contents = buildRequestsFor(DBMS_CONN_STRING, $userInfo["CodSocio"], $HTTP_POST_VARS["CodCategoria"], $HTTP_POST_VARS["DataRichiesta"]);
			}
			else
				$contents = buildReport(DBMS_CONN_STRING, $userInfo["CodSocio"]);
		}
	}
	else {
		$rightMenu = "";
		$leftMenu = "";
		$contents = "";
		
		if(isset($userInfo) && $userInfo["authError"] != "")
			$contents .= "<p><font color=\"red\">" . $userInfo["authError"] . "</font></p>";

		$contents .= buildAuthTable();
		$contents .= buildHomePage();
	}
	
	// Contruisce la pagina coi parametri dati
	echo buildPage(TEMPLATE_PATH, CSS_PATH, VERSION, $rightMenu, $leftMenu, $contents);

/* end of main function*/

function buildUserMenu() {
	global $HTTP_SERVER_VARS;
	
	return '
		<ul>
			<li><a href="' . $HTTP_SERVER_VARS["PHP_SELF"] . '">
				Home Page
			</a>
			<li><a href="' . $HTTP_SERVER_VARS["PHP_SELF"] . '?action=request">
				Richiedi servizio
			</a>
			<li><a href="' . $HTTP_SERVER_VARS["PHP_SELF"] . '?action=list">
				Visualizza tutte le richieste
			</a>
			<li><a href="' . $HTTP_SERVER_VARS["PHP_SELF"] . '?action=confirm">
				Conferma prestazione
			</a>
		</ul>
	';
}

function buildReport($dbmsConnString, $userId) {
	$dbref = pg_connect($dbmsConnString) or die();
	$queryResult = pg_exec("
		SELECT CodCategoria, DescrizioneCategoria, DescrizioneRichiesta, DataRichiesta, NumOreRichieste
		FROM Socio NATURAL JOIN HaRichiesto NATURAL JOIN Categoria
		WHERE Socio.CodSocio=$userId
	");

	if($queryResult) {
		$numRows = pg_numrows($queryResult);
		if($numRows > 0) {
			$result = "
			<h2>Report delle richieste effettuate</h2>
			<form method=\"post\" action=\"index.php\">
			<input type=\"hidden\" name=\"CodCategoria\" value=\"-1\">
			<input type=\"hidden\" name=\"DataRichiesta\" value=\"\">
			
			<table width=\"100%\" border=\"1\">
			<tr><td>Descrizione</td><td>Data</td><td>Num. Ore</td><td>&nbsp;</td></tr>\n";
			
			for($i = 0; $i < $numRows; $i++) {
				$row = pg_fetch_row($queryResult, $i);
				$result .= "\t\t\t\t<tr><td>$row[1]: $row[2]</td><td>$row[3]</td><td>$row[4]</td><td><input type=\"button\" value=\"[O]\" title=\"Visualizza le offerte effettuate per questa richiesta\" onClick=\"form.CodCategoria.value='$row[0]'; form.DataRichiesta.value='$row[3]'; form.submit();\"></td></tr>\n";
			}
			
			$result .= "
			</table>
			</form>\n";
		}
		else
			$result = "no rows";
	}
	else {
		die();
	}
	
	pg_close($dbref);
	return $result;
}

function addConfirm($dbmsConnString, $userId, $userDest, $cath, $date) {
	$dbref = pg_connect($dbmsConnString) or die();
	$queryResult = pg_exec("
		SELECT *
		FROM HaOfferto
		WHERE CodCategoria=$cath AND CodSocioBeneficiario=$userId AND DataPrevista='$date' AND confermato=true
	");

	if($queryResult) {
		if(pg_numrows($queryResult) == 0) {
			$queryResult = pg_exec("
				UPDATE HaOfferto
				SET confermato=true
				WHERE CodCategoria=$cath AND CodSocioBeneficiario=$userId AND DataPrevista='$date' AND CodSocioOfferente=$userDest
			");
			
			$result = "<h2>Conferma ok.</h2>\n";
		}
		else {
			$result = "<h2>Hai gi&agrave; confermato per questo servizio!</h2>\n";
		}
	}
	
	pg_close($dbref);
	return $result;
}

function buildOfferFor($dbmsConnString, $userId, $userDest, $cath, $date) {
	$dbref = pg_connect($dbmsConnString) or die();
	$queryResult = pg_exec("
		SELECT *
		FROM HaOfferto
		WHERE CodCategoria=$cath AND CodSocioOfferente=$userId AND CodSocioBeneficiario=$userDest AND DataPrevista='$date'
	");

	if($queryResult) {
		if(pg_numrows($queryResult) == 0) {
			$queryResult = pg_exec("
				INSERT INTO HaOfferto(CodCategoria, CodSocioOfferente, CodSocioBeneficiario, DataPrevista)
				VALUES($cath, $userId, $userDest, '$date')
			");
			
			$result = "<h2>Inserimento ok.</h2>\n";
		}
		else {
			$result = "<h2>Ti sei gi&agrave; offerto per effettuare questo servizio!</h2>\n";
		}
	}
	
	pg_close($dbref);
	return $result;
}

function buildRequestsFor($dbmsConnString, $userId, $cath, $date) {
	$dbref = pg_connect($dbmsConnString) or die();
	$queryResult = pg_exec("
		SELECT CodSocioOfferente, Nome, Cognome
		FROM HaOfferto, Socio
		WHERE CodSocioBeneficiario=$userId AND DataPrevista='$date' AND CodCategoria=$cath AND CodSocio=CodSocioOfferente AND confermato=false
	");
	
	$result = "";
	if($queryResult) {
		$numRows = pg_numrows($queryResult);
		if($numRows > 0) {
			$result = "
			<form method=\"post\" action=\"index.php\">
			<input type=\"hidden\" name=\"CodCategoria\" value=\"$cath\">
			<input type=\"hidden\" name=\"CodSocioOfferente\" value=\"-1\">
			<input type=\"hidden\" name=\"DataRichiesta\" value=\"$date\">
			
			<table width=\"100%\" border=\"1\">
			<tr><td>Nome</td><td>Cognome</td><td>&nbsp;</td></tr>\n";
			for($i = 0; $i < $numRows; $i++) {
				$row = pg_fetch_row($queryResult, $i);
				$result .= "\t\t\t\t<tr><td>$row[1]</td><td>$row[2]</td><td><input type=\"button\" value=\"[C]\" title=\"Conferma\" onClick=\"form.CodSocioOfferente.value='$row[0]'; form.submit();\"></td></tr>";
			}
			
			$result .= "
			</table>
			</form>\n";
		}
		else {
			$result = "<h2>Nessuna offerta.</h2>\n";
		}
	}
	
	pg_close($dbref);
	return $result;
}

function buildRequest($dbmsConnString, $name, $surname) {
	$dbref = pg_connect($dbmsConnString) or die();
	$queryResult = pg_exec("
		SELECT CodCategoria, DescrizioneCategoria
		FROM Categoria
		WHERE CodCategoria > 0
	");
	
	if($queryResult) {
		$numRows = pg_numrows($queryResult);
		
		$cath = "\t\t\t\t<select name=\"cathegory\">\n";
		for($i = 0; $i < $numRows; $i++) 
			$cath .= "\t\t\t\t\t<option value=\"" . pg_result($queryResult, $i, 0) . "\">" . pg_result($queryResult, $i, 1) . "</option>\n";
		$cath .= "\t\t\t\t</select>\n";
		
		$result = '
			<h2>Modulo di richiesta</h2>
			<form method="post" action="index.php?action=request"><p style="line-height: 2em; text-align: justify;">
				Il cliente <b>' . $name . ' ' . $surname . '</b> richiede servizio di categoria 
				' . $cath . ' da effettuarsi in data 
				' . buildCalendar("day", "month", "year") . '
				e della durata di <input type="text" maxlength="2" name="hoursNum" style="width: 2em;"> ora/e.<br>
				Descrizione aggiuntiva per questa richiesta:<br><textarea name="requestDesc" style="width: 30em; height: 6em;"></textarea>
			</p><input type="submit" value="Invia richiesta"></form>
		';
	}
	else {
		die("Errore dbms!!");
	}
	
	pg_close($dbref);
	return $result;
}

function insertRequest($dbmsConnString, $userId, $day, $month, $year, $cathId, $hoursNum, $desc) {
	$requestKey = sprintf("%03d%03d", $userId, $cathId);
	$dbref = pg_connect($dbmsConnString) or die();
	$query = "
		INSERT INTO HaRichiesto(CodCategoria, CodSocio, DataRichiesta, NumOreRichieste, DescrizioneRichiesta, ChiaveRichiesta)
		VALUES($cathId, $userId, '$year-$month-$day', $hoursNum, " . (($desc == NULL || trim($desc) == "") ? "NULL" : ("'" . htmlentities($desc) . "'")) . ", $requestKey)
	";
	
	$queryResult = pg_exec($query);
	
	if($queryResult) {
		pg_close($dbref);
		return "<p>Inserimento ok, la chiave di conferma &egrave; <b>$requestKey</b></p>";
	}
	else {
		return "<p>Errore inserimento:<br>$query</p>";
	}
}

function buildList($dbmsConnString, $userId) {
	$dbref = pg_connect($dbmsConnString) or die();
	$queryResult = pg_exec("
		SELECT CodSocio, Nome, Cognome, CodCategoria, DescrizioneCategoria, DescrizioneRichiesta, DataRichiesta, NumOreRichieste
		FROM HaRichiesto NATURAL JOIN Socio NATURAL JOIN Categoria
		WHERE CodSocio<>$userId
	");
	
	if($queryResult) {
		$result = "<h2>Elenco delle richieste</h2>";
		$numRows = pg_numrows($queryResult);
		if($numRows > 0) {
			$result .= "
			<form method=\"post\" action=\"index.php?action=list\">
			<input type=\"hidden\" name=\"CodCategoria\" value=\"-1\">
			<input type=\"hidden\" name=\"CodSocio\" value=\"-1\">
			<input type=\"hidden\" name=\"DataRichiesta\" value=\"\">
			
			<table width=\"100%\" border=\"1\">
				<tr><td>Nome</td><td>Cognome</td><td>Descrizione</td><td>In data</td><td>Per ore</td><td>&nbsp;</td></tr>\n";
			
			for($i = 0; $i < $numRows; $i++) {
				$row = pg_fetch_row($queryResult, $i);
				$result .= "\t\t\t<tr><td>$row[1]</td><td>$row[2]</td><td>$row[4]: $row[5]</td><td>$row[6]</td><td>$row[7]</td>
				<td><input type=\"button\" value=\"[P]\" title=\"Rispondi a questa richiesta\" onClick=\"form.CodSocio.value='$row[0]'; form.CodCategoria.value='$row[3]'; form.DataRichiesta.value='$row[6]'; form.submit();\" style=\"width: 2em;\"></td>
				</tr>\n";
			}
			$result .= "
			</form>
			</table>\n";
		}
		else {
			$result = "Nessuna richiesta";
		}
	}
	else {
		die("Errore dbms!!");
	}
	
	pg_close($dbref);
	return $result;
}

function buildConfirm($dbmsConnString, $userId) {
	$dbref = pg_connect($dbmsConnString) or die();
	$queryResult = pg_exec("
		SELECT Nome, Cognome, DescrizioneCategoria, DescrizioneRichiesta, DataPrevista
		FROM HaOfferto NATURAL JOIN Categoria, Socio, HaRichiesto
		WHERE CodSocioBeneficiario=Socio.CodSocio AND CodSocioBeneficiario=HaRichiesto.CodSocio AND DataPrevista=DataRichiesta AND CodSocioOfferente=$userId AND confermato=true
	");

	if($queryResult) {
		$numRows = pg_numrows($queryResult);
		if($numRows > 0) {
			$result = "<p>\n";
			
			for($i = 0; $i < $numRows; $i++) {
				$row = pg_fetch_row($queryResult, $i);
				$result .= var_dump($row) . "<br>\n";
			}
			
			$result .= "</p>\n";
		}
		else
			$result = "<h2>Non hai svolto nessun nuovo lavoro.</h2>";
	}
	else {
		die();
	}
	
	pg_close($dbref);
	return $result;
}
?>
