<?php
include("../scripts/main.php");

define("VERSION", "versione segreteria 1.0");
define("CSS_PATH", "../css/bdt.css");
define("TEMPLATE_PATH", "../scripts/index.inc.html");

define("DBMS_CONN_STRING", "host=localhost dbname=BdT user=Segreteria password=56ftYGHtuOl");

$ERROR_MESSAGE = array (
	"Nessun servizio di segreteria richiesto per oggi.",
	"Non &egrave; compito dell'utente %s svolgere il servizio di segreteria."
);

/* main function */

	if(isset($HTTP_COOKIE_VARS["BdT"])) {
		parse_str($HTTP_COOKIE_VARS["BdT"], $userInfo);
	}
	else if(isset($HTTP_POST_VARS["UserName"]) && isset($HTTP_POST_VARS["Password"])) {
		$userInfo = authenticate($HTTP_POST_VARS["UserName"], $HTTP_POST_VARS["Password"], DBMS_CONN_STRING);
		if($userInfo["authError"] == "") {
			$dbref = pg_connect(DBMS_CONN_STRING) or die();
			// E' stata richiesta la mansione di segreteria per questo giorno a quest'ora?
			$queryResult = pg_exec("
				SELECT to_char(DataRichiesta, 'DD-MM-YYYY HH24'), NumOreRichieste
				FROM HaRichiesto
				WHERE CodSocio=0 AND CodCategoria=0 AND to_char(DataRichiesta, 'DD-MM-YYYY HH24')=to_char(NOW(), 'DD-MM-YYYY HH24')
			");
			
			if($queryResult && pg_numrows($queryResult) == 1) {
				// Se si, e' compito di questo utente svolgere il turno di segreteria?
				$currentTime = pg_result($queryResult, 0);
				$hoursToDo = pg_result($queryResult, 1);
				$queryResult = pg_exec("
					SELECT *
					FROM HaOfferto
					WHERE CodSocioBeneficiario=0 AND CodSocioOfferente=" . $userInfo["CodSocio"] . " AND CodCategoria=0 AND to_char(DataPrevista, 'DD-MM-YYYY HH24')='" . $currentTime . "' AND Confermato=TRUE
				");
				
				if($queryResult && pg_numrows($queryResult) == 1) {
					// Se si, aggiorna le tabelle di Servizio (Richiesto/Offerto/Svolto)
					$queryResult = pg_exec("
						INSERT INTO HaSvolto(CodCategoria, CodSocioAutore, CodSocioBeneficiario, DataSvolgimento, NumOreImpiegate)
						VALUES(0, " . $userInfo["CodSocio"] . ", 0, NOW(), " . $hoursToDo . ");
						
						DELETE FROM HaOfferto
						WHERE CodSocioBeneficiario=0 AND CodSocioOfferente=" . $userInfo["CodSocio"] . " AND CodCategoria=0 AND to_char(DataPrevista, 'DD-MM-YYYY HH24')='" . $currentTime . "';
						
						DELETE FROM HaRichiesto
						WHERE CodSocio=0 AND CodCategoria=0 AND to_char(DataRichiesta, 'DD-MM-YYYY HH24')='" . $currentTime . "';
					");
					
					if($userInfo["authError"] == "")
						setcookie("BdT", createCookie($userInfo));
				}
				else {
					$userInfo["authError"] = sprintf($ERROR_MESSAGE[1], $userInfo["Nome"] . " " . $userInfo["Cognome"]);
				}
			}
			else {
				$userInfo["authError"] = $ERROR_MESSAGE[0];
			}

			pg_close($dbref);
		}
	}
	
	// Controlla se l'utente si e' gia' loggato
	if(isset($userInfo) && $userInfo["authError"] == "") {
		$rightMenu = buildUserInfoTable($userInfo);
		$leftMenu = "";
		$contents = "";
	}
	else {
		$rightMenu = "";
		$leftMenu = "";
		$contents = "";
		
		if(isset($userInfo) && $userInfo["authError"] != "")
			$contents .= "<p><font color=\"red\">" . $userInfo["authError"] . "</font></p>";

		$contents .= buildAuthTable();
		$contents .= buildHomePage();
	}
	
	// Contruisce la pagina coi parametri dati
	echo buildPage(TEMPLATE_PATH, CSS_PATH, VERSION, $rightMenu, $leftMenu, $contents);

/* end of main function*/

?>
